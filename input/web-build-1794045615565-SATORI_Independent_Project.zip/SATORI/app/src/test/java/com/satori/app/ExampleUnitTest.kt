package com.satori.app

import com.satori.app.engine.PythonEngine
import com.satori.app.model.TestCase
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testPrintAndVariables() {
        val code = """
            name = "SATORI"
            score = 100
            print(name)
            print(score)
        """.trimIndent()
        val result = PythonEngine.execute(code)
        assertTrue(result.success)
        assertEquals("SATORI\n100", result.stdout.trim())
    }

    @Test
    fun testArithmeticAndFloorDivision() {
        val code = """
            a = 17
            b = 5
            print(a // b)
            print(a % b)
        """.trimIndent()
        val result = PythonEngine.execute(code)
        assertTrue(result.success)
        assertEquals("3\n2", result.stdout.trim())
    }

    @Test
    fun testLoopAndAccumulator() {
        val code = """
            total = 0
            for i in range(1, 5):
                total += i
            print(total)
        """.trimIndent()
        val result = PythonEngine.execute(code)
        assertTrue(result.success)
        assertEquals("10", result.stdout.trim())
    }

    @Test
    fun testFunctions() {
        val code = """
            def multiply(x, y):
                return x * y
            print(multiply(6, 7))
        """.trimIndent()
        val result = PythonEngine.execute(code)
        assertTrue(result.success)
        assertEquals("42", result.stdout.trim())
    }

    @Test
    fun testExerciseEvaluation() {
        val userCode = "print(\"Hello, SATORI!\")"
        val testCases = listOf(TestCase(expectedOutput = "Hello, SATORI!"))
        val (passed, msg) = PythonEngine.evaluateExercise(userCode, testCases)
        assertTrue(passed)
    }
}
