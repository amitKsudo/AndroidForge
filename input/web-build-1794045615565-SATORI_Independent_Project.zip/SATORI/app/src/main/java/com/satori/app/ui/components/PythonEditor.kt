package com.satori.app.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.satori.app.engine.PythonEngine
import com.satori.app.model.ExecutionResult
import com.satori.app.ui.theme.*

@Composable
fun PythonEditor(
    initialCode: String,
    onCodeChange: ((String) -> Unit)? = null,
    onRunComplete: ((ExecutionResult) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var code by remember(initialCode) { mutableStateOf(initialCode) }
    var customInput by remember { mutableStateOf("") }
    var isRunning by remember { mutableStateOf(false) }
    var executionResult by remember { mutableStateOf<ExecutionResult?>(null) }
    var showInputPrompt by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("python_editor_card"),
        colors = CardDefaults.cardColors(containerColor = SatoriCodeBackground),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(SatoriIndigo.copy(alpha = 0.6f), SatoriPurple.copy(alpha = 0.6f))))
    ) {
        Column {
            // Header bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SatoriSurfaceDark)
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(modifier = Modifier.size(10.dp).background(SatoriErrorRed, RoundedCornerShape(5.dp)))
                    Box(modifier = Modifier.size(10.dp).background(SatoriPythonGold, RoundedCornerShape(5.dp)))
                    Box(modifier = Modifier.size(10.dp).background(SatoriSuccessGreen, RoundedCornerShape(5.dp)))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = "main.py",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = SatoriTextSecondary,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("python_code", code))
                            Toast.makeText(context, "Code copied to clipboard!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.size(32.dp).testTag("copy_code_btn")
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy code", tint = SatoriTextSecondary, modifier = Modifier.size(16.dp))
                    }

                    IconButton(
                        onClick = {
                            code = initialCode
                            executionResult = null
                            onCodeChange?.invoke(initialCode)
                        },
                        modifier = Modifier.size(32.dp).testTag("reset_code_btn")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Reset code", tint = SatoriTextSecondary, modifier = Modifier.size(16.dp))
                    }
                }
            }

            // Editor input area
            val lineCount = maxOf(code.lines().size, 4)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 140.dp, max = 280.dp)
                    .padding(8.dp)
            ) {
                // Line numbers
                Column(
                    modifier = Modifier
                        .padding(end = 8.dp, top = 2.dp)
                        .width(28.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    for (i in 1..lineCount) {
                        Text(
                            text = "$i",
                            color = SatoriTextMuted,
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace,
                            lineHeight = 20.sp
                        )
                    }
                }

                // Vertical separator
                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .fillMaxHeight()
                        .background(SatoriBorderDark)
                )

                // Editable code text field
                BasicTextField(
                    value = code,
                    onValueChange = {
                        code = it
                        onCodeChange?.invoke(it)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 8.dp, top = 2.dp)
                        .testTag("code_input_field"),
                    textStyle = TextStyle(
                        color = SatoriTextPrimary,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace,
                        lineHeight = 20.sp
                    ),
                    cursorBrush = SolidColor(SatoriNeonSpark)
                )
            }

            // Optional custom input box (if code uses input())
            if (code.contains("input(")) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "input(): ",
                        color = SatoriPythonCyan,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    OutlinedTextField(
                        value = customInput,
                        onValueChange = { customInput = it },
                        placeholder = { Text("Value to feed into input()", fontSize = 11.sp, color = SatoriTextMuted) },
                        modifier = Modifier.fillMaxWidth().height(46.dp),
                        singleLine = true,
                        textStyle = TextStyle(fontSize = 12.sp, color = SatoriTextPrimary, fontFamily = FontFamily.Monospace)
                    )
                }
            }

            // Actions bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SatoriSurfaceDark)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${code.length} chars",
                    fontSize = 11.sp,
                    color = SatoriTextMuted
                )

                Button(
                    onClick = {
                        isRunning = true
                        val result = PythonEngine.execute(code, customInput)
                        isRunning = false
                        executionResult = result
                        onRunComplete?.invoke(result)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SatoriIndigo),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("run_python_btn")
                ) {
                    if (isRunning) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                        Spacer(Modifier.width(6.dp))
                        Text("Running...", fontSize = 13.sp)
                    } else {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Run Python", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Console output display
            executionResult?.let { res ->
                ConsoleOutputView(result = res)
            }
        }
    }
}

@Composable
fun ConsoleOutputView(result: ExecutionResult, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("console_output_container"),
        color = Color(0xFF090412)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = null,
                        tint = if (result.success) SatoriSuccessGreen else SatoriErrorRed,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "Terminal Output",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (result.success) SatoriSuccessGreen else SatoriErrorRed
                    )
                }

                Surface(
                    color = SatoriSurfaceHighlightDark,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = "${result.executionTimeMs} ms",
                        fontSize = 10.sp,
                        color = SatoriNeonSpark,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            if (result.stdout.isNotEmpty()) {
                Text(
                    text = result.stdout,
                    color = SatoriTextPrimary,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    lineHeight = 18.sp
                )
            }

            if (result.stderr.isNotEmpty()) {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = result.stderr,
                    color = SatoriErrorRed,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    lineHeight = 18.sp
                )
            }
        }
    }
}
