package com.satori.app.data

import com.satori.app.data.curriculum.CurriculumPart1
import com.satori.app.data.curriculum.CurriculumPart2
import com.satori.app.data.curriculum.CurriculumPart3
import com.satori.app.data.curriculum.CurriculumPart4
import com.satori.app.model.CourseModule

object CurriculumRepository {

    val modules: List<CourseModule> by lazy {
        CurriculumPart1.modules +
        CurriculumPart2.modules +
        CurriculumPart3.modules +
        CurriculumPart4.modules
    }
}
