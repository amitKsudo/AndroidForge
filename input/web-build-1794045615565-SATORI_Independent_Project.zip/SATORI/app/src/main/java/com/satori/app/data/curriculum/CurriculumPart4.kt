package com.satori.app.data.curriculum

import com.satori.app.model.*

object CurriculumPart4 {

    val modules: List<CourseModule> by lazy {
        listOf(
            createModule16(),
            createModule17(),
            createModule18(),
            createModule19(),
            createModule20()
        )
    }

    private fun createModule16(): CourseModule = CourseModule(
        id = "mod_16",
        number = 16,
        title = "Python Standard Library",
        subtitle = "math, random, datetime, collections, and algorithms",
        iconName = "library",
        isPremium = false,
        estimatedHours = 2.0,
        lessons = listOf(
            Lesson(
                id = "m16_l1",
                moduleId = "mod_16",
                title = "Collections & High-Performance Data",
                order = 1,
                difficulty = Difficulty.INTERMEDIATE,
                readTimeMinutes = 6,
                isFree = true,
                summary = "Master specialized container types like Counter and defaultdict for rapid data analysis.",
                whyItMatters = "Counting occurrences or grouping data by category takes 1 line of clean code instead of clunky manual loops.",
                analogy = "An automated sorting machine in a mail room that drops envelopes into labeled bins as fast as they arrive.",
                explanation = "The 'collections' module provides Counter (for instant frequency counting), defaultdict (avoids KeyErrors by supplying defaults), and deque (fast double-ended queue).",
                syntax = "from collections import Counter\ncounts = Counter([1, 2, 2, 3])",
                exampleCode = "# Simulating frequency counting\nwords = [\"python\", \"code\", \"python\", \"sense\", \"code\", \"python\"]\ncounts = {}\nfor w in words:\n    counts[w] = counts.get(w, 0) + 1\nprint(f\"python count: {counts['python']}\")\nprint(f\"code count: {counts['code']}\")",
                lineByLine = listOf(
                    LineExplanation(1, "# Simulating frequency counting", "Frequency count pattern."),
                    LineExplanation(2, "words = [...]", "Sample word list."),
                    LineExplanation(4, "counts[w] = counts.get(w, 0) + 1", "Increments count with fallback 0."),
                    LineExplanation(6, "print(f\"python count: {counts['python']}\")", "Outputs 3."),
                    LineExplanation(7, "print(f\"code count: {counts['code']}\")", "Outputs 2.")
                ),
                expectedOutput = "python count: 3\ncode count: 2",
                visualConceptType = VisualConceptType.NONE,
                commonMistakes = listOf(
                    "Re-inventing complex dictionary grouping logic by hand instead of using standard collections."
                ),
                recap = listOf(
                    "collections offers fast, specialized data structures.",
                    "Frequency counting is essential for analytics and search algorithms."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m16_l1_1",
                        lessonId = "m16_l1",
                        question = "Which class in the 'collections' module tallies elements automatically?",
                        options = listOf("Tally", "Counter", "FrequencyMap", "Accumulator"),
                        correctIndex = 1,
                        explanation = "collections.Counter is a dictionary subclass for counting hashable objects.",
                        topic = "collections"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m16_l1",
                    lessonId = "m16_l1",
                    title = "Frequency Counter",
                    prompt = "Given votes = ['yes', 'no', 'yes', 'yes', 'no'], count how many times 'yes' appears and print the count.",
                    starterCode = "votes = [\"yes\", \"no\", \"yes\", \"yes\", \"no\"]\n# Count and print occurrences of 'yes'\n",
                    solutionCode = "votes = [\"yes\", \"no\", \"yes\", \"yes\", \"no\"]\nprint(votes.count(\"yes\"))",
                    hint = "Use votes.count('yes') inside print().",
                    explanation = "'yes' appears 3 times in the list.",
                    testCases = listOf(
                        TestCase(expectedOutput = "3")
                    )
                )
            ),
            Lesson(
                id = "m16_l2",
                moduleId = "mod_16",
                title = "Dates, Timestamps & Math",
                order = 2,
                difficulty = Difficulty.INTERMEDIATE,
                readTimeMinutes = 6,
                isFree = true,
                summary = "Handle calendar time, timestamps, and mathematical transformations reliably.",
                whyItMatters = "Nearly every commercial software app logs timestamps, schedules subscriptions, or computes date intervals.",
                analogy = "An atomic digital stopwatch that synchronizes with the calendar.",
                explanation = "Python's datetime module handles dates, times, and intervals (timedelta). The math module provides precision constants (pi, e) and functions (sqrt, ceil, floor).",
                syntax = "import datetime\nfrom datetime import timedelta",
                exampleCode = "# Time calculations\ndays_in_year = 365\nweeks = days_in_year // 7\nremaining_days = days_in_year % 7\nprint(f\"{weeks} weeks and {remaining_days} day\")",
                lineByLine = listOf(
                    LineExplanation(1, "# Time calculations", "Calendar math."),
                    LineExplanation(2, "days_in_year = 365", "Total days."),
                    LineExplanation(3, "weeks = days_in_year // 7", "Full weeks calculation (52)."),
                    LineExplanation(4, "remaining_days = days_in_year % 7", "Remainder day (1)."),
                    LineExplanation(5, "print(...)", "Formatted breakdown.")
                ),
                expectedOutput = "52 weeks and 1 day",
                visualConceptType = VisualConceptType.NONE,
                commonMistakes = listOf(
                    "Attempting to subtract string dates without parsing them into proper date objects first."
                ),
                recap = listOf(
                    "datetime handles dates and times.",
                    "timedelta represents time differences.",
                    "math module provides floor, ceil, sqrt, and trigonometric functions."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m16_l2_1",
                        lessonId = "m16_l2",
                        question = "Which class represents the difference between two datetime instances?",
                        options = listOf("timeinterval", "timedelta", "timespan", "duration"),
                        correctIndex = 1,
                        explanation = "datetime.timedelta represents a duration expressing difference between dates.",
                        topic = "datetime"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m16_l2",
                    lessonId = "m16_l2",
                    title = "Days in Hours",
                    prompt = "Calculate how many hours are in 14 days (14 * 24) and print the total hours.",
                    starterCode = "# Calculate hours in 14 days and print\n",
                    solutionCode = "days = 14\nhours = days * 24\nprint(hours)",
                    hint = "print(14 * 24)",
                    explanation = "14 * 24 = 336 hours.",
                    testCases = listOf(
                        TestCase(expectedOutput = "336")
                    )
                )
            )
        )
    )

    private fun createModule17(): CourseModule = CourseModule(
        id = "mod_17",
        number = 17,
        title = "APIs & Web Services",
        subtitle = "HTTP, GET, POST, JSON responses, requests library",
        iconName = "cloud",
        isPremium = false,
        estimatedHours = 2.2,
        lessons = listOf(
            Lesson(
                id = "m17_l1",
                moduleId = "mod_17",
                title = "HTTP & Consuming Web APIs",
                order = 1,
                difficulty = Difficulty.INTERMEDIATE,
                readTimeMinutes = 6,
                isFree = true,
                summary = "Fetch live information from cloud services and external servers using HTTP.",
                whyItMatters = "Modern applications rarely run in isolation; they connect to weather feeds, payment gateways, AI models, and user databases over HTTP APIs.",
                analogy = "A waiter at a restaurant: you give the waiter your order (HTTP Request), they take it to the kitchen (the server), and bring back your food (HTTP Response).",
                explanation = "HTTP methods include GET (retrieve data), POST (create new data), PUT (update), and DELETE (remove). Responses come with status codes (200 OK, 404 Not Found, 500 Server Error).",
                syntax = "import requests\nresp = requests.get(\"https://api.example.com/data\")\ndata = resp.json()",
                exampleCode = "# Simulating API response parsing\napi_response = {\"status\": 200, \"city\": \"London\", \"temp_c\": 18}\nif api_response[\"status\"] == 200:\n    print(f\"Weather in {api_response['city']}: {api_response['temp_c']}C\")",
                lineByLine = listOf(
                    LineExplanation(1, "# Simulating API response parsing", "Parsing JSON payload."),
                    LineExplanation(2, "api_response = {...}", "Simulated 200 OK payload."),
                    LineExplanation(3, "if api_response[\"status\"] == 200:", "Checks status code."),
                    LineExplanation(4, "print(...)", "Extracts and displays weather.")
                ),
                expectedOutput = "Weather in London: 18C",
                visualConceptType = VisualConceptType.NONE,
                commonMistakes = listOf(
                    "Assuming every API request succeeds—always inspect response.status_code before parsing data."
                ),
                recap = listOf(
                    "GET retrieves data; POST creates data.",
                    "Status code 200 means success; 404 means resource not found.",
                    "JSON is standard payload format."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m17_l1_1",
                        lessonId = "m17_l1",
                        question = "Which HTTP status code indicates a successful request?",
                        options = listOf("200", "404", "500", "301"),
                        correctIndex = 0,
                        explanation = "200 OK indicates the request succeeded.",
                        topic = "HTTP"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m17_l1",
                    lessonId = "m17_l1",
                    title = "Parse API User Record",
                    prompt = "Given response = {'status': 200, 'user': {'name': 'Amit', 'role': 'Developer'}}, print 'User: Amit - Developer'.",
                    starterCode = "response = {\"status\": 200, \"user\": {\"name\": \"Amit\", \"role\": \"Developer\"}}\n# Extract and print user info\n",
                    solutionCode = "response = {\"status\": 200, \"user\": {\"name\": \"Amit\", \"role\": \"Developer\"}}\nuser = response[\"user\"]\nprint(f\"User: {user['name']} - {user['role']}\")",
                    hint = "Extract user = response['user'] and format with f-string.",
                    explanation = "Navigates nested dictionaries to format user data.",
                    testCases = listOf(
                        TestCase(expectedOutput = "User: Amit - Developer")
                    )
                )
            ),
            Lesson(
                id = "m17_l2",
                moduleId = "mod_17",
                title = "Query Parameters & Headers",
                order = 2,
                difficulty = Difficulty.INTERMEDIATE,
                readTimeMinutes = 6,
                isFree = true,
                summary = "Pass filters, authentication API keys, and pagination parameters to endpoints.",
                whyItMatters = "APIs need to know which page to return, which search terms to look up, and who is calling.",
                analogy = "An envelope address with a stamp: the URL is the destination, query parameters are the specific department, and headers contain the security seal.",
                explanation = "Query parameters are appended after '?' (e.g. ?query=python&page=2). HTTP Headers pass meta-information such as 'Authorization: Bearer <token>'.",
                syntax = "params = {\"query\": \"python\", \"page\": 1}\nheaders = {\"Authorization\": \"Bearer token\"}",
                exampleCode = "endpoint = \"https://api.satori.dev/search\"\nquery = \"python\"\npage = 1\nurl = f\"{endpoint}?q={query}&page={page}\"\nprint(url)",
                lineByLine = listOf(
                    LineExplanation(1, "endpoint = ...", "Base API URL."),
                    LineExplanation(4, "url = f\"{endpoint}?q={query}&page={page}\"", "Constructing query string."),
                    LineExplanation(5, "print(url)", "Displays fully formed URL.")
                ),
                expectedOutput = "https://api.satori.dev/search?q=python&page=1",
                visualConceptType = VisualConceptType.NONE,
                commonMistakes = listOf(
                    "Hardcoding secret API keys in public source code repositories."
                ),
                recap = listOf(
                    "Query parameters filter and paginate API requests.",
                    "Headers handle authentication tokens and content types."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m17_l2_1",
                        lessonId = "m17_l2",
                        question = "What character begins query parameters in an HTTP URL?",
                        options = listOf("#", "?", "&", "/"),
                        correctIndex = 1,
                        explanation = "A question mark (?) initiates the query string in a URL.",
                        topic = "Query Parameters"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m17_l2",
                    lessonId = "m17_l2",
                    title = "Construct Query URL",
                    prompt = "Given base = 'https://api.example.com/items' and category = 'books', build and print 'https://api.example.com/items?category=books'.",
                    starterCode = "base = \"https://api.example.com/items\"\ncategory = \"books\"\n# Print the combined query URL\n",
                    solutionCode = "base = \"https://api.example.com/items\"\ncategory = \"books\"\nprint(f\"{base}?category={category}\")",
                    hint = "print(f'{base}?category={category}')",
                    explanation = "Concatenates base URL with formatted query parameter.",
                    testCases = listOf(
                        TestCase(expectedOutput = "https://api.example.com/items?category=books")
                    )
                )
            )
        )
    )

    private fun createModule18(): CourseModule = CourseModule(
        id = "mod_18",
        number = 18,
        title = "Databases & SQL",
        subtitle = "SQLite, CRUD operations, tables, queries in Python",
        iconName = "database",
        isPremium = false,
        estimatedHours = 2.5,
        lessons = listOf(
            Lesson(
                id = "m18_l1",
                moduleId = "mod_18",
                title = "Relational Databases & SQLite",
                order = 1,
                difficulty = Difficulty.INTERMEDIATE,
                readTimeMinutes = 7,
                isFree = true,
                summary = "Store millions of structured records reliably with SQLite and SQL queries.",
                whyItMatters = "Flat files become slow and error-prone when searching large datasets. Relational databases provide lightning-fast indexing and transaction safety.",
                analogy = "An organized spreadsheet with strict column types and instant search filters.",
                explanation = "Python includes sqlite3 builtin. You create tables with SQL (CREATE TABLE), and manage records with cursors and commits.",
                syntax = "import sqlite3\nconn = sqlite3.connect(\"app.db\")\ncursor = conn.cursor()",
                exampleCode = "# Simulating relational database schema\nusers_table = [\n    {\"id\": 1, \"name\": \"Amit\", \"role\": \"Lead\"},\n    {\"id\": 2, \"name\": \"Maya\", \"role\": \"Developer\"}\n]\nprint(f\"Users in DB: {len(users_table)}\")\nfor u in users_table:\n    print(f\"{u['id']}: {u['name']} ({u['role']})\")",
                lineByLine = listOf(
                    LineExplanation(1, "# Simulating relational database schema", "Table representation."),
                    LineExplanation(2, "users_table = [...]", "List of relational rows."),
                    LineExplanation(6, "print(f\"Users in DB: {len(users_table)}\")", "Row count."),
                    LineExplanation(7, "for u in users_table:", "Querying all rows."),
                    LineExplanation(8, "print(...)", "Display row fields.")
                ),
                expectedOutput = "Users in DB: 2\n1: Amit (Lead)\n2: Maya (Developer)",
                visualConceptType = VisualConceptType.NONE,
                commonMistakes = listOf(
                    "Concatenating user strings directly into SQL queries—this exposes applications to catastrophic SQL Injection attacks! Always use parameterized queries (?)."
                ),
                recap = listOf(
                    "SQLite requires zero configuration and lives in a single file.",
                    "Always use parameterized queries with (?) to prevent SQL injection."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m18_l1_1",
                        lessonId = "m18_l1",
                        question = "Which standard module provides local relational database capabilities in Python without extra installation?",
                        options = listOf("postgresql", "sqlite3", "mysqldb", "oracle"),
                        correctIndex = 1,
                        explanation = "sqlite3 is bundled directly inside Python's standard library.",
                        topic = "Databases"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m18_l1",
                    lessonId = "m18_l1",
                    title = "Database Query Simulation",
                    prompt = "Given rows = [{'id': 1, 'task': 'Learn Python', 'done': True}, {'id': 2, 'task': 'Build App', 'done': False}], print only the tasks where done is True.",
                    starterCode = "rows = [{\"id\": 1, \"task\": \"Learn Python\", \"done\": True}, {\"id\": 2, \"task\": \"Build App\", \"done\": False}]\n# Loop and print tasks where done is True\n",
                    solutionCode = "rows = [{\"id\": 1, \"task\": \"Learn Python\", \"done\": True}, {\"id\": 2, \"task\": \"Build App\", \"done\": False}]\nfor r in rows:\n    if r[\"done\"]:\n        print(r[\"task\"])",
                    hint = "for r in rows: if r['done']: print(r['task'])",
                    explanation = "Filters rows where done == True and prints 'Learn Python'.",
                    testCases = listOf(
                        TestCase(expectedOutput = "Learn Python")
                    )
                )
            ),
            Lesson(
                id = "m18_l2",
                moduleId = "mod_18",
                title = "CRUD Operations: Insert, Select, Update, Delete",
                order = 2,
                difficulty = Difficulty.INTERMEDIATE,
                readTimeMinutes = 7,
                isFree = true,
                summary = "Master the 4 fundamental database lifecycle operations: Create, Read, Update, Delete.",
                whyItMatters = "Every web app, social network, and backend service is built around CRUD data manipulation.",
                analogy = "Managing customer accounts: Opening a new account (Create), viewing balance (Read), depositing cash (Update), and closing account (Delete).",
                explanation = "CRUD maps directly to SQL commands: INSERT INTO (Create), SELECT (Read), UPDATE (Update), and DELETE FROM (Delete).",
                syntax = "SELECT * FROM users WHERE active = 1\nUPDATE users SET score = 100 WHERE id = 1",
                exampleCode = "# CRUD simulation\ninventory = {\"laptops\": 10, \"monitors\": 5}\n# Update\ninventory[\"laptops\"] += 2\n# Delete\ninventory.pop(\"monitors\")\nprint(f\"Laptops: {inventory['laptops']}\")\nprint(f\"Items remaining: {len(inventory)}\")",
                lineByLine = listOf(
                    LineExplanation(1, "# CRUD simulation", "Lifecycle operations."),
                    LineExplanation(2, "inventory = {...}", "Initial state."),
                    LineExplanation(4, "inventory[\"laptops\"] += 2", "Update operation: 12."),
                    LineExplanation(6, "inventory.pop(\"monitors\")", "Delete operation."),
                    LineExplanation(7, "print(...)", "Read updated balance.")
                ),
                expectedOutput = "Laptops: 12\nItems remaining: 1",
                visualConceptType = VisualConceptType.NONE,
                commonMistakes = listOf(
                    "Running an UPDATE or DELETE statement without a WHERE clause, which accidentally modifies or wipes out every row in the entire database!"
                ),
                recap = listOf(
                    "CRUD = Create, Read, Update, Delete.",
                    "Always remember the WHERE clause in UPDATE and DELETE.",
                    "Call connection.commit() to persist changes to disk."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m18_l2_1",
                        lessonId = "m18_l2",
                        question = "What happens if you run: 'DELETE FROM users;' without a WHERE clause?",
                        options = listOf(
                            "Only the first user is deleted",
                            "An error is raised requiring a confirmation",
                            "All users in the table are deleted",
                            "Nothing happens"
                        ),
                        correctIndex = 2,
                        explanation = "A DELETE without a WHERE clause deletes all records in the table.",
                        topic = "SQL CRUD"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m18_l2",
                    lessonId = "m18_l2",
                    title = "Update and Read",
                    prompt = "Given account = {'holder': 'Amit', 'balance': 500}, add 150 to balance and print 'Final Balance: ' followed by the updated balance.",
                    starterCode = "account = {\"holder\": \"Amit\", \"balance\": 500}\n# Add 150 to balance and print result\n",
                    solutionCode = "account = {\"holder\": \"Amit\", \"balance\": 500}\naccount[\"balance\"] += 150\nprint(f\"Final Balance: {account['balance']}\")",
                    hint = "account['balance'] += 150; print(f'Final Balance: {account[\"balance\"]}')",
                    explanation = "500 + 150 = 650.",
                    testCases = listOf(
                        TestCase(expectedOutput = "Final Balance: 650")
                    )
                )
            )
        )
    )

    private fun createModule19(): CourseModule = CourseModule(
        id = "mod_19",
        number = 19,
        title = "Practical Software Projects",
        subtitle = "Architecture, CLI apps, Task Managers, and clean codebases",
        iconName = "rocket",
        isPremium = false,
        estimatedHours = 3.5,
        lessons = listOf(
            Lesson(
                id = "m19_l1",
                moduleId = "mod_19",
                title = "Architecture of a CLI Application",
                order = 1,
                difficulty = Difficulty.INTERMEDIATE,
                readTimeMinutes = 7,
                isFree = true,
                summary = "Design command-line applications with command loops, menus, and state management.",
                whyItMatters = "Most developer tooling—Git, Docker, AWS CLI, npm—are CLI applications. Building CLIs teaches solid software architecture.",
                analogy = "An automated bank ATM: you enter your pin, choose from a menu (Withdraw, Deposit, Balance), perform actions, and log out.",
                explanation = "A CLI app typically combines a while True loop with command dispatching functions and graceful exit handling.",
                syntax = "while True:\n    cmd = input(\"> \")\n    if cmd == \"exit\":\n        break",
                exampleCode = "# CLI Task Manager Simulation\ntasks = []\ndef add_task(title):\n    tasks.append(title)\n\nadd_task(\"Study Python\")\nadd_task(\"Build Project\")\nprint(f\"Total tasks: {len(tasks)}\")\nfor idx, t in enumerate(tasks, 1):\n    print(f\"{idx}. {t}\")",
                lineByLine = listOf(
                    LineExplanation(1, "# CLI Task Manager Simulation", "State architecture."),
                    LineExplanation(2, "tasks = []", "Global state container."),
                    LineExplanation(3, "def add_task(title):", "Command dispatch function."),
                    LineExplanation(6, "add_task(...)", "Simulating user commands."),
                    LineExplanation(9, "for idx, t in enumerate(tasks, 1):", "Numbered task listing.")
                ),
                expectedOutput = "Total tasks: 2\n1. Study Python\n2. Build Project",
                visualConceptType = VisualConceptType.NONE,
                commonMistakes = listOf(
                    "Mixing business logic directly with user input parsing: separate your core data functions from display logic."
                ),
                recap = listOf(
                    "Separate data models from UI/CLI presentation logic.",
                    "Use enumerate() for numbered list printing.",
                    "Validate user choices before mutating application state."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m19_l1_1",
                        lessonId = "m19_l1",
                        question = "Which builtin function pairs each item in an iterable with its running count?",
                        options = listOf("counter()", "enumerate()", "zip()", "track()"),
                        correctIndex = 1,
                        explanation = "enumerate() yields (index, item) pairs, allowing a start index parameter.",
                        topic = "CLI Tools"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m19_l1",
                    lessonId = "m19_l1",
                    title = "Task List Formatter",
                    prompt = "Given items = ['Read docs', 'Write tests'], print each item numbered starting at 1 (e.g. '1: Read docs').",
                    starterCode = "items = [\"Read docs\", \"Write tests\"]\n# Print numbered items\n",
                    solutionCode = "items = [\"Read docs\", \"Write tests\"]\ncount = 1\nfor item in items:\n    print(f\"{count}: {item}\")\n    count += 1",
                    hint = "Use a counter or enumerate to print '{count}: {item}'.",
                    explanation = "Iterates and prints numbered list: '1: Read docs' and '2: Write tests'.",
                    testCases = listOf(
                        TestCase(expectedOutput = "1: Read docs\n2: Write tests")
                    )
                )
            ),
            Lesson(
                id = "m19_l2",
                moduleId = "mod_19",
                title = "Refactoring & Clean Project Structure",
                order = 2,
                difficulty = Difficulty.INTERMEDIATE,
                readTimeMinutes = 7,
                isFree = true,
                summary = "Transform messy prototype code into clean, modular, production-ready modules.",
                whyItMatters = "Any beginner can write code a computer understands. Great engineers write code that humans can understand and maintain.",
                analogy = "Organizing your kitchen: spices in one rack, knives in a block, pots in the cupboard—everything has its designated place.",
                explanation = "Follow Single Responsibility Principle: each function should do one thing well. Extract helper functions, avoid global state, and use descriptive names.",
                syntax = "# Clean modular design\ndef calculate_tax(amount, rate=0.05):\n    return amount * rate",
                exampleCode = "def calculate_subtotal(items):\n    return sum(items)\n\ndef apply_discount(total, discount_percent=10):\n    return total * (1 - discount_percent / 100)\n\nprices = [20, 30, 50]\nsubtotal = calculate_subtotal(prices)\nfinal = apply_discount(subtotal)\nprint(f\"Subtotal: {subtotal}\")\nprint(f\"Final: {int(final)}\")",
                lineByLine = listOf(
                    LineExplanation(1, "def calculate_subtotal(items):", "Pure calculation function."),
                    LineExplanation(4, "def apply_discount(...):", "Distinct single responsibility function."),
                    LineExplanation(7, "prices = [20, 30, 50]", "Sample input."),
                    LineExplanation(10, "print(...)", "Clear output.")
                ),
                expectedOutput = "Subtotal: 100\nFinal: 90",
                visualConceptType = VisualConceptType.NONE,
                commonMistakes = listOf(
                    "Writing 200-line monolithic functions that handle input, calculation, and printing all at once."
                ),
                recap = listOf(
                    "Keep functions short and single-purpose.",
                    "Pure functions (without side effects) are easy to test and maintain."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m19_l2_1",
                        lessonId = "m19_l2",
                        question = "What is the Single Responsibility Principle?",
                        options = listOf(
                            "Each module can only have one variable",
                            "A function or class should have only one reason to change",
                            "Only one developer can edit the code file",
                            "Functions must only run once"
                        ),
                        correctIndex = 1,
                        explanation = "A function or class should focus on one specific task.",
                        topic = "Architecture"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m19_l2",
                    lessonId = "m19_l2",
                    title = "Single Responsibility Function",
                    prompt = "Write a function 'compute_average(scores)' that returns sum(scores) / len(scores). Print compute_average([80, 90, 100]) formatted as an integer.",
                    starterCode = "# Define compute_average and print test result\n",
                    solutionCode = "def compute_average(scores):\n    return sum(scores) / len(scores)\n\nprint(int(compute_average([80, 90, 100])))",
                    hint = "return sum(scores) / len(scores); print(int(compute_average([80, 90, 100])))",
                    explanation = "(80 + 90 + 100) / 3 = 90.",
                    testCases = listOf(
                        TestCase(expectedOutput = "90")
                    )
                )
            )
        )
    )

    private fun createModule20(): CourseModule = CourseModule(
        id = "mod_20",
        number = 20,
        title = "Career Learning Paths",
        subtitle = "Web development, Data Science, Automation, and Production Standards",
        iconName = "career",
        isPremium = false,
        estimatedHours = 3.0,
        lessons = listOf(
            Lesson(
                id = "m20_l1",
                moduleId = "mod_20",
                title = "PEP 8 & Type Hints",
                order = 1,
                difficulty = Difficulty.INTERMEDIATE,
                readTimeMinutes = 7,
                isFree = true,
                summary = "Adopt official Python style guides and modern static type annotations.",
                whyItMatters = "PEP 8 is the industry standard for Python style. Consistent code allows teams to collaborate smoothly without style friction.",
                analogy = "Standard road traffic rules: when everybody drives on the same side and stops at red lights, traffic flows safely.",
                explanation = "Type hints specify expected types for parameters and return values: 'def greet(name: str) -> str:'. They improve IDE autocompletion and catch bugs early with static analyzers like mypy.",
                syntax = "def add(x: int, y: int) -> int:\n    return x + y",
                exampleCode = "def calculate_discount(price: float, rate: float = 0.1) -> float:\n    return price * (1.0 - rate)\n\noriginal = 100.0\ndiscounted = calculate_discount(original)\nprint(f\"Original: {original}\")\nprint(f\"Discounted: {discounted}\")",
                lineByLine = listOf(
                    LineExplanation(1, "def calculate_discount(price: float, ...):", "Type annotations for arguments and return value."),
                    LineExplanation(4, "original = 100.0", "Float input."),
                    LineExplanation(5, "discounted = calculate_discount(original)", "Typed invocation."),
                    LineExplanation(6, "print(...)", "Outputs results.")
                ),
                expectedOutput = "Original: 100.0\nDiscounted: 90.0",
                visualConceptType = VisualConceptType.NONE,
                commonMistakes = listOf(
                    "Assuming Python enforces type hints at runtime—type hints are for documentation and static analysis tools like mypy, not runtime enforcement."
                ),
                recap = listOf(
                    "PEP 8 guides indentation (4 spaces), naming (snake_case), and line length.",
                    "Type hints document contracts and improve IDE intelligence."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m20_l1_1",
                        lessonId = "m20_l1",
                        question = "What is PEP 8 in the Python ecosystem?",
                        options = listOf(
                            "A compiler optimization flag",
                            "The official Style Guide for Python Code",
                            "A memory profiling tool",
                            "The Python packaging standard"
                        ),
                        correctIndex = 1,
                        explanation = "PEP 8 provides coding conventions and guidelines for Python code.",
                        topic = "PEP 8"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m20_l1",
                    lessonId = "m20_l1",
                    title = "Type-Annotated Function",
                    prompt = "Define a function 'multiply(a: int, b: int) -> int' returning a * b, and print multiply(7, 8).",
                    starterCode = "# Define typed multiply function and print result\n",
                    solutionCode = "def multiply(a: int, b: int) -> int:\n    return a * b\n\nprint(multiply(7, 8))",
                    hint = "def multiply(a: int, b: int) -> int: return a * b",
                    explanation = "7 * 8 = 56.",
                    testCases = listOf(
                        TestCase(expectedOutput = "56")
                    )
                )
            ),
            Lesson(
                id = "m20_l2",
                moduleId = "mod_20",
                title = "Virtual Environments & Testing",
                order = 2,
                difficulty = Difficulty.ADVANCED,
                readTimeMinutes = 7,
                isFree = true,
                summary = "Isolate project dependencies with venv and guarantee software reliability with unit tests.",
                whyItMatters = "Different projects require different library versions. Virtual environments prevent dependency conflicts on your computer.",
                analogy = "A sandbox for each child: toys in one sandbox don't interfere with toys in another.",
                explanation = "Create virtual environments with 'python -m venv .venv'. Write automated tests with the 'unittest' or 'pytest' frameworks to verify code correctness automatically before deploying to production.",
                syntax = "python -m venv .venv\nsource .venv/bin/activate\npip install package_name",
                exampleCode = "# Unit test verification pattern\ndef test_addition():\n    assert 2 + 2 == 4, \"Addition check\"\n    return \"Test Passed: 2 + 2 == 4\"\n\nprint(test_addition())\nprint(\"Ready for production deployment.\")",
                lineByLine = listOf(
                    LineExplanation(1, "# Unit test verification pattern", "Simulates test suite run."),
                    LineExplanation(2, "def test_addition():", "Test function with assertion."),
                    LineExplanation(3, "assert 2 + 2 == 4", "Verifies expected behavior."),
                    LineExplanation(6, "print(test_addition())", "Displays test status."),
                    LineExplanation(7, "print(\"Ready for production deployment.\")", "Deployment confirmation.")
                ),
                expectedOutput = "Test Passed: 2 + 2 == 4\nReady for production deployment.",
                visualConceptType = VisualConceptType.NONE,
                commonMistakes = listOf(
                    "Installing packages into the global system Python instead of an isolated virtual environment."
                ),
                recap = listOf(
                    "Always use virtual environments (venv) for projects.",
                    "Save dependencies in requirements.txt.",
                    "Automated tests give confidence when refactoring and deploying."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m20_l2_1",
                        lessonId = "m20_l2",
                        question = "Which standard Python command creates an isolated virtual environment?",
                        options = listOf(
                            "python --create-env",
                            "python -m venv .venv",
                            "pip make-env",
                            "virtualenv --build"
                        ),
                        correctIndex = 1,
                        explanation = "'python -m venv <directory>' creates an isolated environment.",
                        topic = "Virtual Environments"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m20_l2",
                    lessonId = "m20_l2",
                    title = "Automated Test Assertion",
                    prompt = "Write a function test_is_even(). It should return 'PASS' if 10 % 2 == 0 else 'FAIL'. Print test_is_even().",
                    starterCode = "# Define test_is_even and print result\n",
                    solutionCode = "def test_is_even():\n    if 10 % 2 == 0:\n        return \"PASS\"\n    return \"FAIL\"\n\nprint(test_is_even())",
                    hint = "if 10 % 2 == 0: return 'PASS' else: return 'FAIL'",
                    explanation = "10 is even, so the test returns and prints 'PASS'.",
                    testCases = listOf(
                        TestCase(expectedOutput = "PASS")
                    )
                )
            )
        )
    )
}
