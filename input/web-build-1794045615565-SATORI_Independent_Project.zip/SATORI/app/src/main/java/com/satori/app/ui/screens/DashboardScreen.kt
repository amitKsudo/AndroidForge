package com.satori.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.satori.app.data.CurriculumRepository
import com.satori.app.data.ReferenceRepository
import com.satori.app.model.UserProfile
import com.satori.app.ui.theme.*

@Composable
fun DashboardScreen(
    userProfile: UserProfile,
    onNavigateToCurriculum: () -> Unit,
    onNavigateToLesson: (String) -> Unit,
    onNavigateToPlayground: () -> Unit,
    onNavigateToCheatsheet: () -> Unit,
    onNavigateToProjects: () -> Unit,
    onNavigateToSubscribe: () -> Unit,
    onNavigateToExam: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val allModules = CurriculumRepository.modules
    val nextLesson = allModules.flatMap { it.lessons }.firstOrNull { !userProfile.completedLessonIds.contains(it.id) }
        ?: allModules.first().lessons.first()

    val totalLessonsCount = allModules.sumOf { it.lessons.size }
    val completedCount = userProfile.completedLessonIds.size
    val completionPercent = if (totalLessonsCount > 0) (completedCount * 100 / totalLessonsCount) else 0

    val currentHour = remember { java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY) }
    val timeGreeting = when (currentHour) {
        in 4..11 -> "Good morning"
        in 12..16 -> "Good afternoon"
        in 17..22 -> "Good evening"
        else -> "Good evening"
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("dashboard_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        // Welcome Header & Time-based Greeting
        item {
            Column {
                Text(
                    text = "$timeGreeting, ${userProfile.name}",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "“Code finally makes sense. One concept at a time.”",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SatoriTextSecondary,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        // Continue Learning Hero Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToLesson(nextLesson.id) }
                    .testTag("continue_learning_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = SatoriSurfaceDark),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(SatoriIndigo, SatoriPurple)))
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = SatoriIndigo.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "CONTINUE LEARNING",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = SatoriNeonSpark,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Default.Schedule, contentDescription = null, tint = SatoriTextSecondary, modifier = Modifier.size(14.dp))
                            Text(text = "${nextLesson.readTimeMinutes} min", fontSize = 12.sp, color = SatoriTextSecondary)
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    Text(
                        text = nextLesson.title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = nextLesson.summary,
                        style = MaterialTheme.typography.bodyMedium,
                        color = SatoriTextSecondary,
                        maxLines = 2,
                        modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                    )

                    Button(
                        onClick = { onNavigateToLesson(nextLesson.id) },
                        colors = ButtonDefaults.buttonColors(containerColor = SatoriIndigo),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().testTag("resume_lesson_btn")
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Resume Lesson", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Stats Overview Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Streak",
                    value = "${userProfile.streakDays} Days",
                    icon = Icons.Default.LocalFireDepartment,
                    iconColor = SatoriWarningOrange,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Total XP",
                    value = "${userProfile.totalXp}",
                    icon = Icons.Default.Bolt,
                    iconColor = SatoriPythonGold,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Completed",
                    value = "$completedCount/$totalLessonsCount",
                    icon = Icons.Default.CheckCircle,
                    iconColor = SatoriSuccessGreen,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Final Examination Gate & Certification
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToExam() }
                    .testTag("dashboard_exam_banner"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = SatoriSurfaceDark),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.horizontalGradient(
                        if (userProfile.hasPassedFinalExam) listOf(SatoriPythonGold, SatoriIndigo)
                        else listOf(SatoriIndigo, SatoriPurple)
                    )
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(if (userProfile.hasPassedFinalExam) SatoriPythonGold.copy(alpha = 0.2f) else SatoriIndigo.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (userProfile.hasPassedFinalExam) Icons.Default.WorkspacePremium else Icons.Default.Quiz,
                                contentDescription = null,
                                tint = if (userProfile.hasPassedFinalExam) SatoriPythonGold else SatoriNeonSpark,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = if (userProfile.hasPassedFinalExam) "Certificate Earned" else "Final Certification Exam",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = Color.White
                                )
                                Surface(
                                    color = if (userProfile.hasPassedFinalExam) SatoriSuccessGreen.copy(alpha = 0.2f) else SatoriIndigo.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = if (userProfile.hasPassedFinalExam) "PASSED (${userProfile.finalExamScore}%)" else "50 MCQs • 67%+ TO PASS",
                                        color = if (userProfile.hasPassedFinalExam) SatoriSuccessGreen else SatoriNeonSpark,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = if (userProfile.hasPassedFinalExam)
                                    "Tap to view official certificate signed by Founder Amit Kumar"
                                else
                                    "Timed 45-minute comprehensive exam to qualify for certification",
                                fontSize = 11.sp,
                                color = SatoriTextSecondary,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = null,
                        tint = SatoriTextSecondary
                    )
                }
            }
        }

        // Daily Goal & Weekly Activity
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SatoriSurfaceDark),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Daily Learning Goal", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                            Text(
                                text = "${userProfile.todayMinutesLearned} / ${userProfile.dailyGoalMinutes} mins completed today",
                                fontSize = 12.sp,
                                color = SatoriTextSecondary
                            )
                        }

                        val progressRatio = (userProfile.todayMinutesLearned.toFloat() / userProfile.dailyGoalMinutes.toFloat()).coerceIn(0f, 1f)
                        Text(
                            text = "${(progressRatio * 100).toInt()}%",
                            fontWeight = FontWeight.Bold,
                            color = SatoriSuccessGreen,
                            fontSize = 14.sp
                        )
                    }

                    Spacer(Modifier.height(10.dp))
                    LinearProgressIndicator(
                        progress = { (userProfile.todayMinutesLearned.toFloat() / userProfile.dailyGoalMinutes.toFloat()).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = SatoriIndigo,
                        trackColor = SatoriSurfaceHighlightDark
                    )

                    Spacer(Modifier.height(16.dp))
                    Text(
                        text = "Weekly Activity",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = SatoriTextSecondary
                    )

                    Spacer(Modifier.height(8.dp))
                    // Weekly mini bar chart
                    val days = listOf("M" to 15, "T" to 20, "W" to 10, "T" to 25, "F" to userProfile.todayMinutesLearned, "S" to 0, "S" to 0)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        days.forEach { (day, mins) ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    modifier = Modifier
                                        .width(22.dp)
                                        .height((mins * 2).coerceIn(4, 50).dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (mins >= 15) SatoriIndigo else SatoriSurfaceHighlightDark)
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(text = day, fontSize = 10.sp, color = SatoriTextMuted)
                            }
                        }
                    }
                }
            }
        }

        // Quick Jump Shortcuts
        item {
            Text(
                text = "Interactive Hub",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickActionCard(
                    title = "Playground",
                    subtitle = "Run real Python",
                    icon = Icons.Default.Code,
                    color = SatoriPythonCyan,
                    onClick = onNavigateToPlayground,
                    modifier = Modifier.weight(1f)
                )
                QuickActionCard(
                    title = "Cheatsheet",
                    subtitle = "Quick reference",
                    icon = Icons.Default.MenuBook,
                    color = SatoriPythonGold,
                    onClick = onNavigateToCheatsheet,
                    modifier = Modifier.weight(1f)
                )
                QuickActionCard(
                    title = "Projects",
                    subtitle = "Guided apps",
                    icon = Icons.Default.RocketLaunch,
                    color = SatoriPurple,
                    onClick = onNavigateToProjects,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Achievements Reel
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Recent Achievements",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "${userProfile.unlockedAchievementIds.size} Unlocked",
                    fontSize = 12.sp,
                    color = SatoriNeonSpark
                )
            }
            Spacer(Modifier.height(8.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(ReferenceRepository.achievements) { item ->
                    val isUnlocked = userProfile.unlockedAchievementIds.contains(item.id)
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = if (isUnlocked) SatoriSurfaceHighlightDark else SatoriSurfaceDark),
                        modifier = Modifier.width(160.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .background(if (isUnlocked) SatoriPythonGold.copy(alpha = 0.2f) else SatoriSurfaceDark, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (isUnlocked) Icons.Default.EmojiEvents else Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = if (isUnlocked) SatoriPythonGold else SatoriTextMuted,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(text = item.title, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                            Text(text = item.description, fontSize = 10.sp, color = SatoriTextSecondary, maxLines = 2)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SatoriSurfaceDark)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Icon(imageVector = icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(20.dp))
            Spacer(Modifier.height(8.dp))
            Text(text = value, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
            Text(text = title, fontSize = 11.sp, color = SatoriTextSecondary)
        }
    }
}

@Composable
fun QuickActionCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SatoriSurfaceDark)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .background(color.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
            }
            Spacer(Modifier.height(8.dp))
            Text(text = title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
            Text(text = subtitle, fontSize = 10.sp, color = SatoriTextSecondary)
        }
    }
}
