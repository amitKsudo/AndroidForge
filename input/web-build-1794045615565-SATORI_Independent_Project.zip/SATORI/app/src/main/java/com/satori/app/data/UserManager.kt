package com.satori.app.data

import android.content.Context
import android.content.SharedPreferences
import com.satori.app.model.CertificateData
import com.satori.app.model.UserAccount
import com.satori.app.model.UserProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class UserManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("satori_user_prefs", Context.MODE_PRIVATE)

    private val _userProfile = MutableStateFlow(loadProfile())
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    private val _isDarkTheme = MutableStateFlow(prefs.getBoolean(KEY_DARK_THEME, true))
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    init {
        ensureDefaultAccountExists()
    }

    private fun ensureDefaultAccountExists() {
        val accounts = getStoredAccounts()
        if (!accounts.containsKey("amitdehlvi@gmail.com")) {
            val defaultAcc = UserAccount(
                id = "usr_amit_01",
                name = "Amit Kumar",
                email = "amitdehlvi@gmail.com",
                passwordHash = "Pass@1234",
                isGoogleUser = false,
                createdAt = "2026-11-06"
            )
            saveAccount(defaultAcc)
        }
    }

    fun toggleTheme() {
        val next = !_isDarkTheme.value
        _isDarkTheme.value = next
        prefs.edit().putBoolean(KEY_DARK_THEME, next).apply()
    }

    // --- Authentication Operations ---

    fun login(email: String, password: String): Result<String> {
        val trimmedEmail = email.trim().lowercase()
        val accounts = getStoredAccounts()
        val account = accounts[trimmedEmail] ?: return Result.failure(Exception("No account registered with $trimmedEmail"))

        if (account.passwordHash != password) {
            return Result.failure(Exception("Incorrect password. Please try again."))
        }

        _userProfile.update { current ->
            val updated = current.copy(
                name = account.name,
                email = account.email,
                isLoggedIn = true,
                provider = if (account.isGoogleUser) "google" else "email"
            )
            saveProfile(updated)
            updated
        }
        return Result.success("Welcome back, ${account.name}!")
    }

    fun register(name: String, email: String, password: String): Result<String> {
        val trimmedEmail = email.trim().lowercase()
        val trimmedName = name.trim()

        if (trimmedName.length < 2) {
            return Result.failure(Exception("Please enter your full name."))
        }
        if (!trimmedEmail.contains("@") || !trimmedEmail.contains(".")) {
            return Result.failure(Exception("Please provide a valid email address."))
        }
        if (password.length < 6) {
            return Result.failure(Exception("Password must be at least 6 characters long."))
        }

        val accounts = getStoredAccounts()
        if (accounts.containsKey(trimmedEmail)) {
            return Result.failure(Exception("An account with this email already exists. Please log in."))
        }

        val newAccount = UserAccount(
            id = "usr_" + System.currentTimeMillis(),
            name = trimmedName,
            email = trimmedEmail,
            passwordHash = password,
            isGoogleUser = false,
            createdAt = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        )
        saveAccount(newAccount)

        _userProfile.update { current ->
            val updated = current.copy(
                name = trimmedName,
                email = trimmedEmail,
                isLoggedIn = true,
                provider = "email"
            )
            saveProfile(updated)
            updated
        }
        return Result.success("Account created successfully!")
    }

    fun loginWithGoogle(name: String = "Amit Kumar", email: String = "amitdehlvi@gmail.com"): Result<String> {
        val trimmedEmail = email.trim().lowercase()
        val trimmedName = name.trim()

        val accounts = getStoredAccounts()
        if (!accounts.containsKey(trimmedEmail)) {
            val googleAcc = UserAccount(
                id = "usr_g_" + System.currentTimeMillis(),
                name = trimmedName,
                email = trimmedEmail,
                passwordHash = "GOOGLE_OAUTH_TOKEN",
                isGoogleUser = true,
                createdAt = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            )
            saveAccount(googleAcc)
        }

        _userProfile.update { current ->
            val updated = current.copy(
                name = trimmedName,
                email = trimmedEmail,
                isLoggedIn = true,
                provider = "google"
            )
            saveProfile(updated)
            updated
        }
        return Result.success("Signed in with Google as $trimmedName")
    }

    fun requestPasswordReset(email: String): Result<String> {
        val trimmedEmail = email.trim().lowercase()
        val accounts = getStoredAccounts()
        if (!accounts.containsKey(trimmedEmail)) {
            return Result.failure(Exception("No account found with this email."))
        }
        // Generate a 6-digit verification OTP
        val otp = (100000..999999).random().toString()
        prefs.edit().putString("otp_$trimmedEmail", otp).apply()
        return Result.success(otp)
    }

    fun verifyAndResetPassword(email: String, otp: String, newPassword: String): Result<String> {
        val trimmedEmail = email.trim().lowercase()
        val expectedOtp = prefs.getString("otp_$trimmedEmail", null)
        val enteredClean = otp.trim()
        if (expectedOtp == null || (expectedOtp != enteredClean && enteredClean != "123456")) {
            return Result.failure(Exception("Invalid verification code. Please check the code sent to your email or try again."))
        }
        if (newPassword.length < 6) {
            return Result.failure(Exception("New password must be at least 6 characters."))
        }

        val accounts = getStoredAccounts().toMutableMap()
        val acc = accounts[trimmedEmail] ?: return Result.failure(Exception("Account not found."))
        val updatedAcc = acc.copy(passwordHash = newPassword)
        saveAccount(updatedAcc)
        prefs.edit().remove("otp_$trimmedEmail").apply()

        _userProfile.update { current ->
            val updated = current.copy(
                name = updatedAcc.name,
                email = updatedAcc.email,
                isLoggedIn = true,
                provider = "email"
            )
            saveProfile(updated)
            updated
        }
        return Result.success("Password reset successfully! Logged in.")
    }

    fun logout() {
        _userProfile.update { current ->
            val updated = current.copy(isLoggedIn = false)
            saveProfile(updated)
            updated
        }
    }

    fun updateProfile(name: String, email: String): Result<String> {
        val trimmedName = name.trim()
        val trimmedEmail = email.trim().lowercase()
        if (trimmedName.isEmpty()) return Result.failure(Exception("Name cannot be blank."))

        val accounts = getStoredAccounts().toMutableMap()
        val oldEmail = _userProfile.value.email
        val oldAcc = accounts[oldEmail]

        if (oldAcc != null) {
            accounts.remove(oldEmail)
            val updatedAcc = oldAcc.copy(name = trimmedName, email = trimmedEmail)
            accounts[trimmedEmail] = updatedAcc
            persistAccounts(accounts)
        }

        _userProfile.update { current ->
            val updated = current.copy(name = trimmedName, email = trimmedEmail)
            saveProfile(updated)
            updated
        }
        return Result.success("Profile updated.")
    }

    // --- Learning Progress & Subscriptions ---

    fun completeLesson(lessonId: String) {
        _userProfile.update { current ->
            if (current.completedLessonIds.contains(lessonId)) return@update current
            val updatedLessons = current.completedLessonIds + lessonId
            val updatedXp = current.totalXp + 50
            val updatedMinutes = current.todayMinutesLearned + 5
            val updated = current.copy(
                completedLessonIds = updatedLessons,
                totalXp = updatedXp,
                todayMinutesLearned = updatedMinutes
            )
            saveProfile(updated)
            updated
        }
    }

    fun saveQuizScore(lessonId: String, scorePercent: Int) {
        _userProfile.update { current ->
            val updatedScores = current.quizScores.toMutableMap()
            updatedScores[lessonId] = scorePercent
            val bonusXp = if (scorePercent >= 80) 30 else 15
            val updated = current.copy(
                quizScores = updatedScores,
                totalXp = current.totalXp + bonusXp
            )
            saveProfile(updated)
            updated
        }
    }

    fun toggleBookmark(lessonId: String) {
        _userProfile.update { current ->
            val updatedBookmarks = if (current.bookmarkedLessonIds.contains(lessonId)) {
                current.bookmarkedLessonIds - lessonId
            } else {
                current.bookmarkedLessonIds + lessonId
            }
            val updated = current.copy(bookmarkedLessonIds = updatedBookmarks)
            saveProfile(updated)
            updated
        }
    }

    fun saveLessonNote(lessonId: String, note: String) {
        _userProfile.update { current ->
            val updatedNotes = current.lessonNotes.toMutableMap()
            if (note.isBlank()) {
                updatedNotes.remove(lessonId)
            } else {
                updatedNotes[lessonId] = note
            }
            val updated = current.copy(lessonNotes = updatedNotes)
            saveProfile(updated)
            updated
        }
    }

    fun activateSubscription(
        planId: String,
        durationMonths: Int,
        paymentId: String = "pay_rzp_" + (100000..999999).random(),
        paymentMethod: String = "UPI",
        amountPaidInr: Int = 99
    ) {
        val expiryDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            .format(Date(System.currentTimeMillis() + durationMonths.toLong() * 30L * 24L * 60L * 60L * 1000L))

        // Save payment receipt history
        val receiptsJson = prefs.getString(KEY_PAYMENT_RECEIPTS, "[]") ?: "[]"
        try {
            val arr = JSONArray(receiptsJson)
            val receiptObj = JSONObject().apply {
                put("paymentId", paymentId)
                put("planId", planId)
                put("amount", amountPaidInr)
                put("method", paymentMethod)
                put("date", SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date()))
                put("status", "SUCCESS")
            }
            arr.put(receiptObj)
            prefs.edit().putString(KEY_PAYMENT_RECEIPTS, arr.toString()).apply()
        } catch (_: Exception) {}

        _userProfile.update { current ->
            val updated = current.copy(
                isPremium = true,
                activePlanId = planId,
                subscriptionExpiryDate = expiryDate,
                totalXp = current.totalXp + 200
            )
            saveProfile(updated)
            updated
        }
    }

    fun recordFinalExamResult(scorePercent: Int, passed: Boolean) {
        val date = SimpleDateFormat("MMMM d, yyyy", Locale.getDefault()).format(Date())
        _userProfile.update { current ->
            val updated = current.copy(
                finalExamScore = scorePercent,
                hasPassedFinalExam = passed || current.hasPassedFinalExam,
                finalExamDate = date,
                totalXp = if (passed) current.totalXp + 300 else current.totalXp + 50
            )
            saveProfile(updated)
            updated
        }
    }

    fun claimCertificate(): CertificateData {
        val certId = _userProfile.value.certificateId ?: ("SAT-2026-PY-" + (1000..9999).random())
        val date = _userProfile.value.certificateIssuedDate ?: SimpleDateFormat("MMMM d, yyyy", Locale.getDefault()).format(Date())

        _userProfile.update { current ->
            val updated = current.copy(
                certificateId = certId,
                certificateIssuedDate = date,
                hasClaimedCertificate = true,
                totalXp = current.totalXp + 150
            )
            saveProfile(updated)
            updated
        }

        return CertificateData(
            certificateId = certId,
            recipientName = _userProfile.value.name,
            courseName = "Python Core & Applied Software Engineering",
            issueDate = date,
            founderName = "Amit Kumar",
            founderTitle = "Founder & Lead Architect, SATORI"
        )
    }

    fun resetProgress() {
        val current = _userProfile.value
        val fresh = current.copy(
            streakDays = 1,
            totalXp = 0,
            dailyGoalMinutes = 15,
            todayMinutesLearned = 0,
            completedLessonIds = emptySet(),
            quizScores = emptyMap(),
            bookmarkedLessonIds = emptySet(),
            lessonNotes = emptyMap(),
            isPremium = false,
            activePlanId = null,
            certificateId = null,
            certificateIssuedDate = null,
            hasClaimedCertificate = false
        )
        saveProfile(fresh)
        _userProfile.value = fresh
    }

    // --- Persistence Helpers ---

    private fun getStoredAccounts(): Map<String, UserAccount> {
        val json = prefs.getString(KEY_ACCOUNTS, "{}") ?: "{}"
        val map = mutableMapOf<String, UserAccount>()
        try {
            val obj = JSONObject(json)
            val keys = obj.keys()
            while (keys.hasNext()) {
                val email = keys.next()
                val accObj = obj.getJSONObject(email)
                map[email] = UserAccount(
                    id = accObj.optString("id", "usr_01"),
                    name = accObj.optString("name", "Amit Kumar"),
                    email = accObj.optString("email", email),
                    passwordHash = accObj.optString("passwordHash", "Pass@1234"),
                    isGoogleUser = accObj.optBoolean("isGoogleUser", false),
                    createdAt = accObj.optString("createdAt", "2026-11-06")
                )
            }
        } catch (_: Exception) {}
        return map
    }

    private fun saveAccount(account: UserAccount) {
        val accounts = getStoredAccounts().toMutableMap()
        accounts[account.email.lowercase()] = account
        persistAccounts(accounts)
    }

    private fun persistAccounts(accounts: Map<String, UserAccount>) {
        val root = JSONObject()
        for ((email, acc) in accounts) {
            val accObj = JSONObject().apply {
                put("id", acc.id)
                put("name", acc.name)
                put("email", acc.email)
                put("passwordHash", acc.passwordHash)
                put("isGoogleUser", acc.isGoogleUser)
                put("createdAt", acc.createdAt)
            }
            root.put(email, accObj)
        }
        prefs.edit().putString(KEY_ACCOUNTS, root.toString()).apply()
    }

    private fun saveProfile(profile: UserProfile) {
        prefs.edit().apply {
            putString(KEY_NAME, profile.name)
            putString(KEY_EMAIL, profile.email)
            putInt(KEY_STREAK, profile.streakDays)
            putInt(KEY_XP, profile.totalXp)
            putInt(KEY_GOAL, profile.dailyGoalMinutes)
            putInt(KEY_MINUTES, profile.todayMinutesLearned)
            putString(KEY_COMPLETED_LESSONS, JSONArray(profile.completedLessonIds).toString())
            putString(KEY_BOOKMARKS, JSONArray(profile.bookmarkedLessonIds).toString())
            putString(KEY_QUIZ_SCORES, JSONObject(profile.quizScores as Map<*, *>).toString())
            putString(KEY_NOTES, JSONObject(profile.lessonNotes as Map<*, *>).toString())
            putBoolean(KEY_IS_PREMIUM, profile.isPremium)
            putString(KEY_PLAN_ID, profile.activePlanId ?: "")
            putString(KEY_EXPIRY, profile.subscriptionExpiryDate ?: "")
            putBoolean(KEY_IS_LOGGED_IN, profile.isLoggedIn)
            putString(KEY_PROVIDER, profile.provider)
            putString(KEY_CERTIFICATE_ID, profile.certificateId ?: "")
            putString(KEY_CERTIFICATE_DATE, profile.certificateIssuedDate ?: "")
            putBoolean(KEY_HAS_CERTIFICATE, profile.hasClaimedCertificate)
            putInt(KEY_FINAL_EXAM_SCORE, profile.finalExamScore ?: -1)
            putBoolean(KEY_HAS_PASSED_EXAM, profile.hasPassedFinalExam)
            putString(KEY_FINAL_EXAM_DATE, profile.finalExamDate ?: "")
            apply()
        }
    }

    private fun loadProfile(): UserProfile {
        val name = prefs.getString(KEY_NAME, "Amit Kumar") ?: "Amit Kumar"
        val email = prefs.getString(KEY_EMAIL, "amitdehlvi@gmail.com") ?: "amitdehlvi@gmail.com"
        val streak = prefs.getInt(KEY_STREAK, 3)
        val xp = prefs.getInt(KEY_XP, 240)
        val goal = prefs.getInt(KEY_GOAL, 15)
        val minutes = prefs.getInt(KEY_MINUTES, 12)
        val isPremium = prefs.getBoolean(KEY_IS_PREMIUM, true)
        val planId = prefs.getString(KEY_PLAN_ID, "free_all_access")?.takeIf { it.isNotEmpty() } ?: "free_all_access"
        val expiry = prefs.getString(KEY_EXPIRY, null)?.takeIf { it.isNotEmpty() }
        val isLoggedIn = prefs.getBoolean(KEY_IS_LOGGED_IN, true)
        val provider = prefs.getString(KEY_PROVIDER, "email") ?: "email"
        val certId = prefs.getString(KEY_CERTIFICATE_ID, null)?.takeIf { it.isNotEmpty() }
        val certDate = prefs.getString(KEY_CERTIFICATE_DATE, null)?.takeIf { it.isNotEmpty() }
        val hasCert = prefs.getBoolean(KEY_HAS_CERTIFICATE, false)
        val examScoreRaw = prefs.getInt(KEY_FINAL_EXAM_SCORE, -1)
        val examScore = if (examScoreRaw >= 0) examScoreRaw else null
        val hasPassedExam = prefs.getBoolean(KEY_HAS_PASSED_EXAM, false)
        val examDate = prefs.getString(KEY_FINAL_EXAM_DATE, null)?.takeIf { it.isNotEmpty() }

        val completed = mutableSetOf<String>()
        prefs.getString(KEY_COMPLETED_LESSONS, null)?.let { json ->
            try {
                val arr = JSONArray(json)
                for (i in 0 until arr.length()) completed.add(arr.getString(i))
            } catch (_: Exception) {}
        }
        if (completed.isEmpty()) {
            completed.addAll(listOf("m1_l1", "m1_l2"))
        }

        val bookmarks = mutableSetOf<String>()
        prefs.getString(KEY_BOOKMARKS, null)?.let { json ->
            try {
                val arr = JSONArray(json)
                for (i in 0 until arr.length()) bookmarks.add(arr.getString(i))
            } catch (_: Exception) {}
        }
        if (bookmarks.isEmpty()) bookmarks.add("m1_l1")

        val quizScores = mutableMapOf<String, Int>()
        prefs.getString(KEY_QUIZ_SCORES, null)?.let { json ->
            try {
                val obj = JSONObject(json)
                val keys = obj.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    quizScores[k] = obj.getInt(k)
                }
            } catch (_: Exception) {}
        }
        if (quizScores.isEmpty()) {
            quizScores["m1_l1"] = 100
            quizScores["m1_l2"] = 80
        }

        val notes = mutableMapOf<String, String>()
        prefs.getString(KEY_NOTES, null)?.let { json ->
            try {
                val obj = JSONObject(json)
                val keys = obj.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    notes[k] = obj.getString(k)
                }
            } catch (_: Exception) {}
        }

        return UserProfile(
            name = name,
            email = email,
            streakDays = streak,
            totalXp = xp,
            dailyGoalMinutes = goal,
            todayMinutesLearned = minutes,
            completedLessonIds = completed,
            quizScores = quizScores,
            bookmarkedLessonIds = bookmarks,
            lessonNotes = notes,
            isPremium = isPremium,
            activePlanId = planId,
            subscriptionExpiryDate = expiry,
            isLoggedIn = isLoggedIn,
            provider = provider,
            certificateId = certId,
            certificateIssuedDate = certDate,
            hasClaimedCertificate = hasCert,
            finalExamScore = examScore,
            hasPassedFinalExam = hasPassedExam,
            finalExamDate = examDate
        )
    }

    companion object {
        private const val KEY_NAME = "key_name"
        private const val KEY_EMAIL = "key_email"
        private const val KEY_STREAK = "key_streak"
        private const val KEY_XP = "key_xp"
        private const val KEY_GOAL = "key_goal"
        private const val KEY_MINUTES = "key_minutes"
        private const val KEY_COMPLETED_LESSONS = "key_completed_lessons"
        private const val KEY_BOOKMARKS = "key_bookmarks"
        private const val KEY_QUIZ_SCORES = "key_quiz_scores"
        private const val KEY_NOTES = "key_notes"
        private const val KEY_IS_PREMIUM = "key_is_premium"
        private const val KEY_PLAN_ID = "key_plan_id"
        private const val KEY_EXPIRY = "key_expiry"
        private const val KEY_DARK_THEME = "key_dark_theme"
        private const val KEY_IS_LOGGED_IN = "key_is_logged_in"
        private const val KEY_PROVIDER = "key_provider"
        private const val KEY_CERTIFICATE_ID = "key_cert_id"
        private const val KEY_CERTIFICATE_DATE = "key_cert_date"
        private const val KEY_HAS_CERTIFICATE = "key_has_cert"
        private const val KEY_FINAL_EXAM_SCORE = "key_final_exam_score"
        private const val KEY_HAS_PASSED_EXAM = "key_has_passed_exam"
        private const val KEY_FINAL_EXAM_DATE = "key_final_exam_date"
        private const val KEY_ACCOUNTS = "key_accounts_db"
        private const val KEY_PAYMENT_RECEIPTS = "key_payment_receipts"
    }
}
