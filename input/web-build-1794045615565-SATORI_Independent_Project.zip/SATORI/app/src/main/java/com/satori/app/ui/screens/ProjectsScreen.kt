package com.satori.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.satori.app.data.ReferenceRepository
import com.satori.app.model.GuidedProject
import com.satori.app.model.UserProfile
import com.satori.app.ui.components.PythonEditor
import com.satori.app.ui.theme.*

@Composable
fun ProjectsScreen(
    userProfile: UserProfile,
    onOpenSubscription: () -> Unit,
    modifier: Modifier = Modifier
) {
    val projects = ReferenceRepository.guidedProjects
    var selectedProject by remember { mutableStateOf<GuidedProject?>(projects.first()) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("projects_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Guided Projects",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Apply your knowledge by building complete, functional Python software.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SatoriTextSecondary,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        // Project selector pills
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                projects.forEach { proj ->
                    val isSelected = selectedProject?.id == proj.id
                    val isLocked = false
                    FilterChip(
                        selected = isSelected,
                        onClick = {
                            selectedProject = proj
                        },
                        label = {
                            Text(proj.title, fontSize = 12.sp)
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SatoriIndigo,
                            selectedLabelColor = Color.White,
                            containerColor = SatoriSurfaceDark,
                            labelColor = SatoriTextSecondary
                        ),
                        border = null
                    )
                }
            }
        }

        selectedProject?.let { proj ->
            val isLocked = false

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = SatoriSurfaceDark),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = SatoriIndigo.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = proj.category.uppercase(),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SatoriNeonSpark,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Text(
                                text = "${proj.estimatedMinutes} mins • ${proj.difficulty.name}",
                                fontSize = 11.sp,
                                color = SatoriTextSecondary
                            )
                        }

                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = proj.title,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = proj.description,
                            fontSize = 13.sp,
                            color = SatoriTextSecondary,
                            lineHeight = 19.sp,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }

            if (isLocked) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SatoriSurfaceContainerDark),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = SatoriPythonGold, modifier = Modifier.size(36.dp))
                            Spacer(Modifier.height(8.dp))
                            Text("SATORI Pro Required", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
                            Text(
                                "Unlock all guided projects, complete code solutions, and step-by-step architectures with SATORI Pro.",
                                fontSize = 12.sp,
                                color = SatoriTextSecondary,
                                modifier = Modifier.padding(vertical = 6.dp)
                            )
                            Button(
                                onClick = onOpenSubscription,
                                colors = ButtonDefaults.buttonColors(containerColor = SatoriPythonGold)
                            ) {
                                Text("View Subscription Plans", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else {
                // Steps
                item {
                    Text("Implementation Blueprint", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
                    Spacer(Modifier.height(8.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        proj.steps.forEach { step ->
                            Surface(
                                color = SatoriSurfaceContainerDark,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.Top,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .background(SatoriIndigo, CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("${step.stepNumber}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                    }
                                    Column {
                                        Text(step.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                                        Text(step.instruction, fontSize = 11.sp, color = SatoriTextSecondary)
                                    }
                                }
                            }
                        }
                    }
                }

                // Interactive Project Code Runner
                item {
                    Text("Project Code Workspace", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
                    Spacer(Modifier.height(6.dp))
                    PythonEditor(initialCode = proj.starterCode)
                }
            }
        }
    }
}
