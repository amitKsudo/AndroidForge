package com.satori.app.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.satori.app.data.ReferenceRepository
import com.satori.app.model.CheatsheetItem
import com.satori.app.ui.theme.*

@Composable
fun CheatsheetScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }

    val allItems = ReferenceRepository.cheatsheetItems
    val filteredItems = allItems.filter { item ->
        val matchesCategory = selectedCategory == "All" || item.category == selectedCategory
        val matchesSearch = searchQuery.isBlank() ||
                item.title.contains(searchQuery, ignoreCase = true) ||
                item.syntax.contains(searchQuery, ignoreCase = true) ||
                item.description.contains(searchQuery, ignoreCase = true)
        matchesCategory && matchesSearch
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("cheatsheet_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Python Cheatsheet",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Quick, searchable reference library with syntax and runnable examples.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SatoriTextSecondary,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        // Search Field
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search syntax, functions, methods...", fontSize = 13.sp, color = SatoriTextMuted) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = SatoriTextSecondary) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = SatoriTextSecondary)
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("cheatsheet_search_input"),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = SatoriIndigo,
                    unfocusedBorderColor = SatoriBorderDark,
                    focusedContainerColor = SatoriSurfaceDark,
                    unfocusedContainerColor = SatoriSurfaceDark,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                singleLine = true
            )
        }

        // Category Filter Carousel
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(ReferenceRepository.cheatsheetCategories) { cat ->
                    val isSelected = selectedCategory == cat
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SatoriIndigo,
                            selectedLabelColor = Color.White,
                            containerColor = SatoriSurfaceDark,
                            labelColor = SatoriTextSecondary
                        ),
                        border = null
                    )
                }
            }
        }

        // Results count
        item {
            Text(
                text = "${filteredItems.size} references found",
                fontSize = 12.sp,
                color = SatoriNeonSpark,
                fontWeight = FontWeight.SemiBold
            )
        }

        // Cheatsheet Cards
        items(filteredItems) { item ->
            CheatsheetCard(
                item = item,
                onCopy = {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("python_code", item.codeExample))
                    Toast.makeText(context, "Copied ${item.title} code!", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }
}

@Composable
fun CheatsheetCard(item: CheatsheetItem, onCopy: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("cheatsheet_item_${item.id}"),
        colors = CardDefaults.cardColors(containerColor = SatoriSurfaceDark),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Surface(
                        color = SatoriIndigo.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = item.category.uppercase(),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = SatoriNeonSpark,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Text(
                        text = item.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color.White,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }

                IconButton(onClick = onCopy, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy code", tint = SatoriTextSecondary, modifier = Modifier.size(16.dp))
                }
            }

            Text(
                text = item.description,
                fontSize = 12.sp,
                color = SatoriTextSecondary,
                lineHeight = 18.sp,
                modifier = Modifier.padding(vertical = 6.dp)
            )

            // Syntax Box
            Surface(
                color = SatoriSurfaceContainerDark,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = item.syntax,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    color = SatoriPythonCyan,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }

            Spacer(Modifier.height(8.dp))

            // Code Example with Expected Output
            Surface(
                color = SatoriCodeBackground,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = item.codeExample,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        color = SatoriTextPrimary,
                        lineHeight = 18.sp
                    )
                    HorizontalDivider(color = SatoriBorderDark, modifier = Modifier.padding(vertical = 6.dp))
                    Text(
                        text = "Output: ${item.expectedOutput}",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = SatoriSuccessGreen
                    )
                }
            }
        }
    }
}
