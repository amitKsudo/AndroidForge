package com.satori.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = SatoriIndigo,
    onPrimary = Color.White,
    primaryContainer = SatoriSurfaceContainerDark,
    onPrimaryContainer = SatoriNeonSpark,
    secondary = SatoriPurple,
    onSecondary = Color.White,
    secondaryContainer = SatoriSurfaceHighlightDark,
    onSecondaryContainer = SatoriTextPrimary,
    tertiary = SatoriPythonGold,
    onTertiary = Color.Black,
    background = SatoriDeepViolet,
    onBackground = SatoriTextPrimary,
    surface = SatoriSurfaceDark,
    onSurface = SatoriTextPrimary,
    surfaceVariant = SatoriSurfaceContainerDark,
    onSurfaceVariant = SatoriTextSecondary,
    outline = SatoriBorderDark,
    error = SatoriErrorRed,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = SatoriIndigo,
    onPrimary = Color.White,
    primaryContainer = SatoriLightSurfaceContainer,
    onPrimaryContainer = SatoriIndigo,
    secondary = SatoriPurple,
    onSecondary = Color.White,
    secondaryContainer = SatoriLightSurfaceContainer,
    onSecondaryContainer = SatoriLightTextPrimary,
    tertiary = SatoriPythonGold,
    onTertiary = Color.Black,
    background = SatoriLightBackground,
    onBackground = SatoriLightTextPrimary,
    surface = SatoriLightSurface,
    onSurface = SatoriLightTextPrimary,
    surfaceVariant = SatoriLightSurfaceContainer,
    onSurfaceVariant = SatoriLightTextSecondary,
    outline = SatoriLightBorder,
    error = SatoriErrorRed,
    onError = Color.White
)

@Composable
fun SatoriTheme(
    darkTheme: Boolean = true, // Default to premium dark aesthetic
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
