package com.satori.app.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.satori.app.data.ExamRepository
import com.satori.app.model.Difficulty
import com.satori.app.model.ExamQuestion
import com.satori.app.ui.theme.*
import com.satori.app.util.AudioFeedbackManager
import kotlinx.coroutines.delay

@Composable
fun FinalExamScreen(
    onExamPassed: (scorePercent: Int) -> Unit,
    onExamFailed: (scorePercent: Int) -> Unit,
    onNavigateBack: () -> Unit,
    onViewCertificate: () -> Unit,
    modifier: Modifier = Modifier
) {
    val questions = remember { ExamRepository.finalExamQuestions }
    val userAnswers = remember { mutableStateMapOf<Int, Int>() } // questionId -> selectedOptionIndex
    var currentQuestionIndex by remember { mutableStateOf(0) }
    var isSubmitted by remember { mutableStateOf(false) }
    var showSubmitConfirmation by remember { mutableStateOf(false) }
    var showExitConfirmation by remember { mutableStateOf(false) }

    // 45-Minute Exam Countdown Timer (2700 seconds)
    var remainingSeconds by remember { mutableStateOf(45 * 60) }

    LaunchedEffect(isSubmitted) {
        if (!isSubmitted) {
            while (remainingSeconds > 0) {
                delay(1000L)
                remainingSeconds--
            }
            if (remainingSeconds == 0 && !isSubmitted) {
                isSubmitted = true
            }
        }
    }

    val currentQuestion = questions[currentQuestionIndex]
    val answeredCount = userAnswers.size

    val score = remember(isSubmitted) {
        if (isSubmitted) {
            questions.count { q -> userAnswers[q.id] == q.correctIndex }
        } else 0
    }
    val scorePercent = remember(isSubmitted) {
        if (isSubmitted) ((score.toFloat() / questions.size.toFloat()) * 100).toInt() else 0
    }
    val hasPassed = scorePercent >= 67

    LaunchedEffect(isSubmitted) {
        if (isSubmitted) {
            if (hasPassed) {
                AudioFeedbackManager.playQuizComplete()
                onExamPassed(scorePercent)
            } else {
                onExamFailed(scorePercent)
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SatoriDeepViolet)
            .testTag("final_exam_screen")
    ) {
        // --- STICKY TOP BAR ---
        Surface(
            color = SatoriSurfaceDark,
            shadowElevation = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconButton(
                            onClick = {
                                if (!isSubmitted) showExitConfirmation = true else onNavigateBack()
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = SatoriTextSecondary)
                        }
                        Column {
                            Text(
                                text = "Final Comprehensive Examination",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "50 Questions • 67% Passing Grade",
                                fontSize = 11.sp,
                                color = SatoriTextSecondary
                            )
                        }
                    }

                    // Timer Chip
                    val minutes = remainingSeconds / 60
                    val seconds = remainingSeconds % 60
                    val timerText = String.format("%02d:%02d", minutes, seconds)
                    Surface(
                        color = if (remainingSeconds < 300) SatoriErrorRed.copy(alpha = 0.2f) else SatoriIndigo.copy(alpha = 0.25f),
                        shape = RoundedCornerShape(8.dp),
                        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(if (remainingSeconds < 300) SatoriErrorRed else SatoriIndigo, if (remainingSeconds < 300) SatoriErrorRed else SatoriIndigo)))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                Icons.Default.Timer,
                                contentDescription = null,
                                tint = if (remainingSeconds < 300) SatoriErrorRed else SatoriNeonSpark,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = timerText,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = if (remainingSeconds < 300) SatoriErrorRed else Color.White
                            )
                        }
                    }
                }

                if (!isSubmitted) {
                    Spacer(Modifier.height(8.dp))
                    // Question Numbers Strip (Jump to any question 1..50)
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        itemsIndexed(questions) { idx, q ->
                            val isCurrent = idx == currentQuestionIndex
                            val isAnswered = userAnswers.containsKey(q.id)

                            Box(
                                modifier = Modifier
                                    .size(30.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when {
                                            isCurrent -> SatoriIndigo
                                            isAnswered -> SatoriSuccessGreen.copy(alpha = 0.35f)
                                            else -> SatoriSurfaceHighlightDark
                                        }
                                    )
                                    .border(
                                        width = if (isCurrent) 1.5.dp else 0.5.dp,
                                        color = if (isCurrent) Color.White else if (isAnswered) SatoriSuccessGreen else SatoriBorderDark,
                                        shape = CircleShape
                                    )
                                    .clickable { currentQuestionIndex = idx },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${idx + 1}",
                                    fontSize = 11.sp,
                                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isCurrent || isAnswered) Color.White else SatoriTextSecondary
                                )
                            }
                        }
                    }
                }
            }
        }

        // --- EXAM CONTENT BODY ---
        if (isSubmitted) {
            // RESULT SUMMARY & REVIEW SCREEN
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = SatoriSurfaceDark),
                        border = CardDefaults.outlinedCardBorder().copy(
                            brush = Brush.horizontalGradient(
                                if (hasPassed) listOf(SatoriSuccessGreen, SatoriPythonGold) else listOf(SatoriErrorRed, SatoriWarningOrange)
                            )
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Surface(
                                color = if (hasPassed) SatoriSuccessGreen.copy(alpha = 0.2f) else SatoriErrorRed.copy(alpha = 0.2f),
                                shape = CircleShape,
                                modifier = Modifier.size(64.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = if (hasPassed) Icons.Default.CheckCircle else Icons.Default.Cancel,
                                        contentDescription = null,
                                        tint = if (hasPassed) SatoriSuccessGreen else SatoriErrorRed,
                                        modifier = Modifier.size(38.dp)
                                    )
                                }
                            }

                            Spacer(Modifier.height(14.dp))

                            Text(
                                text = if (hasPassed) "EXAMINATION PASSED" else "MINIMUM PASSING SCORE NOT MET",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp,
                                color = if (hasPassed) SatoriSuccessGreen else SatoriErrorRed
                            )

                            Text(
                                text = "$score of 50 Questions Correct ($scorePercent%)",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(top = 4.dp)
                            )

                            Text(
                                text = if (hasPassed)
                                    "Congratulations. You have demonstrated comprehensive technical proficiency (67%+ required) and qualified for official certification."
                                else
                                    "A minimum score of 67% (34 of 50 correct) is strictly required to qualify for the SATORI credential. You may review your answers below and retake the examination.",
                                fontSize = 12.sp,
                                color = SatoriTextSecondary,
                                textAlign = TextAlign.Center,
                                lineHeight = 18.sp,
                                modifier = Modifier.padding(vertical = 10.dp)
                            )

                            if (hasPassed) {
                                Button(
                                    onClick = onViewCertificate,
                                    colors = ButtonDefaults.buttonColors(containerColor = SatoriIndigo),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth().height(48.dp)
                                ) {
                                    Icon(Icons.Default.School, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text("View Official Certificate", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                }
                            } else {
                                Button(
                                    onClick = {
                                        userAnswers.clear()
                                        currentQuestionIndex = 0
                                        remainingSeconds = 45 * 60
                                        isSubmitted = false
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = SatoriIndigo),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth().height(48.dp)
                                ) {
                                    Icon(Icons.Default.Replay, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text("Retake Examination", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                }
                            }
                        }
                    }
                }

                // Detailed Review of all 50 questions
                item {
                    Text(
                        text = "Examination Review (50 Questions)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                itemsIndexed(questions) { index, q ->
                    val userChoice = userAnswers[q.id]
                    val isCorrect = userChoice == q.correctIndex

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = SatoriSurfaceDark),
                        shape = RoundedCornerShape(12.dp),
                        border = CardDefaults.outlinedCardBorder().copy(
                            brush = Brush.horizontalGradient(
                                if (isCorrect) listOf(SatoriSuccessGreen.copy(alpha = 0.5f), SatoriSuccessGreen.copy(alpha = 0.2f))
                                else listOf(SatoriErrorRed.copy(alpha = 0.5f), SatoriErrorRed.copy(alpha = 0.2f))
                            )
                        )
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Question ${index + 1}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SatoriTextSecondary
                                )
                                Surface(
                                    color = if (isCorrect) SatoriSuccessGreen.copy(alpha = 0.2f) else SatoriErrorRed.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = if (isCorrect) "CORRECT" else "INCORRECT",
                                        color = if (isCorrect) SatoriSuccessGreen else SatoriErrorRed,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Text(
                                text = q.question,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White,
                                modifier = Modifier.padding(vertical = 6.dp)
                            )

                            q.codeSnippet?.let { snippet ->
                                Surface(
                                    color = Color(0xFF090414),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                                ) {
                                    Text(
                                        text = snippet,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 12.sp,
                                        color = SatoriPythonCyan,
                                        modifier = Modifier.padding(10.dp)
                                    )
                                }
                            }

                            Text(
                                text = "Your Answer: ${userChoice?.let { q.options.getOrNull(it) } ?: "Not Answered"}",
                                fontSize = 12.sp,
                                color = if (isCorrect) SatoriSuccessGreen else SatoriErrorRed,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(top = 4.dp)
                            )

                            if (!isCorrect) {
                                Text(
                                    text = "Correct Answer: ${q.options[q.correctIndex]}",
                                    fontSize = 12.sp,
                                    color = SatoriSuccessGreen,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(top = 2.dp)
                                )
                            }

                            Text(
                                text = q.explanation,
                                fontSize = 11.sp,
                                color = SatoriTextSecondary,
                                modifier = Modifier.padding(top = 6.dp)
                            )
                        }
                    }
                }
            }
        } else {
            // ACTIVE EXAM QUESTION
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    // Question Header Card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = SatoriSurfaceDark),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    color = SatoriIndigo.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = currentQuestion.category.uppercase(),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = SatoriNeonSpark,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Text(
                                    text = "Question ${currentQuestionIndex + 1} of ${questions.size}",
                                    fontSize = 12.sp,
                                    color = SatoriTextSecondary,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            Spacer(Modifier.height(8.dp))

                            Text(
                                text = currentQuestion.question,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                lineHeight = 22.sp
                            )

                            // Optional Code Snippet for Output-Type Questions
                            currentQuestion.codeSnippet?.let { snippet ->
                                Spacer(Modifier.height(10.dp))
                                Surface(
                                    color = Color(0xFF0A0517),
                                    shape = RoundedCornerShape(8.dp),
                                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(SatoriIndigo.copy(alpha = 0.5f), SatoriPurple.copy(alpha = 0.5f)))),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = snippet,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 13.sp,
                                        color = SatoriPythonCyan,
                                        modifier = Modifier.padding(12.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // Options
                item {
                    val selectedOption = userAnswers[currentQuestion.id]
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        currentQuestion.options.forEachIndexed { optIndex, optionText ->
                            val isSelected = selectedOption == optIndex

                            Surface(
                                color = if (isSelected) SatoriIndigo.copy(alpha = 0.25f) else SatoriSurfaceDark,
                                shape = RoundedCornerShape(12.dp),
                                border = CardDefaults.outlinedCardBorder().copy(
                                    brush = Brush.linearGradient(
                                        if (isSelected) listOf(SatoriIndigo, SatoriPurple) else listOf(SatoriBorderDark, SatoriBorderDark)
                                    )
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { userAnswers[currentQuestion.id] = optIndex }
                                    .testTag("exam_option_$optIndex")
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(CircleShape)
                                            .background(if (isSelected) SatoriIndigo else SatoriSurfaceHighlightDark)
                                            .border(1.dp, if (isSelected) Color.White else SatoriBorderDark, CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = ('A' + optIndex).toString(),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) Color.White else SatoriTextSecondary
                                        )
                                    }

                                    Text(
                                        text = optionText,
                                        fontSize = 13.sp,
                                        color = SatoriTextPrimary,
                                        lineHeight = 19.sp,
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // --- BOTTOM ACTIONS (PREV, NEXT, SUBMIT) ---
            Surface(
                color = SatoriSurfaceDark,
                shadowElevation = 8.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = {
                            if (currentQuestionIndex > 0) currentQuestionIndex--
                        },
                        enabled = currentQuestionIndex > 0,
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Previous")
                    }

                    Text(
                        text = "$answeredCount of 50 Answered",
                        fontSize = 12.sp,
                        color = SatoriTextSecondary
                    )

                    if (currentQuestionIndex < questions.size - 1) {
                        Button(
                            onClick = { currentQuestionIndex++ },
                            colors = ButtonDefaults.buttonColors(containerColor = SatoriIndigo),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Next")
                        }
                    } else {
                        Button(
                            onClick = { showSubmitConfirmation = true },
                            colors = ButtonDefaults.buttonColors(containerColor = SatoriSuccessGreen),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Submit Exam", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Submit Confirmation Dialog
    if (showSubmitConfirmation) {
        AlertDialog(
            onDismissRequest = { showSubmitConfirmation = false },
            title = { Text("Submit Examination?", fontWeight = FontWeight.Bold, color = Color.White) },
            text = {
                Text(
                    text = "You have answered $answeredCount of 50 questions. Once submitted, your score will be calculated and verified against the 67% passing threshold.",
                    fontSize = 13.sp,
                    color = SatoriTextPrimary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSubmitConfirmation = false
                        isSubmitted = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SatoriSuccessGreen)
                ) {
                    Text("Confirm & Submit", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSubmitConfirmation = false }) {
                    Text("Review More", color = SatoriTextSecondary)
                }
            },
            containerColor = SatoriSurfaceDark
        )
    }

    // Exit Confirmation Dialog
    if (showExitConfirmation) {
        AlertDialog(
            onDismissRequest = { showExitConfirmation = false },
            title = { Text("Exit Examination?", fontWeight = FontWeight.Bold, color = SatoriErrorRed) },
            text = {
                Text(
                    text = "Leaving now will forfeit your current exam progress. Are you sure you wish to exit?",
                    fontSize = 13.sp,
                    color = SatoriTextPrimary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showExitConfirmation = false
                        onNavigateBack()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SatoriErrorRed)
                ) {
                    Text("Exit Exam")
                }
            },
            dismissButton = {
                TextButton(onClick = { showExitConfirmation = false }) {
                    Text("Stay in Exam", color = SatoriTextSecondary)
                }
            },
            containerColor = SatoriSurfaceDark
        )
    }
}
