package com.satori.app.util

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

object AudioFeedbackManager {

    private val scope = CoroutineScope(Dispatchers.Default)
    var isSoundEnabled: Boolean = true

    /**
     * Gentle ascending two-note chime for lesson completion
     */
    fun playLessonComplete() {
        if (!isSoundEnabled) return
        scope.launch {
            // E5 (659.25 Hz) then A5 (880.00 Hz) - soft zen bell chime
            playNotes(
                listOf(
                    Tone(659.25, 0.16, 0.55),
                    Tone(880.00, 0.38, 0.75)
                )
            )
        }
    }

    /**
     * Uplifting minimal arpeggio for completing a quiz
     */
    fun playQuizComplete() {
        if (!isSoundEnabled) return
        scope.launch {
            // C5 (523.25), E5 (659.25), G5 (783.99), C6 (1046.50)
            playNotes(
                listOf(
                    Tone(523.25, 0.11, 0.45),
                    Tone(659.25, 0.11, 0.55),
                    Tone(783.99, 0.13, 0.65),
                    Tone(1046.50, 0.35, 0.75)
                )
            )
        }
    }

    /**
     * Crisp, rewarding affirmation chime for passing an interactive code exercise
     */
    fun playExercisePassed() {
        if (!isSoundEnabled) return
        scope.launch {
            // F#5 (739.99 Hz) then B5 (987.77 Hz) - sparkling confirmation
            playNotes(
                listOf(
                    Tone(739.99, 0.13, 0.50),
                    Tone(987.77, 0.35, 0.75)
                )
            )
        }
    }

    private data class Tone(val freqHz: Double, val durationSec: Double, val volume: Double)

    private fun playNotes(tones: List<Tone>) {
        try {
            val sampleRate = 44100
            val totalSamples = tones.sumOf { (it.durationSec * sampleRate).toInt() }
            val pcmData = ShortArray(totalSamples)

            var offset = 0
            for (tone in tones) {
                val toneSamples = (tone.durationSec * sampleRate).toInt()
                for (i in 0 until toneSamples) {
                    val time = i.toDouble() / sampleRate
                    // Sine wave with soft harmonic overtone for pleasant warmth (marimba/bell feel)
                    val baseWave = sin(2.0 * PI * tone.freqHz * time)
                    val overtone = 0.22 * sin(2.0 * PI * (tone.freqHz * 2) * time)

                    // Smooth envelope: quick 10ms attack, exponential natural decay
                    val attackTime = 0.012
                    val attack = if (time < attackTime) (time / attackTime) else 1.0
                    val decay = exp(-time * (4.2 / tone.durationSec))
                    val envelope = attack * decay

                    val sampleValue = (baseWave + overtone) * tone.volume * envelope * Short.MAX_VALUE
                    val clamped = sampleValue.coerceIn(Short.MIN_VALUE.toDouble(), Short.MAX_VALUE.toDouble()).toInt().toShort()

                    if (offset + i < totalSamples) {
                        pcmData[offset + i] = clamped
                    }
                }
                offset += toneSamples
            }

            val audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(pcmData.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            audioTrack.write(pcmData, 0, pcmData.size)
            audioTrack.play()

            // Release AudioTrack after playback finishes
            val durationMs = (tones.sumOf { it.durationSec } * 1000).toLong() + 100
            Thread.sleep(durationMs)
            audioTrack.stop()
            audioTrack.release()
        } catch (_: Exception) {
            // Non-critical: fail silently if device audio is restricted
        }
    }
}
