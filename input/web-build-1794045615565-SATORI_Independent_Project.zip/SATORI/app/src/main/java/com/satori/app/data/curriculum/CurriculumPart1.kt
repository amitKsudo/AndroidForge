package com.satori.app.data.curriculum

import com.satori.app.model.*

object CurriculumPart1 {

    val modules: List<CourseModule> by lazy {
        listOf(
            createModule1(),
            createModule2(),
            createModule3(),
            createModule4(),
            createModule5()
        )
    }

    private fun createModule1(): CourseModule = CourseModule(
        id = "mod_1",
        number = 1,
        title = "Python Foundations",
        subtitle = "What is code, why Python, running your first line",
        iconName = "foundation",
        isPremium = false,
        estimatedHours = 1.5,
        lessons = listOf(
            Lesson(
                id = "m1_l1",
                moduleId = "mod_1",
                title = "What is Programming?",
                order = 1,
                difficulty = Difficulty.BEGINNER,
                readTimeMinutes = 4,
                isFree = true,
                summary = "Understand what code actually is without confusing technical jargon.",
                whyItMatters = "Computers are incredibly fast but completely mindless. Code is the exact recipe you write to make a computer solve problems for you.",
                analogy = "Think of programming like writing a cooking recipe for a helpful robot chef. If you say 'bake at 350 degrees for 20 minutes', it follows every instruction in order without skipping a beat.",
                explanation = "A computer program is simply a sequential list of clear instructions written in a language the machine can interpret.\n\nComputers cannot think on their own or guess what you mean; they follow commands with 100% literal accuracy. Python was created with a clear philosophy: code should be as clean and readable as everyday English sentences.\n\nWhen you invoke the print() function, Python takes whatever message or calculated result is inside the parentheses, formats it, and transmits it directly to the system console output screen. Every statement is evaluated one after another from top to bottom.",
                syntax = "print(\"Your message here\")",
                exampleCode = "# Welcome to SATORI\nprint(\"Code finally makes sense.\")\nprint(\"Welcome to Python!\")",
                lineByLine = listOf(
                    LineExplanation(1, "# Welcome to SATORI", "A comment! Any line starting with # is ignored by Python. It is a note for human eyes."),
                    LineExplanation(2, "print(\"Code finally makes sense.\")", "The print() function tells Python to display whatever text is inside the parentheses onto the screen."),
                    LineExplanation(3, "print(\"Welcome to Python!\")", "A second instruction that outputs a new line right below the first.")
                ),
                expectedOutput = "Code finally makes sense.\nWelcome to Python!",
                visualConceptType = VisualConceptType.NONE,
                commonMistakes = listOf(
                    "Forgetting quotation marks: print(Hello) will cause a NameError because Python thinks Hello is a variable.",
                    "Capitalizing Print(): Python is case-sensitive, so Print() is not recognized—always use lowercase print()."
                ),
                recap = listOf(
                    "Programming is giving precise step-by-step instructions to a computer.",
                    "Python executes commands sequentially from top to bottom.",
                    "print() outputs words and numbers to your console screen."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m1_l1_1",
                        lessonId = "m1_l1",
                        question = "What does the print() function do in Python?",
                        options = listOf(
                            "Sends a document to a physical laser printer",
                            "Displays text or numbers on the screen",
                            "Stores a password in memory",
                            "Deletes files from the hard drive"
                        ),
                        correctIndex = 1,
                        explanation = "In Python, print() outputs whatever information you put between its parentheses onto your terminal or display.",
                        topic = "Python Output"
                    ),
                    QuizQuestion(
                        id = "q_m1_l1_2",
                        lessonId = "m1_l1",
                        question = "Which character is used to write a single-line comment in Python?",
                        options = listOf("//", "/*", "#", "--"),
                        correctIndex = 2,
                        explanation = "The hash symbol (#) marks the start of a comment. Python ignores anything after the # on that line.",
                        topic = "Comments"
                    ),
                    QuizQuestion(
                        id = "q_m1_l1_3",
                        lessonId = "m1_l1",
                        question = "What will happen if you run: Print(\"Hello\")?",
                        options = listOf(
                            "It prints Hello normally",
                            "It causes a NameError because Python is case-sensitive",
                            "It prompts you for user input",
                            "It opens the printer dialog"
                        ),
                        correctIndex = 1,
                        explanation = "Python is strictly case-sensitive. The builtin function is lowercase 'print', not 'Print'.",
                        topic = "Syntax"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m1_l1",
                    lessonId = "m1_l1",
                    title = "Your First Output",
                    prompt = "Write a program that uses print() to display 'Hello, SATORI!' (without quotes).",
                    starterCode = "# Write your print statement below\n",
                    solutionCode = "print(\"Hello, SATORI!\")",
                    hint = "Remember to put quotation marks around the text inside the parentheses.",
                    explanation = "print(\"Hello, SATORI!\") instructs Python to write the string to the console.",
                    testCases = listOf(
                        TestCase(expectedOutput = "Hello, SATORI!")
                    )
                )
            ),
            Lesson(
                id = "m1_l2",
                moduleId = "mod_1",
                title = "Basic Syntax & Comments",
                order = 2,
                difficulty = Difficulty.BEGINNER,
                readTimeMinutes = 5,
                isFree = true,
                summary = "Learn Python's clean indentation rules and how to keep your code documented.",
                whyItMatters = "Clean code prevents confusion. Unlike other languages that use semicolons and curly braces, Python relies on clean spacing.",
                analogy = "Think of indentation like paragraphs and bullet points in an outline. It naturally groups related ideas together.",
                explanation = "Unlike older programming languages like C, C++, or Java that require complex semicolons at the end of every line and curly braces around blocks, Python uses clean whitespace and newlines.\n\nEvery instruction lives naturally on its own line. Indentation (4 spaces) is used by Python to group related blocks of code together—just like paragraphs in a book.\n\nComments start with a hash symbol (#). Python completely ignores anything on a line following a #. Professional software developers use comments to explain the 'why' behind decisions, leaving breadcrumbs for other engineers and their future selves.",
                syntax = "# Note for humans\nprint(\"First line\")\nprint(\"Second line\")",
                exampleCode = "# Calculating seconds in a minute\nseconds_in_minute = 60\nprint(\"Seconds in a minute:\")\nprint(seconds_in_minute)",
                lineByLine = listOf(
                    LineExplanation(1, "# Calculating seconds in a minute", "A comment explaining the intention of the code."),
                    LineExplanation(2, "seconds_in_minute = 60", "Storing the number 60 for later use."),
                    LineExplanation(3, "print(\"Seconds in a minute:\")", "Printing a descriptive label."),
                    LineExplanation(4, "print(seconds_in_minute)", "Printing the stored number without quotes.")
                ),
                expectedOutput = "Seconds in a minute:\n60",
                visualConceptType = VisualConceptType.NONE,
                commonMistakes = listOf(
                    "Adding unnecessary indentation at the start of a top-level line will trigger an IndentationError.",
                    "Surrounding numbers with quotes when you want to do math with them later."
                ),
                recap = listOf(
                    "Indentation matters in Python and defines code hierarchy.",
                    "Use comments generously to explain why your code makes decisions."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m1_l2_1",
                        lessonId = "m1_l2",
                        question = "What happens if you randomly indent a standard top-level statement in Python?",
                        options = listOf(
                            "Python automatically aligns it silently",
                            "Python throws an IndentationError",
                            "The line runs twice as fast",
                            "It turns into a comment"
                        ),
                        correctIndex = 1,
                        explanation = "In Python, unexpected indentation at the top level causes an immediate IndentationError.",
                        topic = "Indentation"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m1_l2",
                    lessonId = "m1_l2",
                    title = "Multi-line Output Practice",
                    prompt = "Print 'Learning Python' on line 1, and 'One step at a time' on line 2.",
                    starterCode = "# Print the two lines below\n",
                    solutionCode = "print(\"Learning Python\")\nprint(\"One step at a time\")",
                    hint = "Use two separate print() calls on consecutive lines.",
                    explanation = "Each print() statement outputs on its own new line by default.",
                    testCases = listOf(
                        TestCase(expectedOutput = "Learning Python\nOne step at a time")
                    )
                )
            )
        )
    )

    private fun createModule2(): CourseModule = CourseModule(
        id = "mod_2",
        number = 2,
        title = "Variables & Data Types",
        subtitle = "Storing information, numbers, strings, and types",
        iconName = "variables",
        isPremium = false,
        estimatedHours = 2.0,
        lessons = listOf(
            Lesson(
                id = "m2_l1",
                moduleId = "mod_2",
                title = "Variables: Labeled Boxes",
                order = 1,
                difficulty = Difficulty.BEGINNER,
                readTimeMinutes = 5,
                isFree = true,
                summary = "Variables are named storage containers that hold information for your program.",
                whyItMatters = "Programs need to remember user names, scores, prices, and settings. Without variables, your computer has no memory.",
                analogy = "Imagine a cardboard box with a label sticker that says 'player_name'. You can drop the word 'Alex' inside. Whenever your program needs the player's name, it just looks inside the box labeled 'player_name'.",
                explanation = "In computer programming, a variable is a named storage container in memory that preserves a piece of data so you can reference or modify it later in your application.\n\nThink of a variable like a labeled storage box. When you write 'username = \"Maya\"', Python creates the string 'Maya' in your computer's RAM memory and slaps the label 'username' onto it. The single equals sign (=) is the assignment operator—it means 'take the value on the right, and store it into the container named on the left'.\n\nWhenever you type 'username' later in your code, Python automatically looks into that memory location and retrieves 'Maya'. Variables can hold text, whole numbers, decimals, lists, and complex objects without requiring you to declare types beforehand.",
                syntax = "variable_name = value",
                exampleCode = "username = \"Maya\"\nlevel = 5\nprint(\"Player:\")\nprint(username)\nprint(\"Current level:\")\nprint(level)",
                lineByLine = listOf(
                    LineExplanation(1, "username = \"Maya\"", "Creates a variable named username and puts the string 'Maya' inside."),
                    LineExplanation(2, "level = 5", "Creates a variable named level and stores the number 5 inside."),
                    LineExplanation(3, "print(\"Player:\")", "Outputs a text label."),
                    LineExplanation(4, "print(username)", "Outputs the contents of the username variable ('Maya')."),
                    LineExplanation(5, "print(\"Current level:\")", "Outputs another label."),
                    LineExplanation(6, "print(level)", "Outputs the value stored in level (5).")
                ),
                expectedOutput = "Player:\nMaya\nCurrent level:\n5",
                visualConceptType = VisualConceptType.VARIABLES,
                commonMistakes = listOf(
                    "Putting quotes around the variable name: print(\"level\") prints the word 'level', not the number 5.",
                    "Starting variable names with a digit (e.g., 2player = 'Alex' is invalid; use player2 instead)."
                ),
                recap = listOf(
                    "The = sign assigns the value on the right into the variable on the left.",
                    "Variable names should be descriptive and use snake_case (e.g. user_age).",
                    "You do not need to declare types ahead of time; Python figures it out automatically."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m2_l1_1",
                        lessonId = "m2_l1",
                        question = "What does the '=' symbol mean in Python assignment?",
                        options = listOf(
                            "It tests if two numbers are mathematically identical",
                            "It assigns the value on the right into the variable on the left",
                            "It creates a new database table",
                            "It prints a result to the terminal"
                        ),
                        correctIndex = 1,
                        explanation = "In Python, a single '=' is the assignment operator that stores data into a variable container.",
                        topic = "Variables"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m2_l1",
                    lessonId = "m2_l1",
                    title = "Create and Display Variables",
                    prompt = "Create a variable named 'gem' with value 'Ruby' and a variable 'count' with value 10. Print the gem on the first line and count on the second line.",
                    starterCode = "# Create variables and print them\n",
                    solutionCode = "gem = \"Ruby\"\ncount = 10\nprint(gem)\nprint(count)",
                    hint = "gem = \"Ruby\" and count = 10, then use print(gem) and print(count).",
                    explanation = "We store 'Ruby' in gem, 10 in count, and pass each variable to print().",
                    testCases = listOf(
                        TestCase(expectedOutput = "Ruby\n10")
                    )
                )
            ),
            Lesson(
                id = "m2_l2",
                moduleId = "mod_2",
                title = "Data Types & Type Conversion",
                order = 2,
                difficulty = Difficulty.BEGINNER,
                readTimeMinutes = 6,
                isFree = true,
                summary = "Discover integers, floats, strings, booleans, and how to convert between them.",
                whyItMatters = "Adding the text '10' + '20' results in '1020', while adding the numbers 10 + 20 gives 30. Understanding types prevents disastrous bugs.",
                analogy = "A measuring cup, a photo album, and an on/off switch are different kinds of objects. You can't flip a photo album on, and you can't measure milk with a switch. Types tell Python what operations make sense.",
                explanation = "Python has 4 fundamental primitive types: int (whole numbers), float (decimals), str (text enclosed in quotes), and bool (True or False). You can check types with type() and convert using int(), float(), or str().",
                syntax = "int(\"42\")\nfloat(\"3.14\")\nstr(100)",
                exampleCode = "score = 100\naccuracy = 98.5\nis_active = True\nmessage = \"Great job!\"\n\nprint(type(score))\nprint(type(accuracy))\nprint(type(is_active))\nprint(type(message))",
                lineByLine = listOf(
                    LineExplanation(1, "score = 100", "An integer (whole number)."),
                    LineExplanation(2, "accuracy = 98.5", "A float (number with a fractional decimal)."),
                    LineExplanation(3, "is_active = True", "A boolean representing on/true/active state."),
                    LineExplanation(4, "message = \"Great job!\"", "A string of text characters."),
                    LineExplanation(6, "print(type(score))", "type() inspects the kind of data stored in score.")
                ),
                expectedOutput = "<class 'int'>\n<class 'float'>\n<class 'bool'>\n<class 'str'>",
                visualConceptType = VisualConceptType.VARIABLES,
                commonMistakes = listOf(
                    "Attempting int(\"hello\") will crash with a ValueError because the word 'hello' cannot be turned into a number.",
                    "Writing true or false with lowercase letters—in Python it must be capitalized: True and False."
                ),
                recap = listOf(
                    "int = whole numbers, float = decimals, str = text, bool = True/False.",
                    "Use str() to convert numbers to text for concatenation.",
                    "Use int() or float() to parse numbers from user text."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m2_l2_1",
                        lessonId = "m2_l2",
                        question = "What is the data type of the value 3.14159?",
                        options = listOf("int", "float", "str", "bool"),
                        correctIndex = 1,
                        explanation = "Numbers with fractional points (decimals) are of type float.",
                        topic = "Data Types"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m2_l2",
                    lessonId = "m2_l2",
                    title = "Type Conversion Practice",
                    prompt = "Convert the string '50' into an integer, add 25 to it, and print the resulting total.",
                    starterCode = "text_val = \"50\"\n# Convert text_val to an integer, add 25, and print\n",
                    solutionCode = "text_val = \"50\"\ntotal = int(text_val) + 25\nprint(total)",
                    hint = "Use int(text_val) + 25, then pass the result to print().",
                    explanation = "int(\"50\") turns the string into the number 50, which allows addition.",
                    testCases = listOf(
                        TestCase(expectedOutput = "75")
                    )
                )
            )
        )
    )

    private fun createModule3(): CourseModule = CourseModule(
        id = "mod_3",
        number = 3,
        title = "Operators & Expressions",
        subtitle = "Math, comparisons, logic, and precedence",
        iconName = "calculator",
        isPremium = false,
        estimatedHours = 1.8,
        lessons = listOf(
            Lesson(
                id = "m3_l1",
                moduleId = "mod_3",
                title = "Arithmetic & Math Operators",
                order = 1,
                difficulty = Difficulty.BEGINNER,
                readTimeMinutes = 5,
                isFree = true,
                summary = "Perform addition, subtraction, division, powers, and remainder calculations.",
                whyItMatters = "From building games to financial spreadsheets, math operators are the computational gears of every application.",
                analogy = "Just like buttons on a calculator, each symbol performs a specific numerical operation on its neighboring values.",
                explanation = "Python supports addition (+), subtraction (-), multiplication (*), floating division (/), integer floor division (//), modulo/remainder (%), and exponentiation (**).",
                syntax = "a + b\na ** b\na % b",
                exampleCode = "print(10 + 5)\nprint(10 / 4)\nprint(10 // 4)\nprint(10 % 3)\nprint(2 ** 3)",
                lineByLine = listOf(
                    LineExplanation(1, "print(10 + 5)", "Standard addition: 15"),
                    LineExplanation(2, "print(10 / 4)", "Division always returns a float: 2.5"),
                    LineExplanation(3, "print(10 // 4)", "Floor division truncates decimal points: 2"),
                    LineExplanation(4, "print(10 % 3)", "Modulo gives remainder when 10 is divided by 3: 1"),
                    LineExplanation(5, "print(2 ** 3)", "2 to the 3rd power (2 * 2 * 2): 8")
                ),
                expectedOutput = "15\n2.5\n2\n1\n8",
                visualConceptType = VisualConceptType.NONE,
                commonMistakes = listOf(
                    "Confusing single slash (/) with double slash (//): single slash always gives a float.",
                    "Thinking ^ is exponentiation: in Python, ** is exponentiation, while ^ is bitwise XOR."
                ),
                recap = listOf(
                    "+, -, * work as expected.",
                    "/ yields a float, while // rounds down to the nearest integer.",
                    "% gives the remainder, and ** raises a number to a power."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m3_l1_1",
                        lessonId = "m3_l1",
                        question = "What is the result of 17 % 5 in Python?",
                        options = listOf("3.4", "3", "2", "1"),
                        correctIndex = 2,
                        explanation = "5 goes into 17 three times with a remainder of 2. 17 % 5 is 2.",
                        topic = "Arithmetic"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m3_l1",
                    lessonId = "m3_l1",
                    title = "Calculate Cube and Remainder",
                    prompt = "Compute 3 cubed (3 raised to power 3) on line 1, and the remainder of 25 divided by 4 on line 2.",
                    starterCode = "# Calculate power and remainder\n",
                    solutionCode = "print(3 ** 3)\nprint(25 % 4)",
                    hint = "Use 3 ** 3 for power, and 25 % 4 for remainder.",
                    explanation = "3 ** 3 evaluates to 27, and 25 % 4 evaluates to 1.",
                    testCases = listOf(
                        TestCase(expectedOutput = "27\n1")
                    )
                )
            ),
            Lesson(
                id = "m3_l2",
                moduleId = "mod_3",
                title = "Comparisons & Logic",
                order = 2,
                difficulty = Difficulty.BEGINNER,
                readTimeMinutes = 5,
                isFree = true,
                summary = "Compare values with ==, !=, <, >, and combine conditions using and, or, not.",
                whyItMatters = "Logical conditions allow programs to make decisions: 'Is password correct AND is account active?'",
                analogy = "A security gate checks your credentials: You get in if you have an ID card AND your name is on the guest list.",
                explanation = "Comparisons evaluate to True or False. Logical 'and' requires both conditions true; 'or' requires at least one; 'not' inverts the boolean.",
                syntax = "x == y\nx > y\na and b",
                exampleCode = "age = 20\nhas_license = True\nprint(age >= 18)\nprint(age >= 18 and has_license)\nprint(not has_license)",
                lineByLine = listOf(
                    LineExplanation(1, "age = 20", "Assigning 20 to age."),
                    LineExplanation(2, "has_license = True", "Setting boolean flag."),
                    LineExplanation(3, "print(age >= 18)", "20 is greater than or equal to 18 -> True."),
                    LineExplanation(4, "print(age >= 18 and has_license)", "Both are True -> True."),
                    LineExplanation(5, "print(not has_license)", "Inverting True -> False.")
                ),
                expectedOutput = "True\nTrue\nFalse",
                visualConceptType = VisualConceptType.CONDITIONS,
                commonMistakes = listOf(
                    "Using single = for comparison instead of ==. Single = is assignment, double == is equality comparison!"
                ),
                recap = listOf(
                    "== tests equality, != tests inequality.",
                    "and requires both sides True, or requires either side True."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m3_l2_1",
                        lessonId = "m3_l2",
                        question = "What operator tests whether two values are equal in Python?",
                        options = listOf("=", "==", "===", "equals"),
                        correctIndex = 1,
                        explanation = "Double equals (==) tests value equality in Python.",
                        topic = "Comparisons"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m3_l2",
                    lessonId = "m3_l2",
                    title = "Evaluate Logic Expression",
                    prompt = "Given score = 85, print True if score is greater than or equal to 80 AND less than 100, otherwise print False.",
                    starterCode = "score = 85\n# Print the evaluated boolean result\n",
                    solutionCode = "score = 85\nprint(score >= 80 and score < 100)",
                    hint = "Use print(score >= 80 and score < 100).",
                    explanation = "Both conditions are True, so the logical AND evaluates to True.",
                    testCases = listOf(
                        TestCase(expectedOutput = "True")
                    )
                )
            )
        )
    )

    private fun createModule4(): CourseModule = CourseModule(
        id = "mod_4",
        number = 4,
        title = "Strings in Depth",
        subtitle = "Indexing, slicing, formatting, and string methods",
        iconName = "text",
        isPremium = false,
        estimatedHours = 2.2,
        lessons = listOf(
            Lesson(
                id = "m4_l1",
                moduleId = "mod_4",
                title = "Indexing & Slicing",
                order = 1,
                difficulty = Difficulty.BEGINNER,
                readTimeMinutes = 6,
                isFree = true,
                summary = "Extract individual characters and substrings with Python's bracket notation.",
                whyItMatters = "Text processing—like reading names, filenames, or codes—requires isolating parts of a string.",
                analogy = "Think of a string as a train of character carts numbered starting at index 0.",
                explanation = "Python uses 0-based indexing. word[0] is the first character, word[-1] is the last. Slicing with [start:end] extracts from start up to (but not including) end.",
                syntax = "text[0]\ntext[-1]\ntext[start:end]",
                exampleCode = "lang = \"Python\"\nprint(lang[0])\nprint(lang[-1])\nprint(lang[0:2])\nprint(lang[2:])",
                lineByLine = listOf(
                    LineExplanation(1, "lang = \"Python\"", "A 6-character string."),
                    LineExplanation(2, "print(lang[0])", "First character: 'P'"),
                    LineExplanation(3, "print(lang[-1])", "Last character: 'n'"),
                    LineExplanation(4, "print(lang[0:2])", "Characters at 0 and 1: 'Py'"),
                    LineExplanation(5, "print(lang[2:])", "From index 2 to end: 'thon'")
                ),
                expectedOutput = "P\nn\nPy\nthon",
                visualConceptType = VisualConceptType.NONE,
                commonMistakes = listOf(
                    "Forgetting that slices exclude the 'end' index: [0:3] gives indices 0, 1, and 2 (3 characters total)."
                ),
                recap = listOf(
                    "Python indexes start at 0.",
                    "Negative indices count backwards from the end (-1 is the last character).",
                    "[start:stop] stops right before the stop index."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m4_l1_1",
                        lessonId = "m4_l1",
                        question = "What character does 'Python'[1] return?",
                        options = listOf("P", "y", "t", "IndexError"),
                        correctIndex = 1,
                        explanation = "At index 0 is 'P', and at index 1 is 'y'.",
                        topic = "String Indexing"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m4_l1",
                    lessonId = "m4_l1",
                    title = "Extract Substring",
                    prompt = "Given message = 'Hello World', print the first 5 characters ('Hello') using slice notation.",
                    starterCode = "message = \"Hello World\"\n# Print the first 5 characters\n",
                    solutionCode = "message = \"Hello World\"\nprint(message[0:5])",
                    hint = "Use message[0:5] inside print().",
                    explanation = "message[0:5] extracts characters from index 0 to 4 ('Hello').",
                    testCases = listOf(
                        TestCase(expectedOutput = "Hello")
                    )
                )
            ),
            Lesson(
                id = "m4_l2",
                moduleId = "mod_4",
                title = "Modern f-Strings & Methods",
                order = 2,
                difficulty = Difficulty.BEGINNER,
                readTimeMinutes = 5,
                isFree = true,
                summary = "Format text cleanly with f-strings and manipulate case with string methods.",
                whyItMatters = "f-strings are the cleanest, fastest, and most readable way to embed variables directly into strings in modern Python.",
                analogy = "Like a fill-in-the-blank letter where variables automatically plug into the blank slots.",
                explanation = "Prefixing a string with f allows you to embed variables or expressions inside curly braces {}. String methods like .upper(), .lower(), and .strip() return modified copies.",
                syntax = "f\"Hello, {name}!\"\ntext.upper()\ntext.lower()",
                exampleCode = "name = \"Amit\"\nscore = 98\nprint(f\"{name} scored {score}%\")\nprint(name.upper())\nprint(name.lower())",
                lineByLine = listOf(
                    LineExplanation(1, "name = \"Amit\"", "String variable."),
                    LineExplanation(2, "score = 98", "Integer variable."),
                    LineExplanation(3, "print(f\"{name} scored {score}%\")", "f-string dynamically replaces {name} and {score}."),
                    LineExplanation(4, "print(name.upper())", "Returns all uppercase: 'AMIT'."),
                    LineExplanation(5, "print(name.lower())", "Returns all lowercase: 'amit'.")
                ),
                expectedOutput = "Amit scored 98%\nAMIT\namit",
                visualConceptType = VisualConceptType.NONE,
                commonMistakes = listOf(
                    "Forgetting the leading 'f' before the opening quote: \"{name}\" just prints literally '{name}'."
                ),
                recap = listOf(
                    "Always prefer f\"...{variable}...\" for readable text interpolation.",
                    "String methods do not modify strings in place because strings in Python are immutable."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m4_l2_1",
                        lessonId = "m4_l2",
                        question = "What must precede a string literal to activate expression interpolation in curly braces?",
                        options = listOf("s", "f", "$", "@"),
                        correctIndex = 1,
                        explanation = "The letter 'f' indicates an f-string in Python 3.6+.",
                        topic = "f-Strings"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m4_l2",
                    lessonId = "m4_l2",
                    title = "Construct an f-String",
                    prompt = "Given item = 'Notebook' and price = 15, print an f-string: 'Item: Notebook - Price: 15'.",
                    starterCode = "item = \"Notebook\"\nprice = 15\n# Print using an f-string\n",
                    solutionCode = "item = \"Notebook\"\nprice = 15\nprint(f\"Item: {item} - Price: {price}\")",
                    hint = "Use print(f\"Item: {item} - Price: {price}\").",
                    explanation = "The f-string embeds the variables into the specified format.",
                    testCases = listOf(
                        TestCase(expectedOutput = "Item: Notebook - Price: 15")
                    )
                )
            )
        )
    )

    private fun createModule5(): CourseModule = CourseModule(
        id = "mod_5",
        number = 5,
        title = "User Input & Interaction",
        subtitle = "The input() function, prompts, and converting input types",
        iconName = "input",
        isPremium = false,
        estimatedHours = 1.6,
        lessons = listOf(
            Lesson(
                id = "m5_l1",
                moduleId = "mod_5",
                title = "The input() Function",
                order = 1,
                difficulty = Difficulty.BEGINNER,
                readTimeMinutes = 5,
                isFree = true,
                summary = "Capture user text from the keyboard and make your programs interactive.",
                whyItMatters = "Static programs that only output fixed text are boring. User input turns code into interactive software.",
                analogy = "Like a clerk asking 'What is your order?' and waiting until you speak before writing it down.",
                explanation = "The input() function pauses execution and waits for the user to type something and press Enter. Crucially, input() ALWAYS returns data as a string (str).",
                syntax = "user_text = input(\"Enter your name: \")",
                exampleCode = "# Reading user input\nname = input()\nprint(f\"Hello, {name}!\")",
                lineByLine = listOf(
                    LineExplanation(1, "# Reading user input", "Comment describing input action."),
                    LineExplanation(2, "name = input()", "Waits for user input and stores the typed string."),
                    LineExplanation(3, "print(f\"Hello, {name}!\")", "Greets the user dynamically.")
                ),
                expectedOutput = "Hello, Alex!",
                visualConceptType = VisualConceptType.NONE,
                commonMistakes = listOf(
                    "Forgetting that input() returns a string: age = input() -> age + 1 will fail with a TypeError unless converted with int(age)."
                ),
                recap = listOf(
                    "input() pauses the program to read keyboard text.",
                    "Always cast input() with int() or float() if you intend to do arithmetic."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m5_l1_1",
                        lessonId = "m5_l1",
                        question = "What is the return data type of the input() function in Python 3?",
                        options = listOf("int", "float", "str", "depends on what user types"),
                        correctIndex = 2,
                        explanation = "In Python 3, input() ALWAYS returns a string (str).",
                        topic = "User Input"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m5_l1",
                    lessonId = "m5_l1",
                    title = "Interactive Greeting",
                    prompt = "Read one line of input and print 'Welcome, ' followed by the input string.",
                    starterCode = "# Read input and print greeting\n",
                    solutionCode = "name = input()\nprint(f\"Welcome, {name}\")",
                    hint = "name = input() then print(f\"Welcome, {name}\").",
                    explanation = "Stores user input in 'name' and formats the output.",
                    testCases = listOf(
                        TestCase(input = "Amit", expectedOutput = "Welcome, Amit")
                    )
                )
            ),
            Lesson(
                id = "m5_l2",
                moduleId = "mod_5",
                title = "Sanitizing & Validating Input",
                order = 2,
                difficulty = Difficulty.BEGINNER,
                readTimeMinutes = 5,
                isFree = true,
                summary = "Clean up messy user input using .strip() and .lower() before processing.",
                whyItMatters = "Users make typos, add accidental spaces, or use mixed casing. Sanitizing inputs prevents bugs.",
                analogy = "Like wiping your shoes on the doormat before stepping inside the house.",
                explanation = ".strip() removes leading and trailing whitespace, while .lower() normalizes characters for reliable comparison.",
                syntax = "clean_text = raw_input.strip().lower()",
                exampleCode = "raw = \"   Yes   \"\nclean = raw.strip().lower()\nprint(f\"Original: '{raw}'\")\nprint(f\"Cleaned: '{clean}'\")",
                lineByLine = listOf(
                    LineExplanation(1, "raw = \"   Yes   \"", "String with extraneous whitespace."),
                    LineExplanation(2, "clean = raw.strip().lower()", "Chaining strip() and lower() to normalize."),
                    LineExplanation(3, "print(f\"Original: '{raw}'\")", "Display original."),
                    LineExplanation(4, "print(f\"Cleaned: '{clean}'\")", "Display sanitized result: 'yes'.")
                ),
                expectedOutput = "Original: '   Yes   '\nCleaned: 'yes'",
                visualConceptType = VisualConceptType.NONE,
                commonMistakes = listOf(
                    "Expecting strip() to remove spaces inside the string (e.g., 'hello world' is unchanged by strip())."
                ),
                recap = listOf(
                    "strip() trims whitespace from the edges.",
                    "lower() normalizes casing for safe command parsing."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m5_l2_1",
                        lessonId = "m5_l2",
                        question = "What does the method call '  Python  '.strip() return?",
                        options = listOf("'Python'", "'python'", "'  python  '", "None"),
                        correctIndex = 0,
                        explanation = ".strip() removes all leading and trailing whitespace characters.",
                        topic = "String Methods"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m5_l2",
                    lessonId = "m5_l2",
                    title = "Input Sanitization",
                    prompt = "Given raw_text = '  PYTHON  ', strip the leading/trailing spaces, convert to lowercase, and print the result.",
                    starterCode = "raw_text = \"  PYTHON  \"\n# Strip and lowercase raw_text, then print\n",
                    solutionCode = "raw_text = \"  PYTHON  \"\nprint(raw_text.strip().lower())",
                    hint = "Use print(raw_text.strip().lower()).",
                    explanation = "Chaining .strip().lower() produces 'python'.",
                    testCases = listOf(
                        TestCase(expectedOutput = "python")
                    )
                )
            )
        )
    )
}
