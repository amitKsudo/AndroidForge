package com.satori.app.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.satori.app.data.CurriculumRepository
import com.satori.app.model.CourseModule
import com.satori.app.model.Difficulty
import com.satori.app.model.UserProfile
import com.satori.app.ui.theme.*

@Composable
fun CurriculumScreen(
    userProfile: UserProfile,
    onNavigateToLesson: (String) -> Unit,
    onOpenSubscription: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedFilter by remember { mutableStateOf("All") }
    var expandedModuleId by remember { mutableStateOf<String?>("mod_1") }

    val modules = CurriculumRepository.modules
    val filteredModules = when (selectedFilter) {
        "Foundations" -> modules.filter { it.number in 1..5 }
        "Core Logic" -> modules.filter { it.number in 6..12 }
        "Applied & Adv" -> modules.filter { it.number in 13..20 }
        else -> modules
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("curriculum_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        // Curriculum Header
        item {
            Column {
                Text(
                    text = "Python Curriculum",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "20 comprehensive modules from zero to advanced mastery.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SatoriTextSecondary,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        // Filter Pills
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("All", "Foundations", "Core Logic", "Applied & Adv").forEach { filter ->
                    val isSelected = selectedFilter == filter
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedFilter = filter },
                        label = { Text(filter) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SatoriIndigo,
                            selectedLabelColor = Color.White,
                            containerColor = SatoriSurfaceDark,
                            labelColor = SatoriTextSecondary
                        ),
                        border = null,
                        modifier = Modifier.testTag("filter_$filter")
                    )
                }
            }
        }

        // Module Cards
        items(filteredModules) { module ->
            val isExpanded = expandedModuleId == module.id
            val isLocked = false
            val completedInModule = module.lessons.count { userProfile.completedLessonIds.contains(it.id) }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("module_card_${module.number}"),
                colors = CardDefaults.cardColors(containerColor = SatoriSurfaceDark),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                expandedModuleId = if (isExpanded) null else module.id
                            },
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            // Module Number Badge
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(if (isLocked) SatoriSurfaceHighlightDark else SatoriIndigo.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${module.number}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = if (isLocked) SatoriTextMuted else SatoriNeonSpark
                                )
                            }

                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = module.title,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = Color.White
                                    )
                                }
                                Text(
                                    text = module.subtitle,
                                    fontSize = 11.sp,
                                    color = SatoriTextSecondary,
                                    maxLines = 1
                                )
                                Text(
                                    text = "${module.estimatedHours}h • ${module.lessons.size} lessons",
                                    fontSize = 10.sp,
                                    color = SatoriTextMuted,
                                    modifier = Modifier.padding(top = 2.dp)
                                )
                            }
                        }

                        Icon(
                            imageVector = when {
                                isLocked -> Icons.Default.Lock
                                isExpanded -> Icons.Default.KeyboardArrowUp
                                else -> Icons.Default.KeyboardArrowDown
                            },
                            contentDescription = null,
                            tint = if (isLocked) SatoriPythonGold else SatoriTextSecondary
                        )
                    }

                    // Expanded Lesson items
                    AnimatedVisibility(visible = isExpanded) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            HorizontalDivider(color = SatoriBorderDark, thickness = 0.8.dp)

                            if (module.lessons.isEmpty()) {
                                Text(
                                    text = "Lessons ready for learning. Tap to start.",
                                    fontSize = 12.sp,
                                    color = SatoriTextMuted,
                                    modifier = Modifier.padding(vertical = 8.dp)
                                )
                            } else {
                                module.lessons.forEach { lesson ->
                                    val isCompleted = userProfile.completedLessonIds.contains(lesson.id)
                                    Surface(
                                        color = SatoriSurfaceContainerDark,
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { onNavigateToLesson(lesson.id) }
                                            .testTag("lesson_item_${lesson.id}")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Icon(
                                                    imageVector = if (isCompleted) Icons.Default.CheckCircle else Icons.Default.PlayCircleOutline,
                                                    contentDescription = null,
                                                    tint = if (isCompleted) SatoriSuccessGreen else SatoriNeonSpark,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                                Column {
                                                    Text(
                                                        text = lesson.title,
                                                        fontSize = 13.sp,
                                                        fontWeight = FontWeight.SemiBold,
                                                        color = Color.White
                                                    )
                                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                        Text(
                                                            text = "${lesson.readTimeMinutes} min • ${lesson.difficulty.name.lowercase().replaceFirstChar { it.uppercase() }}",
                                                            fontSize = 10.sp,
                                                            color = SatoriTextSecondary
                                                        )
                                                        if (lesson.exercise != null) {
                                                            Surface(
                                                                color = SatoriIndigo.copy(alpha = 0.25f),
                                                                shape = RoundedCornerShape(3.dp)
                                                            ) {
                                                                Text(
                                                                    text = "CHALLENGE",
                                                                    fontSize = 8.5.sp,
                                                                    fontWeight = FontWeight.Bold,
                                                                    color = SatoriNeonSpark,
                                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                                )
                                                            }
                                                        }
                                                    }
                                                }
                                            }

                                            Icon(
                                                imageVector = Icons.Default.ChevronRight,
                                                contentDescription = null,
                                                tint = SatoriTextMuted,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
