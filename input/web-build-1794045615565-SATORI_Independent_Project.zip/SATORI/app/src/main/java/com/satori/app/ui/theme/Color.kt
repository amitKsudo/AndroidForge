package com.satori.app.ui.theme

import androidx.compose.ui.graphics.Color

// SATORI Brand Palette - Deep Violet & Modern Indigo
val SatoriDeepViolet = Color(0xFF130924)
val SatoriSurfaceDark = Color(0xFF1C1035)
val SatoriSurfaceContainerDark = Color(0xFF28174A)
val SatoriSurfaceHighlightDark = Color(0xFF382166)

val SatoriIndigo = Color(0xFF7B5CFA)
val SatoriIndigoLight = Color(0xFF9E86FD)
val SatoriPurple = Color(0xFFC084FC)
val SatoriNeonSpark = Color(0xFFD8B4FE)

// Accents & Syntax Highlighting Colors
val SatoriPythonGold = Color(0xFFFFB800)
val SatoriPythonCyan = Color(0xFF38BDF8)
val SatoriSuccessGreen = Color(0xFF10B981)
val SatoriErrorRed = Color(0xFFF43F5E)
val SatoriWarningOrange = Color(0xFFFB923C)

// Neutral Text & Surfaces
val SatoriTextPrimary = Color(0xFFF8FAFC)
val SatoriTextSecondary = Color(0xFF94A3B8)
val SatoriTextMuted = Color(0xFF64748B)
val SatoriBorderDark = Color(0xFF382B5E)
val SatoriCodeBackground = Color(0xFF0F071D)

// Light Theme Palette
val SatoriLightBackground = Color(0xFFF8F6FF)
val SatoriLightSurface = Color(0xFFFFFFFF)
val SatoriLightSurfaceContainer = Color(0xFFF1ECFC)
val SatoriLightBorder = Color(0xFFE2D9F3)
val SatoriLightTextPrimary = Color(0xFF1E1338)
val SatoriLightTextSecondary = Color(0xFF645E7A)
