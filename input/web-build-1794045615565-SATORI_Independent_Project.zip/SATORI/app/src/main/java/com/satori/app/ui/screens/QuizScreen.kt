package com.satori.app.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.satori.app.model.Lesson
import com.satori.app.model.QuizQuestion
import com.satori.app.ui.theme.*
import com.satori.app.util.AudioFeedbackManager

@Composable
fun QuizScreen(
    lesson: Lesson,
    onQuizComplete: (scorePercent: Int) -> Unit,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val questions = lesson.quizQuestions
    var currentIndex by remember { mutableStateOf(0) }
    var selectedOptionIndex by remember { mutableStateOf<Int?>(null) }
    var isAnswerSubmitted by remember { mutableStateOf(false) }
    var correctAnswersCount by remember { mutableStateOf(0) }
    var isQuizFinished by remember { mutableStateOf(false) }

    if (questions.isEmpty()) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No quiz available for this lesson.", color = SatoriTextSecondary)
        }
        return
    }

    val currentQuestion = questions.getOrElse(currentIndex) { questions.first() }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("quiz_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        // Top Bar
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("quiz_close_btn")) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = SatoriTextSecondary)
                }
                Text(
                    text = "Lesson Quiz",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Color.White
                )
                Surface(
                    color = SatoriSurfaceHighlightDark,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "${currentIndex + 1}/${questions.size}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = SatoriNeonSpark,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
        }

        // Progress Bar
        item {
            LinearProgressIndicator(
                progress = { (currentIndex + 1).toFloat() / questions.size.toFloat() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = SatoriIndigo,
                trackColor = SatoriSurfaceHighlightDark
            )
        }

        if (isQuizFinished) {
            // Results Celebration Screen
            item {
                val percent = (correctAnswersCount * 100) / questions.size
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = SatoriSurfaceDark),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(SatoriIndigo, SatoriPurple)))
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .background(if (percent >= 80) SatoriPythonGold.copy(alpha = 0.2f) else SatoriIndigo.copy(alpha = 0.2f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (percent >= 80) Icons.Default.EmojiEvents else Icons.Default.ThumbUp,
                                contentDescription = null,
                                tint = if (percent >= 80) SatoriPythonGold else SatoriNeonSpark,
                                modifier = Modifier.size(40.dp)
                            )
                        }

                        Spacer(Modifier.height(16.dp))
                        Text(
                            text = if (percent == 100) "Flawless Understanding!" else if (percent >= 80) "Great Job!" else "Keep Practicing!",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "You scored $correctAnswersCount out of ${questions.size} ($percent%)",
                            fontSize = 14.sp,
                            color = SatoriTextSecondary,
                            modifier = Modifier.padding(top = 4.dp)
                        )

                        Surface(
                            color = SatoriSurfaceHighlightDark,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.padding(vertical = 16.dp)
                        ) {
                            Text(
                                text = if (percent >= 80) "+30 XP Earned!" else "+15 XP Earned!",
                                color = SatoriPythonGold,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    currentIndex = 0
                                    selectedOptionIndex = null
                                    isAnswerSubmitted = false
                                    correctAnswersCount = 0
                                    isQuizFinished = false
                                },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Retry Quiz")
                            }

                            Button(
                                onClick = {
                                    onQuizComplete(percent)
                                    onNavigateBack()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = SatoriIndigo),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f).testTag("finish_quiz_btn")
                            ) {
                                Text("Done", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        } else {
            // Question Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = SatoriSurfaceDark),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Surface(
                            color = SatoriIndigo.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = currentQuestion.topic.uppercase(),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = SatoriNeonSpark,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = currentQuestion.question,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            lineHeight = 22.sp
                        )
                    }
                }
            }

            // Options
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    currentQuestion.options.forEachIndexed { index, optionText ->
                        val isSelected = selectedOptionIndex == index
                        val isCorrect = index == currentQuestion.correctIndex

                        val containerColor = when {
                            !isAnswerSubmitted && isSelected -> SatoriIndigo.copy(alpha = 0.3f)
                            isAnswerSubmitted && isCorrect -> SatoriSuccessGreen.copy(alpha = 0.25f)
                            isAnswerSubmitted && isSelected && !isCorrect -> SatoriErrorRed.copy(alpha = 0.25f)
                            else -> SatoriSurfaceDark
                        }

                        val borderColor = when {
                            isAnswerSubmitted && isCorrect -> SatoriSuccessGreen
                            isAnswerSubmitted && isSelected && !isCorrect -> SatoriErrorRed
                            isSelected -> SatoriIndigo
                            else -> SatoriBorderDark
                        }

                        Surface(
                            color = containerColor,
                            shape = RoundedCornerShape(12.dp),
                            border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(borderColor, borderColor))),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(enabled = !isAnswerSubmitted) {
                                    selectedOptionIndex = index
                                }
                                .testTag("quiz_option_$index")
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(CircleShape)
                                            .background(if (isSelected) SatoriIndigo else SatoriSurfaceHighlightDark),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = listOf("A", "B", "C", "D").getOrElse(index) { "?" },
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                    Text(
                                        text = optionText,
                                        fontSize = 14.sp,
                                        color = Color.White,
                                        lineHeight = 20.sp
                                    )
                                }

                                if (isAnswerSubmitted) {
                                    Icon(
                                        imageVector = if (isCorrect) Icons.Default.CheckCircle else if (isSelected) Icons.Default.Cancel else Icons.Default.RadioButtonUnchecked,
                                        contentDescription = null,
                                        tint = if (isCorrect) SatoriSuccessGreen else if (isSelected) SatoriErrorRed else Color.Transparent,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Explanation Card (revealed after submission)
            if (isAnswerSubmitted) {
                item {
                    val wasCorrect = selectedOptionIndex == currentQuestion.correctIndex
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SatoriSurfaceContainerDark),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(
                                    imageVector = if (wasCorrect) Icons.Default.CheckCircle else Icons.Default.Info,
                                    contentDescription = null,
                                    tint = if (wasCorrect) SatoriSuccessGreen else SatoriWarningOrange,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = if (wasCorrect) "Correct Explanation" else "Why this answer is correct:",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (wasCorrect) SatoriSuccessGreen else SatoriWarningOrange
                                )
                            }
                            Text(
                                text = currentQuestion.explanation,
                                fontSize = 13.sp,
                                color = SatoriTextPrimary,
                                modifier = Modifier.padding(top = 4.dp),
                                lineHeight = 19.sp
                            )
                        }
                    }
                }
            }

            // Bottom Action (Check or Next)
            item {
                Button(
                    onClick = {
                        if (!isAnswerSubmitted) {
                            if (selectedOptionIndex != null) {
                                isAnswerSubmitted = true
                                if (selectedOptionIndex == currentQuestion.correctIndex) {
                                    correctAnswersCount++
                                }
                            }
                        } else {
                            if (currentIndex + 1 < questions.size) {
                                currentIndex++
                                selectedOptionIndex = null
                                isAnswerSubmitted = false
                            } else {
                                isQuizFinished = true
                                AudioFeedbackManager.playQuizComplete()
                            }
                        }
                    },
                    enabled = selectedOptionIndex != null,
                    colors = ButtonDefaults.buttonColors(containerColor = SatoriIndigo),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("quiz_action_btn")
                ) {
                    Text(
                        text = if (!isAnswerSubmitted) "Check Answer" else if (currentIndex + 1 < questions.size) "Next Question" else "See Results",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}
