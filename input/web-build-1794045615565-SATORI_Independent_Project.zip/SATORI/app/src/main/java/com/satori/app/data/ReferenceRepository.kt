package com.satori.app.data

import com.satori.app.model.*

object ReferenceRepository {

    val cheatsheetCategories = listOf(
        "All",
        "Basics",
        "Variables",
        "Operators",
        "Strings",
        "Lists",
        "Dictionaries",
        "Conditions",
        "Loops",
        "Functions",
        "File I/O",
        "Exceptions"
    )

    val cheatsheetItems = listOf(
        CheatsheetItem(
            id = "cs_print",
            category = "Basics",
            title = "print() Statement",
            syntax = "print(*objects, sep=' ', end='\\n')",
            description = "Outputs values and formatted text to the screen console.",
            codeExample = "print(\"Hello, SATORI!\", end=\" \")\nprint(\"Code makes sense.\")",
            expectedOutput = "Hello, SATORI! Code makes sense."
        ),
        CheatsheetItem(
            id = "cs_input",
            category = "Basics",
            title = "input() Prompt",
            syntax = "variable = input(prompt)",
            description = "Pauses program and reads a string entered by the user.",
            codeExample = "name = \"User\"\nprint(f\"Welcome, {name}!\")",
            expectedOutput = "Welcome, User!"
        ),
        CheatsheetItem(
            id = "cs_fstrings",
            category = "Strings",
            title = "f-Strings (Formatted Literals)",
            syntax = "f\"Text {expression}\"",
            description = "Interpolates variables and python expressions cleanly directly inside string literals.",
            codeExample = "score = 98\nprint(f\"Accuracy: {score}%\")",
            expectedOutput = "Accuracy: 98%"
        ),
        CheatsheetItem(
            id = "cs_slice",
            category = "Strings",
            title = "String Slicing",
            syntax = "string[start:stop:step]",
            description = "Extracts a substring from start index up to (exclusive) stop index.",
            codeExample = "lang = \"Python\"\nprint(lang[0:4])\nprint(lang[-2:])",
            expectedOutput = "Pyth\non"
        ),
        CheatsheetItem(
            id = "cs_list_append",
            category = "Lists",
            title = "List append() & pop()",
            syntax = "list.append(x)\nlist.pop(index)",
            description = "append adds an element to the end; pop removes and returns the element.",
            codeExample = "items = [1, 2]\nitems.append(3)\nlast = items.pop()\nprint(items)\nprint(f\"Popped: {last}\")",
            expectedOutput = "[1, 2]\nPopped: 3"
        ),
        CheatsheetItem(
            id = "cs_dict_get",
            category = "Dictionaries",
            title = "Dictionary get()",
            syntax = "dict.get(key, default)",
            description = "Safely look up a value without raising a KeyError if the key does not exist.",
            codeExample = "user = {\"name\": \"Aria\"}\nprint(user.get(\"role\", \"Guest\"))",
            expectedOutput = "Guest"
        ),
        CheatsheetItem(
            id = "cs_list_comp",
            category = "Lists",
            title = "List Comprehensions",
            syntax = "[expression for item in iterable if condition]",
            description = "Concise and expressive syntax to generate transformed or filtered lists.",
            codeExample = "squares = [x * x for x in range(1, 5)]\nprint(squares)",
            expectedOutput = "[1, 4, 9, 16]"
        ),
        CheatsheetItem(
            id = "cs_if_elif",
            category = "Conditions",
            title = "if / elif / else",
            syntax = "if cond1:\n    pass\nelif cond2:\n    pass\nelse:\n    pass",
            description = "Conditional branching to control execution flow.",
            codeExample = "val = 15\nif val > 10:\n    print(\"Greater than 10\")\nelse:\n    print(\"10 or less\")",
            expectedOutput = "Greater than 10"
        ),
        CheatsheetItem(
            id = "cs_for_loop",
            category = "Loops",
            title = "for Loop with range()",
            syntax = "for var in range(start, stop, step):\n    ...",
            description = "Iterates over a sequence of numbers.",
            codeExample = "for i in range(3):\n    print(f\"Iteration {i}\")",
            expectedOutput = "Iteration 0\nIteration 1\nIteration 2"
        ),
        CheatsheetItem(
            id = "cs_def_func",
            category = "Functions",
            title = "Function Definition (def)",
            syntax = "def function_name(param1, param2=default):\n    return result",
            description = "Defines a reusable block of logic with parameters and return value.",
            codeExample = "def multiply(a, b):\n    return a * b\n\nprint(multiply(4, 5))",
            expectedOutput = "20"
        ),
        CheatsheetItem(
            id = "cs_try_except",
            category = "Exceptions",
            title = "try / except Handling",
            syntax = "try:\n    ...\nexcept Exception as e:\n    ...",
            description = "Catches runtime errors gracefully to prevent application crashes.",
            codeExample = "try:\n    x = 10 / 0\nexcept:\n    print(\"Cannot divide by zero!\")",
            expectedOutput = "Cannot divide by zero!"
        )
    )

    val guidedProjects = listOf(
        GuidedProject(
            id = "proj_calculator",
            title = "Interactive Calculator",
            category = "Utility",
            description = "Build a versatile math calculator supporting addition, subtraction, multiplication, and division with error checks.",
            difficulty = Difficulty.BEGINNER,
            estimatedMinutes = 20,
            isPremium = false,
            starterCode = "# SATORI Calculator Project\ndef calculate(a, op, b):\n    if op == \"+\":\n        return a + b\n    elif op == \"-\":\n        return a - b\n    elif op == \"*\":\n        return a * b\n    elif op == \"/\":\n        return a / b\n    return \"Invalid operator\"\n\n# Test your calculator\nprint(calculate(10, \"+\", 5))\nprint(calculate(20, \"*\", 3))\nprint(calculate(15, \"/\", 3))",
            solutionCode = "def calculate(a, op, b):\n    if op == \"+\": return a + b\n    elif op == \"-\": return a - b\n    elif op == \"*\": return a * b\n    elif op == \"/\": return a / b if b != 0 else \"ZeroDivisionError\"\n    return \"Invalid operator\"",
            steps = listOf(
                ProjectStep(1, "Define the Function", "Create a function taking two numbers and an operator string.", "def calculate(a, op, b):"),
                ProjectStep(2, "Add Conditional Branches", "Use if/elif/else to evaluate each arithmetic operator.", "if op == '+': return a + b"),
                ProjectStep(3, "Handle Edge Cases", "Prevent division by zero by checking if b == 0.", "if b == 0: return 'Cannot divide by zero'")
            )
        ),
        GuidedProject(
            id = "proj_password_gen",
            title = "Secure Password Generator",
            category = "Security",
            description = "Generate random secure passwords combining uppercase, lowercase, numbers, and symbols.",
            difficulty = Difficulty.BEGINNER,
            estimatedMinutes = 25,
            isPremium = false,
            starterCode = "# Password Generator\nimport random\n\ndef generate_password(length=8):\n    chars = \"abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#$%^&*\"\n    password = \"\"\n    for _ in range(length):\n        password += random.choice(chars)\n    return password\n\nprint(\"Generated Password:\")\nprint(generate_password(10))",
            solutionCode = "import random\ndef generate_password(length=8):\n    chars = \"abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#$%^&*\"\n    return \"\".join(random.choice(chars) for _ in range(length))",
            steps = listOf(
                ProjectStep(1, "Import Random", "Use the random module to pick characters.", "import random"),
                ProjectStep(2, "Define Character Pools", "Create character pools containing letters, digits, and symbols.", "chars = 'abc123!@#'"),
                ProjectStep(3, "Assemble Password", "Loop length times and append chosen characters.", "password += random.choice(chars)")
            )
        ),
        GuidedProject(
            id = "proj_expense_tracker",
            title = "Personal Expense Tracker",
            category = "Finance",
            description = "Record expenses by category, calculate totals, and view a financial breakdown.",
            difficulty = Difficulty.INTERMEDIATE,
            estimatedMinutes = 35,
            isPremium = false,
            starterCode = "# Expense Tracker\nexpenses = [\n    {\"desc\": \"Groceries\", \"amount\": 45.5, \"category\": \"Food\"},\n    {\"desc\": \"Bus pass\", \"amount\": 20.0, \"category\": \"Transit\"},\n    {\"desc\": \"Coffee\", \"amount\": 4.5, \"category\": \"Food\"}\n]\n\ntotal = sum(item[\"amount\"] for item in expenses)\nprint(f\"Total Expenses: \${total}\")",
            solutionCode = "expenses = [{\"amount\": 45.5}, {\"amount\": 20.0}]\ntotal = sum(item[\"amount\"] for item in expenses)",
            steps = listOf(
                ProjectStep(1, "Data Model", "Use a list of dictionaries to represent each transaction.", "{'desc': '...', 'amount': 0.0}"),
                ProjectStep(2, "Total Calculation", "Sum the amounts using sum() and generator expression.", "total = sum(e['amount'] for e in expenses)"),
                ProjectStep(3, "Category Grouping", "Group expenses by category.", "category_totals[cat] += amount")
            )
        )
    )

    val careerPaths = listOf(
        CareerPath(
            id = "career_automation",
            title = "Python Automation Specialist",
            iconName = "bot",
            description = "Automate tedious daily tasks, web scraping, email notifications, file organization, and spreadsheet processing.",
            targetRoles = listOf("Automation Engineer", "DevOps Assistant", "Productivity Specialist"),
            prerequisites = "Modules 1 through 12",
            recommendedModuleNumbers = listOf(1, 2, 3, 4, 5, 6, 7, 8, 11, 12, 16)
        ),
        CareerPath(
            id = "career_data",
            title = "Data Analyst & Scientist",
            iconName = "chart",
            description = "Extract insights from raw data, build statistical dashboards, process data with Pandas/NumPy, and tell stories with numbers.",
            targetRoles = listOf("Data Analyst", "Business Intelligence Dev", "Junior Data Scientist"),
            prerequisites = "Modules 1 through 10, 18",
            recommendedModuleNumbers = listOf(1, 2, 3, 4, 8, 9, 10, 12, 18, 19)
        ),
        CareerPath(
            id = "career_backend",
            title = "Backend & API Developer",
            iconName = "server",
            description = "Design scalable REST APIs, microservices, database schemas with FastAPI, Flask, and Django.",
            targetRoles = listOf("Backend Engineer", "API Developer", "Full Stack Python Dev"),
            prerequisites = "Modules 1 through 14, 17, 18",
            recommendedModuleNumbers = listOf(6, 7, 8, 9, 10, 13, 14, 17, 18, 19)
        ),
        CareerPath(
            id = "career_ai",
            title = "AI & Machine Learning Engineer",
            iconName = "sparkles",
            description = "Build intelligent systems, train neural networks, work with LLMs, Gemini, and PyTorch.",
            targetRoles = listOf("AI Engineer", "ML Practitioner", "LLM Application Dev"),
            prerequisites = "Full Python Core Mastery",
            recommendedModuleNumbers = listOf(1, 2, 8, 9, 10, 14, 15, 17, 19, 20)
        )
    )

    val subscriptionPlans = listOf(
        SubscriptionPlan(
            id = "plan_monthly",
            title = "Monthly Explorer",
            priceInr = 99,
            periodText = "/month",
            billingText = "Billed monthly. Cancel anytime.",
            savingsBadge = "POPULAR",
            isPopular = true,
            benefits = listOf(
                "Access to all 20 Python Modules",
                "Complete Quiz & Coding Exercises",
                "Full Searchable Cheatsheet Library",
                "Guided Real-World Projects",
                "Interactive Python Playground",
                "Course Completion Certificate"
            )
        ),
        SubscriptionPlan(
            id = "plan_quarterly",
            title = "Quarterly Mastery",
            priceInr = 249,
            periodText = "/3 months",
            billingText = "Billed every 3 months. Equivalent to ₹83/mo.",
            savingsBadge = "SAVE 16%",
            isPopular = false,
            benefits = listOf(
                "Everything in Monthly Explorer",
                "Specialized Career Learning Paths",
                "Offline Resource Downloads",
                "Priority Code Evaluation",
                "Verified SATORI Python Certificate",
                "Direct Instructor Q&A Access"
            )
        ),
        SubscriptionPlan(
            id = "plan_annual",
            title = "Annual Pythonista",
            priceInr = 699,
            periodText = "/year",
            billingText = "Billed annually. Equivalent to ₹58/mo.",
            savingsBadge = "BEST VALUE (SAVE 41%)",
            isPopular = false,
            benefits = listOf(
                "Everything in Quarterly Mastery",
                "Lifetime Access to Future Modules",
                "1-on-1 Portfolio & Resume Review",
                "Exclusive Advanced Python Projects",
                "Verified Certificate signed by Founder Amit Kumar"
            )
        )
    )

    val achievements = listOf(
        Achievement("first_step", "First Satori", "Completed your very first Python lesson.", "spark", 50, true, "2026-11-06"),
        Achievement("variable_alchemist", "Variable Alchemist", "Successfully stored and manipulated labeled data boxes.", "box", 70, true, "2026-11-06"),
        Achievement("loop_virtuoso", "Loop Virtuoso", "Automated 1,000 operations with clean for & while loops.", "repeat", 100, false),
        Achievement("bug_hunter", "Bug Hunter", "Debugged and passed all automated exercise test cases.", "target", 120, false),
        Achievement("quiz_champion", "Quiz Champion", "Scored 100% on 5 consecutive lesson quizzes.", "trophy", 150, false),
        Achievement("pythonista", "Master Pythonista", "Completed all core modules and received verified certificate.", "crown", 300, false)
    )
}
