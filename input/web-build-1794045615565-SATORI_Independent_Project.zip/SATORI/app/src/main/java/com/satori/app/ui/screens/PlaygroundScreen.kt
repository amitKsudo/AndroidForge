package com.satori.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.satori.app.ui.components.PythonEditor
import com.satori.app.ui.theme.*

@Composable
fun PlaygroundScreen(modifier: Modifier = Modifier) {
    val templates = listOf(
        "Hello World" to "print(\"Welcome to SATORI!\")\nprint(\"Code finally makes sense.\")",
        "Variables & Types" to "name = \"Alex\"\nage = 24\nis_learner = True\n\nprint(f\"{name} is {age} years old.\")\nprint(f\"Type of age: {type(age)}\")",
        "Loop & Math" to "total = 0\nfor i in range(1, 6):\n    total += i\n    print(f\"Step {i}: total is {total}\")\n\nprint(f\"Final sum: {total}\")",
        "Fibonacci" to "# Fibonacci Sequence\na, b = 0, 1\nsequence = []\nfor _ in range(8):\n    sequence.append(a)\n    a, b = b, a + b\n\nprint(f\"Fibonacci: {sequence}\")",
        "Function & Logic" to "def categorize_number(n):\n    if n > 0:\n        return \"Positive\"\n    elif n < 0:\n        return \"Negative\"\n    else:\n        return \"Zero\"\n\nprint(categorize_number(12))\nprint(categorize_number(-5))\nprint(categorize_number(0))",
        "List Operations" to "fruits = [\"Apple\", \"Banana\", \"Cherry\"]\nfruits.append(\"Date\")\nprint(f\"All fruits: {fruits}\")\nprint(f\"Count: {len(fruits)}\")\nprint(f\"First: {fruits[0]}, Last: {fruits[-1]}\")"
    )

    var currentTemplateName by remember { mutableStateOf("Hello World") }
    var currentCode by remember { mutableStateOf(templates.first().second) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("playground_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Python Playground",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Write, experiment, and run real Python code directly on your device.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SatoriTextSecondary,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        // Templates carousel
        item {
            Text("Preset Code Templates", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = SatoriTextSecondary)
            Spacer(Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(templates) { (name, codeSnippet) ->
                    val isSelected = currentTemplateName == name
                    FilterChip(
                        selected = isSelected,
                        onClick = {
                            currentTemplateName = name
                            currentCode = codeSnippet
                        },
                        label = { Text(name, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SatoriIndigo,
                            selectedLabelColor = Color.White,
                            containerColor = SatoriSurfaceDark,
                            labelColor = SatoriTextSecondary
                        ),
                        border = null
                    )
                }
            }
        }

        // Python Code Editor
        item {
            PythonEditor(
                initialCode = currentCode,
                onCodeChange = { currentCode = it }
            )
        }

        // Tips card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SatoriSurfaceDark),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = SatoriPythonCyan, modifier = Modifier.size(16.dp))
                        Text("Python Execution Environment", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SatoriPythonCyan)
                    }
                    Text(
                        text = "SATORI's local Python runtime supports arithmetic, variables, control flow, loops, functions, lists, dicts, f-strings, and stdout. No internet connection required.",
                        fontSize = 11.sp,
                        color = SatoriTextSecondary,
                        lineHeight = 16.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }
    }
}
