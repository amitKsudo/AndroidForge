package com.satori.app.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.satori.app.data.CurriculumRepository
import com.satori.app.data.ReferenceRepository
import com.satori.app.model.CertificateData
import com.satori.app.model.SubscriptionPlan
import com.satori.app.model.UserProfile
import com.satori.app.ui.components.CertificateDialog
import com.satori.app.ui.theme.*
import com.satori.app.util.AudioFeedbackManager

@Composable
fun ProfileScreen(
    userProfile: UserProfile,
    onSelectPlan: (SubscriptionPlan) -> Unit,
    onResetProgress: () -> Unit,
    onNavigateToLesson: (String) -> Unit,
    onEditProfile: (String, String) -> Unit,
    onClaimCertificate: () -> CertificateData,
    onLogout: () -> Unit,
    onNavigateToExam: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showResetConfirm by remember { mutableStateOf(false) }
    var showEditProfileDialog by remember { mutableStateOf(false) }
    var activeCertificate by remember { mutableStateOf<CertificateData?>(null) }

    var editName by remember { mutableStateOf(userProfile.name) }
    var editEmail by remember { mutableStateOf(userProfile.email) }

    val allLessons = CurriculumRepository.modules.flatMap { it.lessons }
    val bookmarkedLessons = allLessons.filter { userProfile.bookmarkedLessonIds.contains(it.id) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("profile_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        // User Identity Header Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = SatoriSurfaceDark),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(SatoriIndigo, SatoriPurple)))
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(CircleShape)
                                    .background(SatoriIndigo),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = userProfile.name.take(1).uppercase(),
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 24.sp
                                )
                            }

                            Column {
                                Text(
                                    text = userProfile.name,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = userProfile.email,
                                    fontSize = 12.sp,
                                    color = SatoriTextSecondary,
                                    modifier = Modifier.padding(top = 2.dp)
                                )
                                Text(
                                    text = if (userProfile.provider == "google") "Google Authenticated" else "Standard Account",
                                    fontSize = 10.sp,
                                    color = SatoriPythonCyan
                                )
                            }
                        }

                        IconButton(
                            onClick = {
                                editName = userProfile.name
                                editEmail = userProfile.email
                                showEditProfileDialog = true
                            },
                            modifier = Modifier.testTag("edit_profile_btn")
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit Profile", tint = SatoriTextSecondary)
                        }
                    }

                    Spacer(Modifier.height(16.dp))
                    HorizontalDivider(color = SatoriBorderDark)
                    Spacer(Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${userProfile.streakDays} Days", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = SatoriWarningOrange)
                            Text("Current Streak", fontSize = 11.sp, color = SatoriTextSecondary)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${userProfile.totalXp}", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = SatoriPythonGold)
                            Text("Total XP", fontSize = 11.sp, color = SatoriTextSecondary)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${userProfile.completedLessonIds.size}", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = SatoriSuccessGreen)
                            Text("Completed", fontSize = 11.sp, color = SatoriTextSecondary)
                        }
                    }
                }
            }
        }

        // Official Completion Certificate & Examination Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth().testTag("certificate_card"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = SatoriSurfaceDark),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.horizontalGradient(
                        if (userProfile.hasPassedFinalExam) listOf(SatoriPythonGold, SatoriIndigo)
                        else listOf(SatoriIndigo, SatoriBorderDark)
                    )
                )
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(
                                        if (userProfile.hasPassedFinalExam) SatoriPythonGold.copy(alpha = 0.2f)
                                        else SatoriIndigo.copy(alpha = 0.2f),
                                        CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.WorkspacePremium,
                                    contentDescription = null,
                                    tint = if (userProfile.hasPassedFinalExam) SatoriPythonGold else SatoriNeonSpark,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = if (userProfile.hasPassedFinalExam) "Certificate of Completion" else "Python Certification Examination",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = Color.White
                                )
                                Text(
                                    text = "Signed by Founder Amit Kumar",
                                    fontSize = 11.sp,
                                    color = SatoriTextSecondary
                                )
                            }
                        }

                        Surface(
                            color = if (userProfile.hasPassedFinalExam) SatoriSuccessGreen.copy(alpha = 0.2f)
                                   else if (userProfile.finalExamScore != null) SatoriErrorRed.copy(alpha = 0.2f)
                                   else SatoriIndigo.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = when {
                                    userProfile.hasPassedFinalExam -> "PASSED (${userProfile.finalExamScore ?: 100}%)"
                                    userProfile.finalExamScore != null -> "FAILED (${userProfile.finalExamScore}%)"
                                    else -> "67%+ REQUIRED"
                                },
                                color = when {
                                    userProfile.hasPassedFinalExam -> SatoriSuccessGreen
                                    userProfile.finalExamScore != null -> SatoriErrorRed
                                    else -> SatoriNeonSpark
                                },
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    if (userProfile.hasPassedFinalExam) {
                        Text(
                            text = "Awarded to ${userProfile.name} upon successfully passing the comprehensive 50-question final examination with ${userProfile.finalExamScore}%.",
                            fontSize = 12.sp,
                            color = SatoriTextPrimary,
                            lineHeight = 17.sp
                        )

                        Spacer(Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    val cert = onClaimCertificate()
                                    activeCertificate = cert
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = SatoriIndigo),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f).testTag("view_certificate_btn")
                            ) {
                                Icon(Icons.Default.School, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    text = "View Certificate",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }

                            OutlinedButton(
                                onClick = onNavigateToExam,
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = SatoriPythonCyan)
                            ) {
                                Text("Retake Exam", fontSize = 12.sp)
                            }
                        }
                    } else {
                        Text(
                            text = "To unlock your official Certificate of Completion, complete the 50-question comprehensive examination and achieve at least 67% (34 correct answers).",
                            fontSize = 12.sp,
                            color = SatoriTextSecondary,
                            lineHeight = 17.sp
                        )

                        userProfile.finalExamScore?.let { score ->
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = "Previous attempt: $score% (Minimum 67% needed to qualify).",
                                fontSize = 11.sp,
                                color = SatoriErrorRed
                            )
                        }

                        Spacer(Modifier.height(14.dp))

                        Button(
                            onClick = onNavigateToExam,
                            colors = ButtonDefaults.buttonColors(containerColor = SatoriIndigo),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().testTag("start_exam_btn")
                        ) {
                            Icon(Icons.Default.Quiz, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "Take Final Examination (50 Questions)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }

        // Bookmarks & Saved Notes
        item {
            Text("Bookmarked Lessons (${bookmarkedLessons.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(Modifier.height(8.dp))
            if (bookmarkedLessons.isEmpty()) {
                Text("No bookmarked lessons yet. Tap the bookmark icon in any lesson to save it here.", fontSize = 12.sp, color = SatoriTextMuted)
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    bookmarkedLessons.forEach { bLesson ->
                        Surface(
                            color = SatoriSurfaceDark,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onNavigateToLesson(bLesson.id) }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(bLesson.title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = Color.White)
                                    Text(bLesson.summary, fontSize = 11.sp, color = SatoriTextSecondary, maxLines = 1)
                                }
                                Icon(Icons.Default.ChevronRight, contentDescription = null, tint = SatoriTextSecondary)
                            }
                        }
                    }
                }
            }
        }

        // Account & Admin Options
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SatoriSurfaceDark),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    // Log out
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Log Out Account", fontSize = 13.sp, color = SatoriTextPrimary)
                        TextButton(onClick = onLogout) {
                            Text("Sign Out", color = SatoriPythonCyan, fontWeight = FontWeight.Bold)
                        }
                    }

                    HorizontalDivider(color = SatoriBorderDark, modifier = Modifier.padding(vertical = 4.dp))

                    // Reset Progress
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Reset Learning Progress", fontSize = 13.sp, color = SatoriErrorRed)
                        TextButton(onClick = { showResetConfirm = true }) {
                            Text("Reset", color = SatoriErrorRed, fontWeight = FontWeight.Bold)
                        }
                    }

                    HorizontalDivider(color = SatoriBorderDark, modifier = Modifier.padding(vertical = 4.dp))

                    var soundEnabled by remember { mutableStateOf(AudioFeedbackManager.isSoundEnabled) }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                            Text("Audio Chimes & Sound Effects", fontSize = 13.sp, color = SatoriTextPrimary)
                            Text("Play subtle harmonic feedback on completing lessons and quizzes", fontSize = 11.sp, color = SatoriTextSecondary)
                        }
                        Switch(
                            checked = soundEnabled,
                            onCheckedChange = {
                                soundEnabled = it
                                AudioFeedbackManager.isSoundEnabled = it
                                if (it) AudioFeedbackManager.playExercisePassed()
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = SatoriIndigo, checkedTrackColor = SatoriIndigoLight)
                        )
                    }
                }
            }
        }
    }

    // Edit Profile Dialog
    if (showEditProfileDialog) {
        AlertDialog(
            onDismissRequest = { showEditProfileDialog = false },
            title = { Text("Edit Account Profile", fontWeight = FontWeight.Bold, color = SatoriNeonSpark) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = editName,
                        onValueChange = { editName = it },
                        label = { Text("Full Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = editEmail,
                        onValueChange = { editEmail = it },
                        label = { Text("Email Address") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onEditProfile(editName, editEmail)
                        showEditProfileDialog = false
                        Toast.makeText(context, "Profile updated successfully!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SatoriIndigo)
                ) {
                    Text("Save Changes")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditProfileDialog = false }) {
                    Text("Cancel", color = SatoriTextSecondary)
                }
            },
            containerColor = SatoriSurfaceDark
        )
    }

    // Reset Confirmation Dialog
    if (showResetConfirm) {
        AlertDialog(
            onDismissRequest = { showResetConfirm = false },
            title = { Text("Reset Progress?", fontWeight = FontWeight.Bold, color = SatoriErrorRed) },
            text = { Text("This will clear completed lessons, quiz scores, and XP so you can start the course fresh.", fontSize = 13.sp, color = SatoriTextPrimary) },
            confirmButton = {
                Button(
                    onClick = {
                        onResetProgress()
                        showResetConfirm = false
                        Toast.makeText(context, "Progress reset successfully.", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SatoriErrorRed)
                ) {
                    Text("Confirm Reset")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirm = false }) {
                    Text("Cancel", color = SatoriTextSecondary)
                }
            },
            containerColor = SatoriSurfaceDark
        )
    }

    // Certificate Full-Screen Modal
    activeCertificate?.let { cert ->
        CertificateDialog(
            certificate = cert,
            onDismiss = { activeCertificate = null }
        )
    }
}
