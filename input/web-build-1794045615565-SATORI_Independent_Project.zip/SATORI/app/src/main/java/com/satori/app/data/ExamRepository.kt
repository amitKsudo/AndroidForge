package com.satori.app.data

import com.satori.app.model.Difficulty
import com.satori.app.model.ExamQuestion

object ExamRepository {

    val finalExamQuestions: List<ExamQuestion> by lazy {
        listOf(
            // Question 1
            ExamQuestion(
                id = 1,
                question = "What is the primary role of the Python interpreter during program execution?",
                codeSnippet = null,
                options = listOf(
                    "It compiles Python source code directly into hardware machine binary.",
                    "It translates source code into intermediate bytecode (.pyc) and executes it on the Python Virtual Machine (PVM).",
                    "It serves only as a syntax validator without executing instructions.",
                    "It packages code into native operating system executable binaries."
                ),
                correctIndex = 1,
                explanation = "Python compiles source code (.py) into bytecode (.pyc), which is then interpreted by the Python Virtual Machine (PVM).",
                difficulty = Difficulty.BEGINNER,
                category = "Foundations"
            ),

            // Question 2
            ExamQuestion(
                id = 2,
                question = "What is the output of the following statement?",
                codeSnippet = "print(type(5 / 2))",
                options = listOf(
                    "<class 'int'>",
                    "<class 'float'>",
                    "<class 'double'>",
                    "<class 'number'>"
                ),
                correctIndex = 1,
                explanation = "In Python 3, the standard division operator (/) always returns a float, so 5 / 2 evaluates to 2.5 of type float.",
                difficulty = Difficulty.BEGINNER,
                category = "Data Types"
            ),

            // Question 3
            ExamQuestion(
                id = 3,
                question = "What will be printed by the following code snippet?",
                codeSnippet = "text = \"SATORI\"\nprint(text[::-1])",
                options = listOf(
                    "SATORI",
                    "IRO TAS",
                    "IROTA S",
                    "IROTAS"
                ),
                correctIndex = 3,
                explanation = "The slice step of -1 reverses the string sequence, reversing 'SATORI' into 'IROTAS'.",
                difficulty = Difficulty.BEGINNER,
                category = "String Manipulation"
            ),

            // Question 4
            ExamQuestion(
                id = 4,
                question = "What is the outcome of executing this code?",
                codeSnippet = "a = [1, 2, 3]\nb = a\nb.append(4)\nprint(len(a))",
                options = listOf(
                    "3",
                    "4",
                    "An error occurs because lists cannot be assigned.",
                    "None"
                ),
                correctIndex = 1,
                explanation = "Assignment creates a reference to the same list in memory. Mutating 'b' directly mutates the list that 'a' references, so len(a) is 4.",
                difficulty = Difficulty.INTERMEDIATE,
                category = "Memory & References"
            ),

            // Question 5
            ExamQuestion(
                id = 5,
                question = "Which of the following data structures in Python is immutable?",
                codeSnippet = null,
                options = listOf(
                    "list",
                    "dict",
                    "set",
                    "tuple"
                ),
                correctIndex = 3,
                explanation = "Tuples are immutable sequences; once created, their elements cannot be reassigned, added, or removed.",
                difficulty = Difficulty.BEGINNER,
                category = "Data Structures"
            ),

            // Question 6
            ExamQuestion(
                id = 6,
                question = "What will be the output of this code?",
                codeSnippet = "nums = [x * 2 for x in range(5) if x % 2 == 0]\nprint(nums)",
                options = listOf(
                    "[0, 2, 4]",
                    "[0, 4, 8]",
                    "[2, 4, 6]",
                    "[0, 2, 4, 6, 8]"
                ),
                correctIndex = 1,
                explanation = "range(5) yields 0, 1, 2, 3, 4. Even values are 0, 2, 4. Multiplying each by 2 yields [0, 4, 8].",
                difficulty = Difficulty.INTERMEDIATE,
                category = "Comprehensions"
            ),

            // Question 7
            ExamQuestion(
                id = 7,
                question = "What happens when accessing a non-existent key in a dictionary using .get()?",
                codeSnippet = "data = {'name': 'Alice'}\nval = data.get('age', 25)",
                options = listOf(
                    "It raises a KeyError.",
                    "It assigns 'age': 25 into the dictionary and returns 25.",
                    "It returns the provided default value 25 without modifying the dictionary.",
                    "It returns None and discards the default argument."
                ),
                correctIndex = 2,
                explanation = "dict.get(key, default) safely returns the default value if the key does not exist, leaving the dictionary unchanged.",
                difficulty = Difficulty.BEGINNER,
                category = "Dictionaries"
            ),

            // Question 8
            ExamQuestion(
                id = 8,
                question = "What is the output of the following boolean evaluation?",
                codeSnippet = "result = bool(\"\") or bool(0) or bool([]) or bool(\"0\")\nprint(result)",
                options = listOf(
                    "False",
                    "True",
                    "0",
                    "None"
                ),
                correctIndex = 1,
                explanation = "Empty strings, 0, and empty lists evaluate to False. However, non-empty string \"0\" has length 1 and evaluates to True.",
                difficulty = Difficulty.INTERMEDIATE,
                category = "Control Flow"
            ),

            // Question 9
            ExamQuestion(
                id = 9,
                question = "What will be output by this loop with an else clause?",
                codeSnippet = "for n in range(3):\n    if n == 5:\n        break\nelse:\n    print(\"Finished\")",
                options = listOf(
                    "Nothing is printed.",
                    "Finished",
                    "An exception is raised because else cannot be attached to a loop.",
                    "Finished Finished Finished"
                ),
                correctIndex = 1,
                explanation = "A loop's 'else' block executes when the loop finishes naturally without encountering a 'break' statement.",
                difficulty = Difficulty.INTERMEDIATE,
                category = "Control Flow"
            ),

            // Question 10
            ExamQuestion(
                id = 10,
                question = "What is the critical problem with mutable default arguments in functions?",
                codeSnippet = "def append_item(item, target=[]):\n    target.append(item)\n    return target",
                options = listOf(
                    "Python throws a SyntaxError when a list is passed as a default.",
                    "The default list is instantiated only once when the function is defined, sharing state across invocations.",
                    "Default arguments cannot accept lists because lists are hashable.",
                    "The function becomes an anonymous lambda."
                ),
                correctIndex = 1,
                explanation = "Default parameter values are evaluated once when the function definition is executed. A mutable object like a list retains modifications across subsequent calls.",
                difficulty = Difficulty.INTERMEDIATE,
                category = "Functions"
            ),

            // Question 11
            ExamQuestion(
                id = 11,
                question = "What does the *args syntax in a function definition indicate?",
                codeSnippet = "def calculate(*args):\n    pass",
                options = listOf(
                    "It requires all arguments to be pointers in memory.",
                    "It packs any number of positional arguments into a single tuple.",
                    "It unpacks keyword arguments into a dictionary.",
                    "It requires arguments to be typed as integers."
                ),
                correctIndex = 1,
                explanation = "*args collects variable positional arguments into a tuple, allowing functions to accept an arbitrary number of inputs.",
                difficulty = Difficulty.BEGINNER,
                category = "Functions"
            ),

            // Question 12
            ExamQuestion(
                id = 12,
                question = "What is the order of scope resolution defined by Python's LEGB rule?",
                codeSnippet = null,
                options = listOf(
                    "Local -> Enclosing -> Global -> Built-in",
                    "Local -> External -> General -> Binary",
                    "Global -> Local -> Enclosing -> Built-in",
                    "Built-in -> Global -> Enclosing -> Local"
                ),
                correctIndex = 0,
                explanation = "Python resolves names sequentially starting from Local scope, then Enclosing (outer functions), Global (module level), and finally Built-in.",
                difficulty = Difficulty.INTERMEDIATE,
                category = "Scoping"
            ),

            // Question 13
            ExamQuestion(
                id = 13,
                question = "What is the output of the following lambda with map?",
                codeSnippet = "nums = [1, 2, 3]\nres = list(map(lambda x: x ** 2, nums))\nprint(res)",
                options = listOf(
                    "[1, 4, 9]",
                    "[2, 4, 6]",
                    "[1, 2, 3]",
                    "An error because lambdas cannot use the exponent operator."
                ),
                correctIndex = 0,
                explanation = "map applies the squaring function to each element: 1^2=1, 2^2=4, 3^2=9, resulting in [1, 4, 9].",
                difficulty = Difficulty.BEGINNER,
                category = "Functional Programming"
            ),

            // Question 14
            ExamQuestion(
                id = 14,
                question = "What is the difference between '==' and 'is' in Python?",
                codeSnippet = null,
                options = listOf(
                    "'==' checks memory address identity; 'is' checks value equality.",
                    "'==' checks value equality; 'is' checks object identity (same memory address).",
                    "They are exact synonyms and can be used interchangeably.",
                    "'is' converts both operands to booleans before comparison."
                ),
                correctIndex = 1,
                explanation = "The '==' operator checks equality of values, whereas 'is' checks whether two variables point to the exact same object in memory.",
                difficulty = Difficulty.INTERMEDIATE,
                category = "Memory & Operators"
            ),

            // Question 15
            ExamQuestion(
                id = 15,
                question = "What will be printed by the following code?",
                codeSnippet = "a = 256\nb = 256\nprint(a is b)",
                options = listOf(
                    "True",
                    "False",
                    "None",
                    "TypeError"
                ),
                correctIndex = 0,
                explanation = "CPython pre-allocates and caches small integers between -5 and 256, so both variables reference the identical cached object in memory.",
                difficulty = Difficulty.ADVANCED,
                category = "CPython Internals"
            ),

            // Question 16
            ExamQuestion(
                id = 16,
                question = "What does the 'with' statement guarantee when opening a file?",
                codeSnippet = "with open('data.txt', 'r') as f:\n    content = f.read()",
                options = listOf(
                    "It ensures the file is encrypted on disk.",
                    "It ensures the file is automatically closed upon exiting the block, even if an exception occurs.",
                    "It executes the file asynchronously in a separate process thread.",
                    "It validates the file against a predefined JSON schema."
                ),
                correctIndex = 1,
                explanation = "The context manager protocol enters __enter__() and guarantees __exit__() is called, ensuring the file resource is closed reliably.",
                difficulty = Difficulty.BEGINNER,
                category = "File Handling"
            ),

            // Question 17
            ExamQuestion(
                id = 17,
                question = "What is the purpose of the 'finally' clause in an exception block?",
                codeSnippet = null,
                options = listOf(
                    "It executes only when an exception is successfully caught.",
                    "It executes only when NO exception was raised in the try block.",
                    "It always executes regardless of whether an exception was raised, caught, or unhandled.",
                    "It cancels any previous return statements in the function."
                ),
                correctIndex = 2,
                explanation = "The 'finally' clause is guaranteed to run under all circumstances, typically utilized for releasing critical system resources.",
                difficulty = Difficulty.BEGINNER,
                category = "Exception Handling"
            ),

            // Question 18
            ExamQuestion(
                id = 18,
                question = "What is the output of this dictionary comprehension?",
                codeSnippet = "keys = ['a', 'b']\nd = {k: i for i, k in enumerate(keys)}\nprint(d)",
                options = listOf(
                    "{0: 'a', 1: 'b'}",
                    "{'a': 0, 'b': 1}",
                    "{'a': 1, 'b': 2}",
                    "['a': 0, 'b': 1]"
                ),
                correctIndex = 1,
                explanation = "enumerate(keys) produces (0, 'a') and (1, 'b'). The comprehension maps k to i, resulting in {'a': 0, 'b': 1}.",
                difficulty = Difficulty.INTERMEDIATE,
                category = "Comprehensions"
            ),

            // Question 19
            ExamQuestion(
                id = 19,
                question = "What does the 'self' parameter represent in a Python class method?",
                codeSnippet = "class User:\n    def __init__(self, name):\n        self.name = name",
                options = listOf(
                    "A reserved keyword referring to the class definition itself.",
                    "A reference to the specific instance of the object calling the method.",
                    "A pointer to the global namespace module.",
                    "A built-in garbage collection tracker."
                ),
                correctIndex = 1,
                explanation = "'self' is an explicit reference to the current instance of the class being manipulated.",
                difficulty = Difficulty.BEGINNER,
                category = "Object-Oriented Programming"
            ),

            // Question 20
            ExamQuestion(
                id = 20,
                question = "What is the difference between __str__ and __repr__ dunder methods?",
                codeSnippet = null,
                options = listOf(
                    "__str__ is for human-readable end-user display; __repr__ is for unambiguous, machine-readable developer inspection.",
                    "__repr__ is for string concatenation; __str__ is for console printing only.",
                    "__str__ must return an integer; __repr__ must return a string.",
                    "They are identical and cannot both be defined in the same class."
                ),
                correctIndex = 0,
                explanation = "__str__ provides an informal, readable presentation for users, while __repr__ provides an unambiguous representation primarily for debugging.",
                difficulty = Difficulty.INTERMEDIATE,
                category = "Object-Oriented Programming"
            ),

            // Question 21
            ExamQuestion(
                id = 21,
                question = "What will be the output of this inheritance code?",
                codeSnippet = "class Base:\n    val = 10\nclass Child(Base):\n    pass\nChild.val = 20\nprint(Base.val)",
                options = listOf(
                    "20",
                    "10",
                    "None",
                    "AttributeError"
                ),
                correctIndex = 1,
                explanation = "Assigning to Child.val sets a class attribute directly on the Child class namespace, leaving Base.val unchanged at 10.",
                difficulty = Difficulty.INTERMEDIATE,
                category = "Object-Oriented Programming"
            ),

            // Question 22
            ExamQuestion(
                id = 22,
                question = "What makes a function a generator in Python?",
                codeSnippet = null,
                options = listOf(
                    "Using the @generator decorator above the function header.",
                    "Containing the 'yield' keyword instead of or in addition to 'return'.",
                    "Inheriting from collections.abc.Generator.",
                    "Accepting only generator expressions as input parameters."
                ),
                correctIndex = 1,
                explanation = "The presence of the 'yield' keyword turns a regular function into a generator factory that produces a generator iterator.",
                difficulty = Difficulty.INTERMEDIATE,
                category = "Generators & Iterators"
            ),

            // Question 23
            ExamQuestion(
                id = 23,
                question = "What is the advantage of using a generator over returning a complete list?",
                codeSnippet = null,
                options = listOf(
                    "Generators compute values lazily on demand, using O(1) memory regardless of sequence size.",
                    "Generators execute in C rather than Python for 100x faster execution.",
                    "Generators permit random access via indexing [i] without computation.",
                    "Generators prevent all runtime exceptions."
                ),
                correctIndex = 0,
                explanation = "Generators evaluate one item at a time (lazy evaluation), avoiding allocating large memory buffers for massive sequences.",
                difficulty = Difficulty.INTERMEDIATE,
                category = "Generators & Iterators"
            ),

            // Question 24
            ExamQuestion(
                id = 24,
                question = "What is the output of the following generator consumption?",
                codeSnippet = "def count():\n    yield 1\n    yield 2\ng = count()\nprint(next(g) + next(g))",
                options = listOf(
                    "1",
                    "2",
                    "3",
                    "StopIteration"
                ),
                correctIndex = 2,
                explanation = "First next(g) yields 1, second next(g) yields 2. 1 + 2 evaluates to 3.",
                difficulty = Difficulty.INTERMEDIATE,
                category = "Generators & Iterators"
            ),

            // Question 25
            ExamQuestion(
                id = 25,
                question = "What does the @decorator syntax do to a function?",
                codeSnippet = "@my_decorator\ndef greet():\n    pass",
                options = listOf(
                    "It converts the function into an asynchronous coroutine.",
                    "It is syntactic sugar equivalent to: greet = my_decorator(greet).",
                    "It compiles the function into native C code.",
                    "It executes the function immediately upon import."
                ),
                correctIndex = 1,
                explanation = "The @decorator syntax is syntactic sugar that passes the decorated function into the callable decorator and rebinds the symbol.",
                difficulty = Difficulty.ADVANCED,
                category = "Decorators"
            ),

            // Question 26
            ExamQuestion(
                id = 26,
                question = "What is the purpose of functools.wraps inside a decorator?",
                codeSnippet = null,
                options = listOf(
                    "To speed up execution time by caching return values.",
                    "To preserve the original function's metadata (__name__, __doc__, and signature).",
                    "To convert positional arguments into keyword arguments.",
                    "To prevent recursion depth limit errors."
                ),
                correctIndex = 1,
                explanation = "@functools.wraps copies the original function's identity attributes to the wrapper function, avoiding losing __name__ or docstrings.",
                difficulty = Difficulty.ADVANCED,
                category = "Decorators"
            ),

            // Question 27
            ExamQuestion(
                id = 27,
                question = "What is the output of the following string formatting operation?",
                codeSnippet = "val = 42\nprint(f\"{val:05d}\")",
                options = listOf(
                    "42000",
                    "00042",
                    "042",
                    "42.000"
                ),
                correctIndex = 1,
                explanation = "The format specifier '05d' indicates a decimal integer padded with leading zeros to a minimum width of 5 characters, producing '00042'.",
                difficulty = Difficulty.INTERMEDIATE,
                category = "String Manipulation"
            ),

            // Question 28
            ExamQuestion(
                id = 28,
                question = "What will be printed by the following code?",
                codeSnippet = "items = [1, 2, 3]\nitems[1:2] = [8, 9]\nprint(items)",
                options = listOf(
                    "[1, [8, 9], 3]",
                    "[1, 8, 9, 3]",
                    "[1, 8, 3]",
                    "[8, 9, 3]"
                ),
                correctIndex = 1,
                explanation = "Slice assignment replaces the slice [1:2] (which contains element 2) with the elements of [8, 9], resulting in [1, 8, 9, 3].",
                difficulty = Difficulty.ADVANCED,
                category = "Data Structures"
            ),

            // Question 29
            ExamQuestion(
                id = 29,
                question = "What is the output of this set operation?",
                codeSnippet = "a = {1, 2, 3}\nb = {3, 4, 5}\nprint(a ^ b)",
                options = listOf(
                    "{3}",
                    "{1, 2, 3, 4, 5}",
                    "{1, 2, 4, 5}",
                    "set()"
                ),
                correctIndex = 2,
                explanation = "The caret (^) operator computes the symmetric difference, returning elements present in either set but NOT in both.",
                difficulty = Difficulty.INTERMEDIATE,
                category = "Sets"
            ),

            // Question 30
            ExamQuestion(
                id = 30,
                question = "What will be the result of executing this code?",
                codeSnippet = "x = (1)\nprint(type(x))",
                options = listOf(
                    "<class 'tuple'>",
                    "<class 'int'>",
                    "<class 'list'>",
                    "<class 'set'>"
                ),
                correctIndex = 1,
                explanation = "Parentheses alone do not create a tuple; a trailing comma is required (e.g. (1,)). Thus (1) is merely an integer in grouping parentheses.",
                difficulty = Difficulty.BEGINNER,
                category = "Data Types"
            ),

            // Question 31
            ExamQuestion(
                id = 31,
                question = "What happens if a function executes without an explicit return statement?",
                codeSnippet = "def no_op():\n    x = 10",
                options = listOf(
                    "It returns 0.",
                    "It returns None.",
                    "It returns False.",
                    "It raises a ReturnValueMissingException."
                ),
                correctIndex = 1,
                explanation = "In Python, functions that reach the end of their body without a return statement implicitly return None.",
                difficulty = Difficulty.BEGINNER,
                category = "Functions"
            ),

            // Question 32
            ExamQuestion(
                id = 32,
                question = "What will be printed by the following code?",
                codeSnippet = "def outer():\n    x = 'outer'\n    def inner():\n        nonlocal x\n        x = 'inner'\n    inner()\n    return x\nprint(outer())",
                options = listOf(
                    "outer",
                    "inner",
                    "None",
                    "UnboundLocalError"
                ),
                correctIndex = 1,
                explanation = "The 'nonlocal' keyword binds 'x' to the nearest enclosing scope variable, allowing the inner function to rebind outer's 'x'.",
                difficulty = Difficulty.ADVANCED,
                category = "Scoping"
            ),

            // Question 33
            ExamQuestion(
                id = 33,
                question = "How does Python handle garbage collection for cyclic references?",
                codeSnippet = null,
                options = listOf(
                    "Python relies solely on reference counting and leaks cyclic memory.",
                    "A cyclic generational garbage collector inspects container objects to collect unreachable reference cycles.",
                    "The operating system automatically cleans cycles every minute.",
                    "Cycles are prohibited by the Python compiler."
                ),
                correctIndex = 1,
                explanation = "While reference counting handles immediate cleanup, Python's generational cyclic garbage collector identifies and reclaims isolated reference loops.",
                difficulty = Difficulty.ADVANCED,
                category = "CPython Internals"
            ),

            // Question 34
            ExamQuestion(
                id = 34,
                question = "What will be printed by this code snippet?",
                codeSnippet = "values = [1, 2, 3, 4]\nprint(values[-3:-1])",
                options = listOf(
                    "[2, 3]",
                    "[1, 2, 3]",
                    "[2, 3, 4]",
                    "[3, 2]"
                ),
                correctIndex = 0,
                explanation = "Negative indexing counts from the end: index -3 is element 2, and index -1 is element 4 (exclusive). The slice evaluates to [2, 3].",
                difficulty = Difficulty.INTERMEDIATE,
                category = "String & List Slicing"
            ),

            // Question 35
            ExamQuestion(
                id = 35,
                question = "What is the output of the following zip function?",
                codeSnippet = "letters = ['a', 'b']\nnumbers = [1, 2, 3]\nprint(list(zip(letters, numbers)))",
                options = listOf(
                    "[('a', 1), ('b', 2), (None, 3)]",
                    "[('a', 1), ('b', 2)]",
                    "[('a', 1), ('b', 2), ('b', 3)]",
                    "ValueError: sequence lengths do not match"
                ),
                correctIndex = 1,
                explanation = "The standard zip() function stops as soon as the shortest input iterable is exhausted, producing [('a', 1), ('b', 2)].",
                difficulty = Difficulty.INTERMEDIATE,
                category = "Built-in Functions"
            ),

            // Question 36
            ExamQuestion(
                id = 36,
                question = "Which exception is raised when trying to convert an invalid string to an integer?",
                codeSnippet = "int(\"abc\")",
                options = listOf(
                    "TypeError",
                    "ValueError",
                    "ConversionError",
                    "CastError"
                ),
                correctIndex = 1,
                explanation = "When an argument has the right type (string) but an inappropriate value ('abc'), Python raises a ValueError.",
                difficulty = Difficulty.BEGINNER,
                category = "Exception Handling"
            ),

            // Question 37
            ExamQuestion(
                id = 37,
                question = "What will be printed by the following code?",
                codeSnippet = "data = {True: 'yes', 1: 'one', 1.0: 'point_one'}\nprint(len(data))",
                options = listOf(
                    "3",
                    "1",
                    "2",
                    "TypeError"
                ),
                correctIndex = 1,
                explanation = "In Python, True == 1 == 1.0 and hash(True) == hash(1) == hash(1.0). They are considered duplicate keys, overwriting each other to a single entry.",
                difficulty = Difficulty.ADVANCED,
                category = "Dictionaries & Hashing"
            ),

            // Question 38
            ExamQuestion(
                id = 38,
                question = "What is the output of this unpacking operation?",
                codeSnippet = "first, *middle, last = [10, 20, 30, 40, 50]\nprint(middle)",
                options = listOf(
                    "20",
                    "[20, 30, 40]",
                    "(20, 30, 40)",
                    "[30]"
                ),
                correctIndex = 1,
                explanation = "Extended iterable unpacking assigns the first element to 'first', the last element to 'last', and packs all intermediate elements into a list: [20, 30, 40].",
                difficulty = Difficulty.INTERMEDIATE,
                category = "Unpacking"
            ),

            // Question 39
            ExamQuestion(
                id = 39,
                question = "What will be the output of the following code?",
                codeSnippet = "def test():\n    try:\n        return 1\n    finally:\n        return 2\nprint(test())",
                options = listOf(
                    "1",
                    "2",
                    "None",
                    "1 then 2"
                ),
                correctIndex = 1,
                explanation = "The 'finally' block is executed before leaving the function, and an explicit return in finally overrides the prior return value in the try block.",
                difficulty = Difficulty.ADVANCED,
                category = "Exception Handling"
            ),

            // Question 40
            ExamQuestion(
                id = 40,
                question = "What does the @property decorator allow a method to do?",
                codeSnippet = "class Circle:\n    @property\n    def radius(self):\n        return 5",
                options = listOf(
                    "Make the method accessible as an attribute without parenthesis: circle.radius.",
                    "Prevent the method from being overridden in subclasses.",
                    "Store the return value in a persistent database automatically.",
                    "Execute the method whenever any attribute in the class is accessed."
                ),
                correctIndex = 0,
                explanation = "The @property decorator defines getter methods that can be accessed using attribute syntax without parentheses.",
                difficulty = Difficulty.INTERMEDIATE,
                category = "Object-Oriented Programming"
            ),

            // Question 41
            ExamQuestion(
                id = 41,
                question = "What is the output of this string split operation?",
                codeSnippet = "s = \"a,b,,c\"\nparts = s.split(\",\")\nprint(len(parts))",
                options = listOf(
                    "3",
                    "4",
                    "2",
                    "5"
                ),
                correctIndex = 1,
                explanation = "split(',') preserves empty strings between adjacent delimiters: ['a', 'b', '', 'c'], resulting in 4 elements.",
                difficulty = Difficulty.INTERMEDIATE,
                category = "String Manipulation"
            ),

            // Question 42
            ExamQuestion(
                id = 42,
                question = "What will be output by the following code?",
                codeSnippet = "x = [1, 2]\ny = x * 2\ny[0] = 99\nprint(x[0])",
                options = listOf(
                    "99",
                    "1",
                    "198",
                    "IndexError"
                ),
                correctIndex = 1,
                explanation = "The repetition operator (*) on integers creates a new list with duplicated elements. Modifying 'y' does not mutate 'x'.",
                difficulty = Difficulty.INTERMEDIATE,
                category = "Data Structures"
            ),

            // Question 43
            ExamQuestion(
                id = 43,
                question = "What does the __all__ variable in an __init__.py file control?",
                codeSnippet = "__all__ = ['func_a', 'ClassB']",
                options = listOf(
                    "It defines which variables are exported when a client uses: from module import *.",
                    "It imports all modules in the directory into memory.",
                    "It forces garbage collection on all module objects.",
                    "It restricts permissions so only those objects can be instantiated."
                ),
                correctIndex = 0,
                explanation = "__all__ is a list of strings that defines the public symbol interface exported when using wildcard import ('from module import *').",
                difficulty = Difficulty.ADVANCED,
                category = "Modules & Packages"
            ),

            // Question 44
            ExamQuestion(
                id = 44,
                question = "What will be printed by the following code?",
                codeSnippet = "print(round(2.5), round(3.5))",
                options = listOf(
                    "3 4",
                    "2 4",
                    "2 3",
                    "3 3"
                ),
                correctIndex = 1,
                explanation = "Python 3 uses bankers' rounding (round half to even). 2.5 rounds down to 2, and 3.5 rounds up to 4.",
                difficulty = Difficulty.ADVANCED,
                category = "Core Math & Precision"
            ),

            // Question 45
            ExamQuestion(
                id = 45,
                question = "What is the output of the following lambda invocation?",
                codeSnippet = "f = lambda x, y=10: x * y\nprint(f(5))",
                options = listOf(
                    "50",
                    "5",
                    "TypeError: missing required argument 'y'",
                    "10"
                ),
                correctIndex = 0,
                explanation = "Lambdas support default arguments just like regular functions. x=5 and default y=10, so 5 * 10 = 50.",
                difficulty = Difficulty.BEGINNER,
                category = "Functions"
            ),

            // Question 46
            ExamQuestion(
                id = 46,
                question = "What does the pass statement do in Python?",
                codeSnippet = "def placeholder():\n    pass",
                options = listOf(
                    "It skips the remainder of the current function and returns True.",
                    "It acts as a null operation placeholder where code is syntactically required but no action should be performed.",
                    "It yields control to the operating system thread scheduler.",
                    "It terminates the program immediately."
                ),
                correctIndex = 1,
                explanation = "'pass' is a syntactic null-statement used as a stub or placeholder where an indented block is required.",
                difficulty = Difficulty.BEGINNER,
                category = "Foundations"
            ),

            // Question 47
            ExamQuestion(
                id = 47,
                question = "What will be the output of this code?",
                codeSnippet = "items = ['cat', 'elephant', 'dog']\nitems.sort(key=len)\nprint(items[0])",
                options = listOf(
                    "cat",
                    "elephant",
                    "dog",
                    "None"
                ),
                correctIndex = 0,
                explanation = "Sorting by len orders items by string length: 'cat' (3), 'dog' (3), 'elephant' (8). Python's Timsort is stable, maintaining 'cat' as the first element.",
                difficulty = Difficulty.INTERMEDIATE,
                category = "Sorting & Algorithms"
            ),

            // Question 48
            ExamQuestion(
                id = 48,
                question = "What is the outcome of attempting to use a list as a dictionary key?",
                codeSnippet = "d = {[1, 2]: 'val'}",
                options = listOf(
                    "The dictionary is created successfully.",
                    "TypeError: unhashable type: 'list'",
                    "KeyError: [1, 2]",
                    "ValueError: list cannot be hashed"
                ),
                correctIndex = 1,
                explanation = "Dictionary keys must be hashable and immutable. Lists are mutable and do not implement __hash__, raising TypeError: unhashable type: 'list'.",
                difficulty = Difficulty.INTERMEDIATE,
                category = "Dictionaries & Hashing"
            ),

            // Question 49
            ExamQuestion(
                id = 49,
                question = "What will be printed by the following code?",
                codeSnippet = "x = [1, 2, 3]\nprint(x.pop(0))\nprint(x)",
                options = listOf(
                    "3 and [1, 2]",
                    "1 and [2, 3]",
                    "0 and [1, 2, 3]",
                    "None and [2, 3]"
                ),
                correctIndex = 1,
                explanation = "pop(index) removes and returns the item at the specified index. pop(0) removes and returns element 1, leaving [2, 3].",
                difficulty = Difficulty.BEGINNER,
                category = "Data Structures"
            ),

            // Question 50
            ExamQuestion(
                id = 50,
                question = "What is the output of the following recursion example?",
                codeSnippet = "def solve(n):\n    if n <= 1:\n        return 1\n    return n * solve(n - 1)\nprint(solve(4))",
                options = listOf(
                    "24",
                    "16",
                    "12",
                    "10"
                ),
                correctIndex = 0,
                explanation = "solve computes the factorial of 4: 4 * 3 * 2 * 1 = 24.",
                difficulty = Difficulty.INTERMEDIATE,
                category = "Algorithms & Recursion"
            )
        )
    }
}
