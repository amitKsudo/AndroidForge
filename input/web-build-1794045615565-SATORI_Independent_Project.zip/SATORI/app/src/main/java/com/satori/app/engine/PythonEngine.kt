package com.satori.app.engine

import com.satori.app.model.ExecutionResult
import com.satori.app.model.TestCase

/**
 * Lightweight, pure-Kotlin Python evaluation engine.
 * Safely parses and executes standard beginner-to-intermediate Python constructs:
 * - print(), type(), len(), range(), sum(), min(), max(), abs(), sorted(), int(), float(), str()
 * - Variables, assignments, augmented assignments (+=, -=, *=, /=)
 * - Lists, dictionaries, tuples, f-strings, string slicing
 * - Branching: if, elif, else
 * - Loops: for, while, break, continue
 * - Functions: def, return
 * - Infinite loop protection (step limit)
 */
object PythonEngine {

    private const val MAX_STEPS = 2000

    fun execute(code: String, customInput: String = ""): ExecutionResult {
        val startTime = System.currentTimeMillis()
        val stdout = StringBuilder()
        val stderr = StringBuilder()

        try {
            val lines = code.lines()
            val env = mutableMapOf<String, Any?>()
            val functions = mutableMapOf<String, FunctionDef>()
            val inputLines = customInput.lines().filter { it.isNotBlank() }.toMutableList()

            // Pre-scan functions
            var idx = 0
            val cleanedLines = mutableListOf<String>()
            while (idx < lines.size) {
                val rawLine = lines[idx]
                val trimmed = rawLine.trim()
                if (trimmed.startsWith("def ") && trimmed.endsWith(":")) {
                    val signature = trimmed.removePrefix("def ").removeSuffix(":")
                    val funcName = signature.substringBefore("(").trim()
                    val params = signature.substringAfter("(").substringBeforeLast(")")
                        .split(",")
                        .map { it.trim() }
                        .filter { it.isNotEmpty() }

                    val funcBody = mutableListOf<String>()
                    val baseIndent = getIndentLevel(rawLine)
                    idx++
                    while (idx < lines.size) {
                        val nextLine = lines[idx]
                        if (nextLine.isBlank()) {
                            idx++
                            continue
                        }
                        val nextIndent = getIndentLevel(nextLine)
                        if (nextIndent > baseIndent) {
                            funcBody.add(nextLine)
                            idx++
                        } else {
                            break
                        }
                    }
                    functions[funcName] = FunctionDef(funcName, params, funcBody)
                } else {
                    cleanedLines.add(rawLine)
                    idx++
                }
            }

            // Execute main script
            executeBlock(
                lines = cleanedLines,
                startIndex = 0,
                endIndex = cleanedLines.size,
                env = env,
                functions = functions,
                stdout = stdout,
                inputLines = inputLines,
                stepCounter = IntArray(1) { 0 }
            )

            val duration = System.currentTimeMillis() - startTime
            val outputText = stdout.toString()
            return ExecutionResult(
                stdout = if (outputText.isEmpty()) "(Program finished with no output)" else outputText.trimEnd(),
                stderr = "",
                executionTimeMs = duration,
                success = true
            )
        } catch (e: Exception) {
            val duration = System.currentTimeMillis() - startTime
            val errorMsg = e.message ?: "RuntimeError"
            return ExecutionResult(
                stdout = stdout.toString().trimEnd(),
                stderr = "Traceback (most recent call last):\n$errorMsg",
                executionTimeMs = duration,
                success = false
            )
        }
    }

    fun evaluateExercise(code: String, testCases: List<TestCase>): Pair<Boolean, String> {
        if (testCases.isEmpty()) {
            val res = execute(code)
            return Pair(res.success, if (res.success) "All checks passed!" else res.stderr)
        }

        for ((index, tc) in testCases.withIndex()) {
            val result = execute(code, tc.input)
            if (!result.success) {
                return Pair(false, "Test Case #${index + 1} Failed: ${result.stderr}")
            }
            val actual = result.stdout.trim()
            val expected = tc.expectedOutput.trim()
            if (actual != expected) {
                return Pair(
                    false,
                    "Test Case #${index + 1} Failed!\nExpected output: \"$expected\"\nActual output: \"$actual\""
                )
            }
        }
        return Pair(true, "All ${testCases.size} test cases passed successfully! (+30 XP)")
    }

    private data class FunctionDef(
        val name: String,
        val params: List<String>,
        val body: List<String>
    )

    private fun getIndentLevel(line: String): Int {
        var count = 0
        for (ch in line) {
            if (ch == ' ') count++
            else if (ch == '\t') count += 4
            else break
        }
        return count
    }

    private fun executeBlock(
        lines: List<String>,
        startIndex: Int,
        endIndex: Int,
        env: MutableMap<String, Any?>,
        functions: Map<String, FunctionDef>,
        stdout: StringBuilder,
        inputLines: MutableList<String>,
        stepCounter: IntArray
    ): Any? {
        var i = startIndex
        while (i < endIndex) {
            stepCounter[0]++
            if (stepCounter[0] > MAX_STEPS) {
                throw RuntimeException("ExecutionLimitExceeded: Infinite loop detected or maximum execution steps ($MAX_STEPS) exceeded.")
            }

            val line = lines[i]
            val trimmed = line.trim()

            // Skip empty or comment lines
            if (trimmed.isEmpty() || trimmed.startsWith("#")) {
                i++
                continue
            }

            // Return statement inside function
            if (trimmed.startsWith("return")) {
                val expr = trimmed.removePrefix("return").trim()
                return if (expr.isEmpty()) null else evalExpression(expr, env, functions)
            }

            // Break / Continue
            if (trimmed == "break") return "BREAK_SIGNAL"
            if (trimmed == "continue") return "CONTINUE_SIGNAL"
            if (trimmed == "pass") {
                i++
                continue
            }

            // IF / ELIF / ELSE branching
            if (trimmed.startsWith("if ") && trimmed.endsWith(":")) {
                val baseIndent = getIndentLevel(line)
                var handled = false

                // Process IF branch
                val ifCondition = trimmed.removePrefix("if ").removeSuffix(":").trim()
                val branchBody = mutableListOf<String>()
                i++
                while (i < endIndex) {
                    val l = lines[i]
                    if (l.isBlank()) { i++; continue }
                    val ind = getIndentLevel(l)
                    if (ind > baseIndent) {
                        branchBody.add(l)
                        i++
                    } else {
                        break
                    }
                }

                if (isTruthy(evalExpression(ifCondition, env, functions))) {
                    val ret = executeBlock(branchBody, 0, branchBody.size, env, functions, stdout, inputLines, stepCounter)
                    if (ret != null) return ret
                    handled = true
                }

                // Check subsequent elif / else branches
                while (i < endIndex) {
                    val nextLine = lines[i]
                    val nextTrimmed = nextLine.trim()
                    val nextIndent = getIndentLevel(nextLine)
                    if (nextIndent != baseIndent) break

                    if (nextTrimmed.startsWith("elif ") && nextTrimmed.endsWith(":")) {
                        val elifCond = nextTrimmed.removePrefix("elif ").removeSuffix(":").trim()
                        val elifBody = mutableListOf<String>()
                        i++
                        while (i < endIndex) {
                            val l = lines[i]
                            if (l.isBlank()) { i++; continue }
                            if (getIndentLevel(l) > baseIndent) {
                                elifBody.add(l)
                                i++
                            } else break
                        }
                        if (!handled && isTruthy(evalExpression(elifCond, env, functions))) {
                            val ret = executeBlock(elifBody, 0, elifBody.size, env, functions, stdout, inputLines, stepCounter)
                            if (ret != null) return ret
                            handled = true
                        }
                    } else if (nextTrimmed == "else:") {
                        val elseBody = mutableListOf<String>()
                        i++
                        while (i < endIndex) {
                            val l = lines[i]
                            if (l.isBlank()) { i++; continue }
                            if (getIndentLevel(l) > baseIndent) {
                                elseBody.add(l)
                                i++
                            } else break
                        }
                        if (!handled) {
                            val ret = executeBlock(elseBody, 0, elseBody.size, env, functions, stdout, inputLines, stepCounter)
                            if (ret != null) return ret
                            handled = true
                        }
                        break
                    } else {
                        break
                    }
                }
                continue
            }

            // FOR loop
            if (trimmed.startsWith("for ") && trimmed.endsWith(":")) {
                val header = trimmed.removePrefix("for ").removeSuffix(":")
                val varName = header.substringBefore(" in ").trim()
                val iterExpr = header.substringAfter(" in ").trim()
                val baseIndent = getIndentLevel(line)

                val loopBody = mutableListOf<String>()
                i++
                while (i < endIndex) {
                    val l = lines[i]
                    if (l.isBlank()) { i++; continue }
                    if (getIndentLevel(l) > baseIndent) {
                        loopBody.add(l)
                        i++
                    } else break
                }

                val iterable = evalExpression(iterExpr, env, functions)
                val items = toIterable(iterable)
                for (item in items) {
                    env[varName] = item
                    val res = executeBlock(loopBody, 0, loopBody.size, env, functions, stdout, inputLines, stepCounter)
                    if (res == "BREAK_SIGNAL") break
                    if (res == "CONTINUE_SIGNAL") continue
                    if (res != null) return res
                }
                continue
            }

            // WHILE loop
            if (trimmed.startsWith("while ") && trimmed.endsWith(":")) {
                val condition = trimmed.removePrefix("while ").removeSuffix(":").trim()
                val baseIndent = getIndentLevel(line)

                val loopBody = mutableListOf<String>()
                i++
                while (i < endIndex) {
                    val l = lines[i]
                    if (l.isBlank()) { i++; continue }
                    if (getIndentLevel(l) > baseIndent) {
                        loopBody.add(l)
                        i++
                    } else break
                }

                while (isTruthy(evalExpression(condition, env, functions))) {
                    val res = executeBlock(loopBody, 0, loopBody.size, env, functions, stdout, inputLines, stepCounter)
                    if (res == "BREAK_SIGNAL") break
                    if (res == "CONTINUE_SIGNAL") continue
                    if (res != null) return res
                }
                continue
            }

            // Standard line execution
            executeSimpleLine(trimmed, env, functions, stdout, inputLines)
            i++
        }
        return null
    }

    private fun executeSimpleLine(
        trimmed: String,
        env: MutableMap<String, Any?>,
        functions: Map<String, FunctionDef>,
        stdout: StringBuilder,
        inputLines: MutableList<String>
    ) {
        // Method calls on objects: e.g. list.append(x)
        if (trimmed.contains(".append(") && trimmed.endsWith(")")) {
            val target = trimmed.substringBefore(".append(").trim()
            val argExpr = trimmed.substringAfter(".append(").removeSuffix(")").trim()
            val listObj = env[target]
            if (listObj is MutableList<*>) {
                val value = evalExpression(argExpr, env, functions)
                @Suppress("UNCHECKED_CAST")
                (listObj as MutableList<Any?>).add(value)
                return
            }
        }

        // Augmented assignments: +=, -=, *=, /=
        val augOps = listOf("+=", "-=", "*=", "/=")
        for (op in augOps) {
            if (trimmed.contains(op)) {
                val varName = trimmed.substringBefore(op).trim()
                val expr = trimmed.substringAfter(op).trim()
                val current = env[varName]
                val rhs = evalExpression(expr, env, functions)
                env[varName] = applyOperator(op.removeSuffix("="), current, rhs)
                return
            }
        }

        // Normal assignment: var = expr
        if (trimmed.contains("=") && !trimmed.contains("==") && !trimmed.contains("!=") && !trimmed.contains("<=") && !trimmed.contains(">=")) {
            val left = trimmed.substringBefore("=").trim()
            val right = trimmed.substringAfter("=").trim()

            // List or dict item assignment: arr[0] = 5
            if (left.contains("[") && left.endsWith("]")) {
                val containerName = left.substringBefore("[").trim()
                val indexExpr = left.substringAfter("[").removeSuffix("]").trim()
                val container = env[containerName]
                val indexVal = evalExpression(indexExpr, env, functions)
                val value = evalExpression(right, env, functions)

                if (container is MutableList<*>) {
                    val idx = (indexVal as? Number)?.toInt() ?: 0
                    @Suppress("UNCHECKED_CAST")
                    (container as MutableList<Any?>)[idx] = value
                    return
                } else if (container is MutableMap<*, *>) {
                    @Suppress("UNCHECKED_CAST")
                    (container as MutableMap<Any?, Any?>)[indexVal] = value
                    return
                }
            }

            // Multiple assignment: a, b = 1, 2
            if (left.contains(",")) {
                val targets = left.split(",").map { it.trim() }
                val value = evalExpression(right, env, functions)
                val list = toIterable(value)
                for (k in targets.indices) {
                    if (k < list.size) {
                        env[targets[k]] = list[k]
                    }
                }
                return
            }

            // Normal assignment
            env[left] = evalExpression(right, env, functions)
            return
        }

        // Direct expression (e.g. print(...))
        evalExpression(trimmed, env, functions, stdout, inputLines)
    }

    private fun evalExpression(
        rawExpr: String,
        env: MutableMap<String, Any?>,
        functions: Map<String, FunctionDef>,
        stdout: StringBuilder? = null,
        inputLines: MutableList<String>? = null
    ): Any? {
        val expr = rawExpr.trim()
        if (expr.isEmpty()) return null

        // Literals
        if (expr == "True") return true
        if (expr == "False") return false
        if (expr == "None") return null

        // Quoted string
        if ((expr.startsWith("\"") && expr.endsWith("\"")) || (expr.startsWith("'") && expr.endsWith("'"))) {
            return expr.substring(1, expr.length - 1)
        }

        // F-String: f"Hello {name}"
        if ((expr.startsWith("f\"") && expr.endsWith("\"")) || (expr.startsWith("f'") && expr.endsWith("'"))) {
            val template = expr.substring(2, expr.length - 1)
            val regex = Regex("\\{([^}]+)\\}")
            return regex.replace(template) { matchResult ->
                val inner = matchResult.groupValues[1]
                evalExpression(inner, env, functions).toString()
            }
        }

        // Numbers
        expr.toIntOrNull()?.let { return it }
        expr.toDoubleOrNull()?.let { return it }

        // List literal: [1, 2, 3]
        if (expr.startsWith("[") && expr.endsWith("]")) {
            val content = expr.substring(1, expr.length - 1).trim()
            if (content.isEmpty()) return mutableListOf<Any?>()
            val parts = splitArgs(content)
            return parts.map { evalExpression(it, env, functions) }.toMutableList()
        }

        // Dict literal: {"a": 1, "b": 2}
        if (expr.startsWith("{") && expr.endsWith("}")) {
            val content = expr.substring(1, expr.length - 1).trim()
            if (content.isEmpty()) return mutableMapOf<Any?, Any?>()
            val map = mutableMapOf<Any?, Any?>()
            val pairs = splitArgs(content)
            for (pair in pairs) {
                val k = pair.substringBefore(":").trim()
                val v = pair.substringAfter(":").trim()
                map[evalExpression(k, env, functions)] = evalExpression(v, env, functions)
            }
            return map
        }

        // print(...)
        if (expr.startsWith("print(") && expr.endsWith(")")) {
            val inner = expr.removePrefix("print(").removeSuffix(")").trim()
            if (inner.isEmpty()) {
                stdout?.append("\n")
                return null
            }
            val args = splitArgs(inner)
            val printed = args.map { formatValue(evalExpression(it, env, functions)) }
            val lineText = printed.joinToString(" ")
            stdout?.append(lineText)?.append("\n")
            return null
        }

        // input(...)
        if (expr.startsWith("input(") && expr.endsWith(")")) {
            val promptText = expr.removePrefix("input(").removeSuffix(")").trim()
            if (promptText.isNotEmpty()) {
                val p = evalExpression(promptText, env, functions)?.toString() ?: ""
                stdout?.append(p)
            }
            val line = if (!inputLines.isNullOrEmpty()) inputLines.removeAt(0) else ""
            return line
        }

        // len(...)
        if (expr.startsWith("len(") && expr.endsWith(")")) {
            val inner = expr.removePrefix("len(").removeSuffix(")").trim()
            val v = evalExpression(inner, env, functions)
            return when (v) {
                is String -> v.length
                is List<*> -> v.size
                is Map<*, *> -> v.size
                else -> 0
            }
        }

        // range(...)
        if (expr.startsWith("range(") && expr.endsWith(")")) {
            val inner = expr.removePrefix("range(").removeSuffix(")").trim()
            val args = splitArgs(inner).map { (evalExpression(it, env, functions) as? Number)?.toInt() ?: 0 }
            return when (args.size) {
                1 -> (0 until args[0]).toList()
                2 -> (args[0] until args[1]).toList()
                3 -> (args[0] until args[1] step args[2]).toList()
                else -> emptyList<Int>()
            }
        }

        // type(...)
        if (expr.startsWith("type(") && expr.endsWith(")")) {
            val inner = expr.removePrefix("type(").removeSuffix(")").trim()
            val v = evalExpression(inner, env, functions)
            val typeStr = when (v) {
                is Int -> "<class 'int'>"
                is Double -> "<class 'float'>"
                is String -> "<class 'str'>"
                is Boolean -> "<class 'bool'>"
                is List<*> -> "<class 'list'>"
                is Map<*, *> -> "<class 'dict'>"
                else -> "<class 'object'>"
            }
            return typeStr
        }

        // sum(...)
        if (expr.startsWith("sum(") && expr.endsWith(")")) {
            val inner = expr.removePrefix("sum(").removeSuffix(")").trim()
            val list = toIterable(evalExpression(inner, env, functions))
            var total = 0.0
            var allInts = true
            for (item in list) {
                if (item is Number) {
                    total += item.toDouble()
                    if (item !is Int) allInts = false
                }
            }
            return if (allInts) total.toInt() else total
        }

        // str(...), int(...), float(...)
        if (expr.startsWith("str(") && expr.endsWith(")")) {
            val inner = expr.removePrefix("str(").removeSuffix(")").trim()
            return evalExpression(inner, env, functions)?.toString() ?: ""
        }
        if (expr.startsWith("int(") && expr.endsWith(")")) {
            val inner = expr.removePrefix("int(").removeSuffix(")").trim()
            val v = evalExpression(inner, env, functions)
            return (v as? Number)?.toInt() ?: v.toString().toIntOrNull() ?: 0
        }
        if (expr.startsWith("float(") && expr.endsWith(")")) {
            val inner = expr.removePrefix("float(").removeSuffix(")").trim()
            val v = evalExpression(inner, env, functions)
            return (v as? Number)?.toDouble() ?: v.toString().toDoubleOrNull() ?: 0.0
        }

        // Function call: func(a, b)
        for ((fName, fDef) in functions) {
            if (expr.startsWith("$fName(") && expr.endsWith(")")) {
                val inner = expr.removePrefix("$fName(").removeSuffix(")").trim()
                val args = if (inner.isEmpty()) emptyList() else splitArgs(inner).map { evalExpression(it, env, functions) }
                val funcEnv = env.toMutableMap()
                for (k in fDef.params.indices) {
                    if (k < args.size) {
                        funcEnv[fDef.params[k]] = args[k]
                    }
                }
                return executeBlock(fDef.body, 0, fDef.body.size, funcEnv, functions, stdout ?: StringBuilder(), inputLines ?: mutableListOf(), IntArray(1) { 0 })
            }
        }

        // Indexing & Slicing: arr[0], str[1:4]
        if (expr.contains("[") && expr.endsWith("]")) {
            val baseName = expr.substringBefore("[").trim()
            val sliceExpr = expr.substringAfter("[").removeSuffix("]").trim()
            val baseVal = env[baseName] ?: evalExpression(baseName, env, functions)

            if (sliceExpr.contains(":")) {
                // Slicing
                val parts = sliceExpr.split(":")
                val start = parts.getOrNull(0)?.trim()?.let { evalExpression(it, env, functions) as? Int } ?: 0
                val end = parts.getOrNull(1)?.trim()?.let { evalExpression(it, env, functions) as? Int }
                return when (baseVal) {
                    is String -> if (end != null) baseVal.substring(start, minOf(end, baseVal.length)) else baseVal.substring(start)
                    is List<*> -> if (end != null) baseVal.subList(start, minOf(end, baseVal.size)) else baseVal.subList(start, baseVal.size)
                    else -> null
                }
            } else {
                // Single index
                val idx = (evalExpression(sliceExpr, env, functions) as? Number)?.toInt() ?: 0
                if (baseVal is List<*>) {
                    val actualIdx = if (idx < 0) baseVal.size + idx else idx
                    return baseVal.getOrNull(actualIdx)
                } else if (baseVal is String) {
                    val actualIdx = if (idx < 0) baseVal.length + idx else idx
                    return baseVal.getOrNull(actualIdx)?.toString()
                } else if (baseVal is Map<*, *>) {
                    val key = evalExpression(sliceExpr, env, functions)
                    return baseVal[key]
                }
            }
        }

        // Comparisons and Boolean operators
        // "and" / "or"
        if (expr.contains(" and ")) {
            val l = expr.substringBefore(" and ").trim()
            val r = expr.substringAfter(" and ").trim()
            return isTruthy(evalExpression(l, env, functions)) && isTruthy(evalExpression(r, env, functions))
        }
        if (expr.contains(" or ")) {
            val l = expr.substringBefore(" or ").trim()
            val r = expr.substringAfter(" or ").trim()
            return isTruthy(evalExpression(l, env, functions)) || isTruthy(evalExpression(r, env, functions))
        }
        if (expr.startsWith("not ")) {
            val inner = expr.removePrefix("not ").trim()
            return !isTruthy(evalExpression(inner, env, functions))
        }

        // Comparison operators: ==, !=, <=, >=, <, >
        val compOps = listOf("==", "!=", "<=", ">=", "<", ">")
        for (op in compOps) {
            if (expr.contains(" $op ")) {
                val lVal = evalExpression(expr.substringBefore(" $op ").trim(), env, functions)
                val rVal = evalExpression(expr.substringAfter(" $op ").trim(), env, functions)
                return compareValues(op, lVal, rVal)
            }
        }

        // Arithmetic: +, -, *, /, //, %, **
        val arithOps = listOf("+", "-", "*", "/", "//", "%", "**")
        for (op in arithOps) {
            val pattern = " $op "
            if (expr.contains(pattern)) {
                val lVal = evalExpression(expr.substringBefore(pattern).trim(), env, functions)
                val rVal = evalExpression(expr.substringAfter(pattern).trim(), env, functions)
                return applyOperator(op, lVal, rVal)
            }
        }

        // Variable lookup
        if (env.containsKey(expr)) {
            return env[expr]
        }

        return expr
    }

    private fun compareValues(op: String, left: Any?, right: Any?): Boolean {
        if (op == "==") return left == right
        if (op == "!=") return left != right

        val lNum = (left as? Number)?.toDouble()
        val rNum = (right as? Number)?.toDouble()
        if (lNum != null && rNum != null) {
            return when (op) {
                "<" -> lNum < rNum
                "<=" -> lNum <= rNum
                ">" -> lNum > rNum
                ">=" -> lNum >= rNum
                else -> false
            }
        }
        return false
    }

    private fun applyOperator(op: String, left: Any?, right: Any?): Any? {
        if (op == "+" && (left is String || right is String)) {
            return left.toString() + right.toString()
        }
        if (op == "+" && left is List<*> && right is List<*>) {
            return (left + right).toMutableList()
        }
        val lNum = (left as? Number)?.toDouble() ?: 0.0
        val rNum = (right as? Number)?.toDouble() ?: 0.0
        val isIntResult = left is Int && right is Int && op != "/"

        val res = when (op) {
            "+" -> lNum + rNum
            "-" -> lNum - rNum
            "*" -> lNum * rNum
            "/" -> if (rNum == 0.0) throw ArithmeticException("ZeroDivisionError: division by zero") else lNum / rNum
            "//" -> if (rNum == 0.0) throw ArithmeticException("ZeroDivisionError: integer division by zero") else kotlin.math.floor(lNum / rNum)
            "%" -> if (rNum == 0.0) throw ArithmeticException("ZeroDivisionError: modulo by zero") else lNum % rNum
            "**" -> Math.pow(lNum, rNum)
            else -> lNum
        }

        return if (isIntResult) res.toInt() else res
    }

    private fun isTruthy(v: Any?): Boolean {
        return when (v) {
            null -> false
            is Boolean -> v
            is Number -> v.toDouble() != 0.0
            is String -> v.isNotEmpty()
            is List<*> -> v.isNotEmpty()
            is Map<*, *> -> v.isNotEmpty()
            else -> true
        }
    }

    private fun toIterable(value: Any?): List<Any?> {
        return when (value) {
            is List<*> -> value
            is String -> value.map { it.toString() }
            is Map<*, *> -> value.keys.toList()
            else -> emptyList()
        }
    }

    private fun formatValue(v: Any?): String {
        return when (v) {
            null -> "None"
            is Boolean -> if (v) "True" else "False"
            is Double -> if (v % 1.0 == 0.0) v.toInt().toString() else v.toString()
            else -> v.toString()
        }
    }

    private fun splitArgs(text: String): List<String> {
        val list = mutableListOf<String>()
        var depth = 0
        var inQuotes = false
        var quoteChar = ' '
        val current = StringBuilder()

        for (ch in text) {
            if ((ch == '"' || ch == '\'') && !inQuotes) {
                inQuotes = true
                quoteChar = ch
                current.append(ch)
            } else if (ch == quoteChar && inQuotes) {
                inQuotes = false
                current.append(ch)
            } else if (!inQuotes && (ch == '(' || ch == '[' || ch == '{')) {
                depth++
                current.append(ch)
            } else if (!inQuotes && (ch == ')' || ch == ']' || ch == '}')) {
                depth--
                current.append(ch)
            } else if (!inQuotes && ch == ',' && depth == 0) {
                list.add(current.toString().trim())
                current.clear()
            } else {
                current.append(ch)
            }
        }
        if (current.isNotBlank()) {
            list.add(current.toString().trim())
        }
        return list
    }
}
