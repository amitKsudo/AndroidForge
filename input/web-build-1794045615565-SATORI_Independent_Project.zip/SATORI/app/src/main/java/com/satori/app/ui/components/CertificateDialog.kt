package com.satori.app.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.satori.app.R
import com.satori.app.model.CertificateData
import com.satori.app.ui.theme.*

@Composable
fun CertificateDialog(
    certificate: CertificateData,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .padding(8.dp)
                .testTag("certificate_dialog"),
            shape = RoundedCornerShape(20.dp),
            color = Color(0xFF0F0B1E),
            border = CardDefaults.outlinedCardBorder().copy(brush = Brush.verticalGradient(listOf(SatoriIndigo, SatoriPurple)))
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Modal Top Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = SatoriSuccessGreen.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "OFFICIAL CREDENTIAL",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = SatoriSuccessGreen,
                            letterSpacing = 1.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = SatoriTextSecondary)
                    }
                }

                Spacer(Modifier.height(12.dp))

                // Landscape Certificate (White Background & Formal Design)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(4f / 3f)
                        .shadow(elevation = 16.dp, shape = RoundedCornerShape(12.dp), spotColor = Color.Black.copy(alpha = 0.5f))
                        .testTag("certificate_landscape_card"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp)
                            .border(
                                width = 1.dp,
                                color = Color(0xFFE2E8F0),
                                shape = RoundedCornerShape(8.dp)
                            )
                            .padding(4.dp)
                            .border(
                                width = 0.8.dp,
                                color = Color(0xFFD4AF37), // Subtle gold hairline
                                shape = RoundedCornerShape(6.dp)
                            )
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            // 1. Certificate Header (Emblem + Wordmark)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.ic_satori_user_logo),
                                    contentDescription = "SATORI Emblem",
                                    modifier = Modifier.size(26.dp)
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    text = "SATORI",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 3.sp,
                                    color = Color(0xFF0F172A)
                                )
                            }

                            // 2. Title & Subtitle
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "CERTIFICATE OF COMPLETION",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 2.sp,
                                    color = Color(0xFF854D0E)
                                )
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    text = "This credential certifies that",
                                    fontSize = 9.sp,
                                    color = Color(0xFF64748B),
                                    letterSpacing = 0.5.sp
                                )
                            }

                            // 3. Recipient Name & Course Title
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = certificate.recipientName,
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFF0F172A),
                                    letterSpacing = 0.5.sp,
                                    textAlign = TextAlign.Center
                                )

                                Box(
                                    modifier = Modifier
                                        .width(90.dp)
                                        .height(1.dp)
                                        .background(Color(0xFFD4AF37))
                                )

                                Spacer(Modifier.height(4.dp))

                                Text(
                                    text = "has successfully completed the curriculum and demonstrated competence in",
                                    fontSize = 8.5.sp,
                                    color = Color(0xFF64748B),
                                    textAlign = TextAlign.Center
                                )

                                Text(
                                    text = certificate.courseName,
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF312E81),
                                    textAlign = TextAlign.Center
                                )
                            }

                            // 4. Metadata & Founder Signature
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Bottom
                            ) {
                                // Left Column: Credential Verification
                                Column {
                                    Text(
                                        text = "ISSUE DATE",
                                        fontSize = 7.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF94A3B8)
                                    )
                                    Text(
                                        text = certificate.issueDate,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF334155)
                                    )
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        text = "CREDENTIAL ID",
                                        fontSize = 7.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF94A3B8)
                                    )
                                    Text(
                                        text = certificate.certificateId,
                                        fontSize = 7.5.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF0F172A)
                                    )
                                }

                                // Center Seal: Verified Stamp
                                Surface(
                                    color = Color(0xFFFEF9C3),
                                    shape = CircleShape,
                                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFFD4AF37), Color(0xFFCA8A04)))),
                                    modifier = Modifier.size(34.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            Icons.Default.Verified,
                                            contentDescription = "Verified Seal",
                                            tint = Color(0xFFCA8A04),
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }

                                // Right Column: Founder Signature (Amit Kumar)
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = certificate.founderName,
                                        fontSize = 15.sp,
                                        fontStyle = FontStyle.Italic,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF0F172A),
                                        letterSpacing = 1.sp
                                    )
                                    Box(
                                        modifier = Modifier
                                            .width(80.dp)
                                            .height(0.8.dp)
                                            .background(Color(0xFF94A3B8))
                                    )
                                    Text(
                                        text = certificate.founderName,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF0F172A)
                                    )
                                    Text(
                                        text = "Founder & Lead Architect",
                                        fontSize = 7.sp,
                                        color = Color(0xFF64748B)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("certificate_url", "https://${certificate.verificationUrl}/${certificate.certificateId}"))
                            Toast.makeText(context, "Verification link copied to clipboard.", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Share Link", fontSize = 12.sp)
                    }

                    Button(
                        onClick = {
                            Toast.makeText(context, "Certificate saved to device.", Toast.LENGTH_LONG).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SatoriIndigo),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f).testTag("download_cert_btn")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Download", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
