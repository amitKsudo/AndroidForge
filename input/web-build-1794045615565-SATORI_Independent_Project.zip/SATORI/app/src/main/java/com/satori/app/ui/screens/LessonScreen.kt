package com.satori.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.satori.app.model.Lesson
import com.satori.app.model.UserProfile
import com.satori.app.ui.components.ConceptVisualizerHost
import com.satori.app.ui.components.PythonEditor
import com.satori.app.ui.theme.*
import com.satori.app.util.AudioFeedbackManager

@Composable
fun LessonScreen(
    lesson: Lesson,
    moduleTitle: String,
    userProfile: UserProfile,
    onToggleBookmark: (String) -> Unit,
    onSaveNote: (String, String) -> Unit,
    onMarkCompleted: (String) -> Unit,
    onLaunchQuiz: (Lesson) -> Unit,
    onLaunchExercise: (Lesson) -> Unit,
    onNavigateBack: () -> Unit,
    onNextLesson: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val isBookmarked = userProfile.bookmarkedLessonIds.contains(lesson.id)
    val isCompleted = userProfile.completedLessonIds.contains(lesson.id)
    var showNoteDialog by remember { mutableStateOf(false) }
    var currentNote by remember(lesson.id, userProfile.lessonNotes) {
        mutableStateOf(userProfile.lessonNotes[lesson.id] ?: "")
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("lesson_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        // Navigation Bar & Actions
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier.testTag("lesson_back_btn")
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = SatoriTextSecondary)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    IconButton(
                        onClick = { showNoteDialog = true },
                        modifier = Modifier.testTag("lesson_note_btn")
                    ) {
                        Icon(
                            imageVector = if (currentNote.isNotEmpty()) Icons.Default.StickyNote2 else Icons.Default.EditNote,
                            contentDescription = "Notes",
                            tint = if (currentNote.isNotEmpty()) SatoriPythonGold else SatoriTextSecondary
                        )
                    }

                    IconButton(
                        onClick = { onToggleBookmark(lesson.id) },
                        modifier = Modifier.testTag("lesson_bookmark_btn")
                    ) {
                        Icon(
                            imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            contentDescription = "Bookmark",
                            tint = if (isBookmarked) SatoriNeonSpark else SatoriTextSecondary
                        )
                    }
                }
            }
        }

        // Breadcrumb & Title Header
        item {
            Column {
                Text(
                    text = moduleTitle.uppercase(),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = SatoriIndigoLight,
                    letterSpacing = 1.sp
                )
                Text(
                    text = lesson.title,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        color = SatoriSurfaceHighlightDark,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = lesson.difficulty.name,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = SatoriNeonSpark,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Text(
                        text = "${lesson.readTimeMinutes} min read",
                        fontSize = 12.sp,
                        color = SatoriTextSecondary
                    )
                }
            }
        }

        // Summary Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SatoriSurfaceDark),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(
                    text = lesson.summary,
                    fontSize = 14.sp,
                    color = SatoriTextPrimary,
                    lineHeight = 22.sp,
                    modifier = Modifier.padding(14.dp)
                )
            }
        }

        // Everyday Analogy Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SatoriSurfaceContainerDark),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(SatoriPythonGold.copy(alpha = 0.5f), SatoriIndigo.copy(alpha = 0.5f))))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Lightbulb, contentDescription = null, tint = SatoriPythonGold, modifier = Modifier.size(20.dp))
                        Text(
                            text = "The Everyday Analogy",
                            fontWeight = FontWeight.Bold,
                            color = SatoriPythonGold,
                            fontSize = 14.sp
                        )
                    }
                    Text(
                        text = lesson.analogy,
                        fontSize = 13.sp,
                        color = SatoriTextPrimary,
                        lineHeight = 20.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }
        }

        // Why it matters
        item {
            Column {
                Text("Why This Concept Matters", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
                Text(
                    text = lesson.whyItMatters,
                    fontSize = 13.sp,
                    color = SatoriTextSecondary,
                    lineHeight = 20.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        // In-Depth Conceptual Guide Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SatoriSurfaceDark),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.horizontalGradient(listOf(SatoriIndigo.copy(alpha = 0.5f), SatoriPurple.copy(alpha = 0.5f)))
                )
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.MenuBook, contentDescription = null, tint = SatoriNeonSpark, modifier = Modifier.size(20.dp))
                        Text("In-Depth Conceptual Guide", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
                    }

                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = lesson.explanation,
                        fontSize = 13.5.sp,
                        color = SatoriTextPrimary,
                        lineHeight = 22.sp
                    )

                    Spacer(Modifier.height(14.dp))
                    HorizontalDivider(color = SatoriBorderDark)
                    Spacer(Modifier.height(12.dp))

                    Text("Under The Hood • How Python Executes This:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = SatoriPythonCyan)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "• Execution Order: Python evaluates code strictly top-to-bottom, evaluating inner expressions before outer assignments.\n• Memory Allocation: Values are stored as objects in memory heap, and variable names act as lightweight pointer labels.\n• Safety & Guardrails: If an operation violates data types or syntax rules, Python pauses execution immediately and displays a descriptive traceback.",
                        fontSize = 12.sp,
                        color = SatoriTextSecondary,
                        lineHeight = 19.sp
                    )
                }
            }
        }

        // Syntax Reference Box
        if (lesson.syntax.isNotBlank()) {
            item {
                Surface(
                    color = SatoriCodeBackground,
                    shape = RoundedCornerShape(10.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(SatoriIndigo.copy(alpha = 0.4f), SatoriPurple.copy(alpha = 0.4f)))),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("SYNTAX", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SatoriNeonSpark, letterSpacing = 1.sp)
                        Text(
                            text = lesson.syntax,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 13.sp,
                            color = SatoriPythonCyan,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
        }

        // Interactive Visualizer Model
        item {
            ConceptVisualizerHost(conceptType = lesson.visualConceptType)
        }

        // Line-by-Line Breakdown
        if (lesson.lineByLine.isNotEmpty()) {
            item {
                Column {
                    Text("Line-By-Line Walkthrough", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
                    Spacer(Modifier.height(8.dp))
                    lesson.lineByLine.forEach { lineExp ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SatoriSurfaceDark),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = "Line ${lineExp.lineNumber}: ${lineExp.code}",
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = SatoriPythonGold
                                )
                                Text(
                                    text = lineExp.explanation,
                                    fontSize = 12.sp,
                                    color = SatoriTextSecondary,
                                    modifier = Modifier.padding(top = 2.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Embedded Runnable Code Editor
        item {
            Column {
                Text("Try It In Python", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
                Text("Edit the code below and run it to see Python execute your commands in real time.", fontSize = 12.sp, color = SatoriTextSecondary, modifier = Modifier.padding(top = 2.dp, bottom = 8.dp))
                PythonEditor(initialCode = lesson.exampleCode)
            }
        }

        // Common Mistakes
        if (lesson.commonMistakes.isNotEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SatoriSurfaceDark),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = SatoriWarningOrange, modifier = Modifier.size(18.dp))
                            Text("Common Mistakes to Avoid", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = SatoriWarningOrange)
                        }
                        Spacer(Modifier.height(6.dp))
                        lesson.commonMistakes.forEach { mistake ->
                            Text(
                                text = "• $mistake",
                                fontSize = 12.sp,
                                color = SatoriTextSecondary,
                                modifier = Modifier.padding(vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }

        // Key Takeaways & Core Mental Model
        if (lesson.recap.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = SatoriSurfaceDark),
                    shape = RoundedCornerShape(14.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(SatoriSuccessGreen.copy(alpha = 0.4f), SatoriIndigo.copy(alpha = 0.4f))))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SatoriSuccessGreen, modifier = Modifier.size(20.dp))
                            Text("Key Takeaways & Mental Model", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                        }
                        Spacer(Modifier.height(8.dp))
                        lesson.recap.forEach { item ->
                            Row(
                                modifier = Modifier.padding(vertical = 3.dp),
                                verticalAlignment = Alignment.Top,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .padding(top = 5.dp)
                                        .size(6.dp)
                                        .background(SatoriSuccessGreen, CircleShape)
                                )
                                Text(
                                    text = item,
                                    fontSize = 13.sp,
                                    color = SatoriTextPrimary,
                                    lineHeight = 19.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Action Buttons: Quiz, Exercise, Mark Complete
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 10.dp)) {
                if (lesson.quizQuestions.isNotEmpty()) {
                    Button(
                        onClick = { onLaunchQuiz(lesson) },
                        colors = ButtonDefaults.buttonColors(containerColor = SatoriIndigo),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("take_quiz_btn")
                    ) {
                        Icon(Icons.Default.Quiz, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Take Lesson Quiz (${lesson.quizQuestions.size} MCQs)", fontWeight = FontWeight.Bold)
                    }
                }

                if (lesson.exercise != null) {
                    OutlinedButton(
                        onClick = { onLaunchExercise(lesson) },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = SatoriNeonSpark),
                        border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.horizontalGradient(listOf(SatoriIndigo, SatoriPurple))),
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("coding_exercise_btn")
                    ) {
                        Icon(Icons.Default.Code, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Solve Coding Challenge", fontWeight = FontWeight.Bold)
                    }
                }

                Button(
                    onClick = {
                        AudioFeedbackManager.playLessonComplete()
                        onMarkCompleted(lesson.id)
                        onNextLesson?.invoke() ?: onNavigateBack()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = if (isCompleted) SatoriSurfaceHighlightDark else SatoriSuccessGreen),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("mark_completed_btn")
                ) {
                    Icon(imageVector = if (isCompleted) Icons.Default.Check else Icons.Default.CheckCircleOutline, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(if (isCompleted) "Completed (+50 XP)" else "Mark as Completed (+50 XP)", fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }
    }

    // Notes Dialog
    if (showNoteDialog) {
        var noteDraft by remember { mutableStateOf(currentNote) }
        AlertDialog(
            onDismissRequest = { showNoteDialog = false },
            title = { Text("Personal Notes", fontWeight = FontWeight.Bold, color = SatoriNeonSpark) },
            text = {
                OutlinedTextField(
                    value = noteDraft,
                    onValueChange = { noteDraft = it },
                    placeholder = { Text("Write your key takeaways or questions here...", fontSize = 12.sp, color = SatoriTextMuted) },
                    modifier = Modifier.fillMaxWidth().height(160.dp),
                    textStyle = TextStyle(fontSize = 13.sp, color = SatoriTextPrimary)
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        currentNote = noteDraft
                        onSaveNote(lesson.id, noteDraft)
                        showNoteDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SatoriIndigo)
                ) {
                    Text("Save Note")
                }
            },
            dismissButton = {
                TextButton(onClick = { showNoteDialog = false }) {
                    Text("Cancel", color = SatoriTextSecondary)
                }
            },
            containerColor = SatoriSurfaceDark
        )
    }
}
