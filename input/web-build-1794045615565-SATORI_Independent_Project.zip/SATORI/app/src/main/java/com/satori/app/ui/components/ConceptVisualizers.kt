package com.satori.app.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.satori.app.model.VisualConceptType
import com.satori.app.ui.theme.*

@Composable
fun ConceptVisualizerHost(conceptType: VisualConceptType, modifier: Modifier = Modifier) {
    if (conceptType == VisualConceptType.NONE) return

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("concept_visualizer_host"),
        colors = CardDefaults.cardColors(containerColor = SatoriCodeBackground),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(SatoriIndigo.copy(alpha = 0.5f), SatoriPurple.copy(alpha = 0.5f))))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .background(SatoriIndigo.copy(alpha = 0.2f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Visibility,
                        contentDescription = "Visualizer",
                        tint = SatoriNeonSpark,
                        modifier = Modifier.size(16.dp)
                    )
                }
                Text(
                    text = "SATORI Visual Concept Model",
                    style = MaterialTheme.typography.titleMedium,
                    color = SatoriNeonSpark,
                    fontWeight = FontWeight.Bold
                )
            }
            Text(
                text = "Tap interactive controls to see how Python handles data in memory.",
                style = MaterialTheme.typography.bodySmall,
                color = SatoriTextSecondary,
                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
            )

            when (conceptType) {
                VisualConceptType.VARIABLES -> VariableVisualizer()
                VisualConceptType.LISTS -> ListVisualizer()
                VisualConceptType.LOOPS -> LoopVisualizer()
                VisualConceptType.FUNCTIONS -> FunctionVisualizer()
                VisualConceptType.CONDITIONS -> ConditionVisualizer()
                else -> {}
            }
        }
    }
}

@Composable
fun VariableVisualizer() {
    var storedValue by remember { mutableStateOf("10") }
    var varType by remember { mutableStateOf("int") }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(SatoriSurfaceDark)
                .border(1.dp, SatoriIndigo.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                // Box label tag
                Surface(
                    color = SatoriIndigo,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.padding(bottom = 8.dp)
                ) {
                    Text(
                        text = "Variable Box: score",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }

                // Inner content
                AnimatedContent(
                    targetState = storedValue,
                    transitionSpec = {
                        slideInVertically { height -> height } + fadeIn() togetherWith
                                slideOutVertically { height -> -height } + fadeOut()
                    },
                    label = "variable_box_anim"
                ) { target ->
                    Surface(
                        color = SatoriSurfaceContainerDark,
                        shape = RoundedCornerShape(8.dp),
                        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(SatoriPythonGold, SatoriIndigo)))
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(horizontal = 24.dp, vertical = 14.dp)
                        ) {
                            Text(
                                text = target,
                                color = SatoriPythonGold,
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "<type '$varType'>",
                                color = SatoriPythonCyan,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // Interactive control buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Button(
                onClick = { storedValue = "10"; varType = "int" },
                colors = ButtonDefaults.buttonColors(containerColor = SatoriSurfaceHighlightDark),
                modifier = Modifier.testTag("var_set_10")
            ) {
                Text("score = 10", fontSize = 12.sp, color = SatoriTextPrimary)
            }
            Button(
                onClick = { storedValue = "25"; varType = "int" },
                colors = ButtonDefaults.buttonColors(containerColor = SatoriSurfaceHighlightDark),
                modifier = Modifier.testTag("var_set_25")
            ) {
                Text("score = 25", fontSize = 12.sp, color = SatoriTextPrimary)
            }
            Button(
                onClick = { storedValue = "\"Victory!\""; varType = "str" },
                colors = ButtonDefaults.buttonColors(containerColor = SatoriSurfaceHighlightDark),
                modifier = Modifier.testTag("var_set_str")
            ) {
                Text("score = \"...\"", fontSize = 12.sp, color = SatoriTextPrimary)
            }
        }
    }
}

@Composable
fun ListVisualizer() {
    var items by remember { mutableStateOf(listOf("Python", "Rust", "Go")) }
    var selectedIndex by remember { mutableStateOf<Int?>(0) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            items.forEachIndexed { index, item ->
                val isSelected = selectedIndex == index
                Card(
                    onClick = { selectedIndex = index },
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) SatoriIndigo else SatoriSurfaceDark
                    ),
                    modifier = Modifier
                        .padding(4.dp)
                        .testTag("list_cell_$index")
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = "[$index]",
                            color = if (isSelected) SatoriNeonSpark else SatoriPythonCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "\"$item\"",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "[${index - items.size}]",
                            color = if (isSelected) Color.White.copy(alpha = 0.7f) else SatoriTextMuted,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Button(
                onClick = {
                    if (items.size < 5) {
                        val additions = listOf("Kotlin", "TypeScript", "Swift", "C++")
                        val next = additions.firstOrNull { !items.contains(it) } ?: "SQL"
                        items = items + next
                    }
                },
                enabled = items.size < 5,
                colors = ButtonDefaults.buttonColors(containerColor = SatoriIndigo),
                modifier = Modifier.testTag("list_append_btn")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("append()", fontSize = 12.sp)
            }

            Button(
                onClick = {
                    if (items.size > 1) {
                        items = items.dropLast(1)
                        if (selectedIndex != null && selectedIndex!! >= items.size) {
                            selectedIndex = items.size - 1
                        }
                    }
                },
                enabled = items.size > 1,
                colors = ButtonDefaults.buttonColors(containerColor = SatoriErrorRed),
                modifier = Modifier.testTag("list_pop_btn")
            ) {
                Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("pop()", fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun LoopVisualizer() {
    var step by remember { mutableStateOf(0) }
    val numbers = listOf(10, 20, 30, 40)
    val maxSteps = numbers.size

    val currentNum = numbers.getOrNull(step) ?: 0
    val runningSum = numbers.take(step + 1).sum()

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "for n in [10, 20, 30, 40]:",
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                color = SatoriPythonGold
            )
            Text(
                text = "Step ${step + 1} of $maxSteps",
                fontSize = 11.sp,
                color = SatoriNeonSpark
            )
        }

        // Stepper cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            numbers.forEachIndexed { idx, value ->
                val isActive = idx == step
                val isDone = idx < step
                Card(
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = when {
                            isActive -> SatoriIndigo
                            isDone -> SatoriSurfaceHighlightDark
                            else -> SatoriSurfaceDark
                        }
                    ),
                    modifier = Modifier.padding(2.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "n=$value",
                            color = if (isActive) Color.White else SatoriTextSecondary,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp
                        )
                        Icon(
                            imageVector = when {
                                isDone -> Icons.Default.Check
                                isActive -> Icons.Default.PlayArrow
                                else -> Icons.Default.HourglassEmpty
                            },
                            contentDescription = null,
                            tint = if (isActive) SatoriPythonGold else SatoriTextMuted,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }

        // State display
        Surface(
            color = SatoriSurfaceDark,
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = "Current loop variable n = $currentNum",
                    color = SatoriPythonCyan,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp
                )
                Text(
                    text = "Accumulated total += $currentNum -> $runningSum",
                    color = SatoriSuccessGreen,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Button(
                onClick = { step = (step + 1) % maxSteps },
                colors = ButtonDefaults.buttonColors(containerColor = SatoriIndigo),
                modifier = Modifier.testTag("loop_next_step")
            ) {
                Icon(Icons.Default.SkipNext, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Next Iteration", fontSize = 12.sp)
            }
            Button(
                onClick = { step = 0 },
                colors = ButtonDefaults.buttonColors(containerColor = SatoriSurfaceHighlightDark),
                modifier = Modifier.testTag("loop_reset_step")
            ) {
                Text("Reset Loop", fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun FunctionVisualizer() {
    var paramA by remember { mutableStateOf(5) }
    var paramB by remember { mutableStateOf(8) }
    var isExecuting by remember { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "def add(a, b): return a + b",
            fontFamily = FontFamily.Monospace,
            fontSize = 13.sp,
            color = SatoriPythonGold
        )

        // Visual Machine
        Surface(
            color = SatoriSurfaceDark,
            shape = RoundedCornerShape(12.dp),
            border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(SatoriIndigo, SatoriPurple))),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Inputs entering
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Input a", fontSize = 11.sp, color = SatoriTextSecondary)
                        Text("$paramA", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = SatoriPythonCyan)
                    }
                    Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = SatoriNeonSpark)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Input b", fontSize = 11.sp, color = SatoriTextSecondary)
                        Text("$paramB", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = SatoriPythonCyan)
                    }
                }

                Spacer(Modifier.height(8.dp))

                // Processing Chamber
                Surface(
                    color = SatoriSurfaceContainerDark,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth(0.8f)
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Build, contentDescription = null, tint = SatoriPythonGold, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "Function Machine",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = SatoriNeonSpark
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))
                Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = SatoriSuccessGreen)

                // Return Output
                Text("Returned Value", fontSize = 11.sp, color = SatoriTextSecondary)
                Text(
                    text = "${paramA + paramB}",
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    color = SatoriSuccessGreen,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Button(
                onClick = { paramA = (1..10).random(); paramB = (1..10).random() },
                colors = ButtonDefaults.buttonColors(containerColor = SatoriIndigo),
                modifier = Modifier.testTag("func_randomize_btn")
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("New Inputs", fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun ConditionVisualizer() {
    var score by remember { mutableStateOf(85) }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Test Score: $score", fontSize = 14.sp, color = SatoriNeonSpark, fontWeight = FontWeight.Bold)
            Text(
                text = when {
                    score >= 90 -> "Grade: A"
                    score >= 80 -> "Grade: B"
                    else -> "Grade: C"
                },
                fontSize = 14.sp,
                color = SatoriSuccessGreen,
                fontWeight = FontWeight.Bold
            )
        }

        Slider(
            value = score.toFloat(),
            onValueChange = { score = it.toInt() },
            valueRange = 50f..100f,
            colors = SliderDefaults.colors(
                thumbColor = SatoriIndigo,
                activeTrackColor = SatoriIndigo,
                inactiveTrackColor = SatoriSurfaceHighlightDark
            ),
            modifier = Modifier.testTag("condition_score_slider")
        )

        // Branching Decision Tree Cards
        val branches = listOf(
            Triple("if score >= 90:", "Grade: A", score >= 90),
            Triple("elif score >= 80:", "Grade: B", score in 80..89),
            Triple("else:", "Grade: C", score < 80)
        )

        branches.forEach { (branch, result, isActive) ->
            Surface(
                color = if (isActive) SatoriIndigo.copy(alpha = 0.25f) else SatoriSurfaceDark,
                shape = RoundedCornerShape(8.dp),
                border = if (isActive) CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(SatoriIndigo, SatoriPurple))) else null,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isActive) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                            contentDescription = null,
                            tint = if (isActive) SatoriSuccessGreen else SatoriTextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = branch,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp,
                            color = if (isActive) SatoriTextPrimary else SatoriTextMuted
                        )
                    }
                    Text(
                        text = result,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isActive) SatoriPythonGold else SatoriTextMuted
                    )
                }
            }
        }
    }
}
