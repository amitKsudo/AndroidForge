package com.satori.app.data.curriculum

import com.satori.app.model.*

object CurriculumPart2 {

    val modules: List<CourseModule> by lazy {
        listOf(
            createModule6(),
            createModule7(),
            createModule8(),
            createModule9(),
            createModule10()
        )
    }

    private fun createModule6(): CourseModule = CourseModule(
        id = "mod_6",
        number = 6,
        title = "Conditional Statements",
        subtitle = "if, elif, else, nested branching, and decision making",
        iconName = "branch",
        isPremium = false,
        estimatedHours = 2.0,
        lessons = listOf(
            Lesson(
                id = "m6_l1",
                moduleId = "mod_6",
                title = "if, elif, and else",
                order = 1,
                difficulty = Difficulty.BEGINNER,
                readTimeMinutes = 6,
                isFree = true,
                summary = "Make decisions in code by branching execution based on boolean conditions.",
                whyItMatters = "Without branching, code is just a rigid script. Conditions give software intelligence to respond differently to different situations.",
                analogy = "Think of a fork in the road with signposts: 'If you have a VIP ticket, turn left; otherwise if you have standard ticket, go straight; else turn around.'",
                explanation = "An 'if' statement tests a condition. If True, its indented block runs. If False, Python skips it and checks subsequent 'elif' branches. If all are False, the optional 'else' block runs.",
                syntax = "if condition:\n    # do something\nelif another_condition:\n    # do something else\nelse:\n    # fallback",
                exampleCode = "temperature = 28\nif temperature > 30:\n    print(\"It's hot outside!\")\nelif temperature >= 20:\n    print(\"Nice and comfortable.\")\nelse:\n    print(\"Bring a warm jacket.\")",
                lineByLine = listOf(
                    LineExplanation(1, "temperature = 28", "Setting the temperature variable."),
                    LineExplanation(2, "if temperature > 30:", "Checks if 28 > 30 (False). Skips this block."),
                    LineExplanation(4, "elif temperature >= 20:", "Checks if 28 >= 20 (True). Enters this block!"),
                    LineExplanation(5, "print(\"Nice and comfortable.\")", "Outputs the message."),
                    LineExplanation(6, "else:", "Skipped because an earlier branch already matched.")
                ),
                expectedOutput = "Nice and comfortable.",
                visualConceptType = VisualConceptType.CONDITIONS,
                commonMistakes = listOf(
                    "Forgetting the colon (:) at the end of the if, elif, or else lines.",
                    "Inconsistent indentation inside the block."
                ),
                recap = listOf(
                    "if tests the first condition.",
                    "elif lets you test multiple mutually exclusive conditions in sequence.",
                    "else acts as a catch-all safety net."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m6_l1_1",
                        lessonId = "m6_l1",
                        question = "What character must always appear at the end of an 'if' or 'elif' condition line?",
                        options = listOf(";", ":", "{", "then"),
                        correctIndex = 1,
                        explanation = "In Python, a colon (:) is mandatory at the end of header lines for code blocks.",
                        topic = "Conditions"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m6_l1",
                    lessonId = "m6_l1",
                    title = "Pass or Fail Check",
                    prompt = "Given score = 75, write an if-else statement: if score is 60 or above print 'Passed', else print 'Failed'.",
                    starterCode = "score = 75\n# Write your if-else statement below\n",
                    solutionCode = "score = 75\nif score >= 60:\n    print(\"Passed\")\nelse:\n    print(\"Failed\")",
                    hint = "if score >= 60: print('Passed') else: print('Failed')",
                    explanation = "Since 75 >= 60 is True, the first branch executes and outputs 'Passed'.",
                    testCases = listOf(
                        TestCase(expectedOutput = "Passed")
                    )
                )
            ),
            Lesson(
                id = "m6_l2",
                moduleId = "mod_6",
                title = "Ternary Operator & Nested Logic",
                order = 2,
                difficulty = Difficulty.INTERMEDIATE,
                readTimeMinutes = 5,
                isFree = true,
                summary = "Write concise one-line conditionals and handle nested decision structures.",
                whyItMatters = "One-line ternary expressions reduce boilerplate when assigning values based on a quick check.",
                analogy = "Like a quick toggle: 'status is Open if current_hour < 18 else Closed'.",
                explanation = "Python's ternary operator syntax is: 'value_if_true if condition else value_if_false'. It reads like standard English.",
                syntax = "result = \"Adult\" if age >= 18 else \"Minor\"",
                exampleCode = "age = 22\nstatus = \"Adult\" if age >= 18 else \"Minor\"\nprint(status)",
                lineByLine = listOf(
                    LineExplanation(1, "age = 22", "Variable holding age."),
                    LineExplanation(2, "status = \"Adult\" if age >= 18 else \"Minor\"", "Evaluates condition inline."),
                    LineExplanation(3, "print(status)", "Prints 'Adult'.")
                ),
                expectedOutput = "Adult",
                visualConceptType = VisualConceptType.CONDITIONS,
                commonMistakes = listOf(
                    "Overcomplicating ternary expressions: keep them simple; use multi-line if-else for complex logic."
                ),
                recap = listOf(
                    "Ternary operator: [on_true] if [condition] else [on_false].",
                    "Great for inline assignments and concise string messages."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m6_l2_1",
                        lessonId = "m6_l2",
                        question = "What is the correct syntax for Python's conditional expression?",
                        options = listOf(
                            "condition ? on_true : on_false",
                            "on_true if condition else on_false",
                            "if condition then on_true else on_false",
                            "(condition) -> on_true | on_false"
                        ),
                        correctIndex = 1,
                        explanation = "Python uses 'val_true if cond else val_false'.",
                        topic = "Ternary"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m6_l2",
                    lessonId = "m6_l2",
                    title = "Inline Status Assignment",
                    prompt = "Given num = 14, assign 'Even' if num % 2 == 0 else 'Odd' to a variable parity, and print parity.",
                    starterCode = "num = 14\n# Assign parity using a ternary expression and print it\n",
                    solutionCode = "num = 14\nparity = \"Even\" if num % 2 == 0 else \"Odd\"\nprint(parity)",
                    hint = "parity = \"Even\" if num % 2 == 0 else \"Odd\"",
                    explanation = "14 is evenly divisible by 2, so 'Even' is assigned and printed.",
                    testCases = listOf(
                        TestCase(expectedOutput = "Even")
                    )
                )
            )
        )
    )

    private fun createModule7(): CourseModule = CourseModule(
        id = "mod_7",
        number = 7,
        title = "Loops & Iteration",
        subtitle = "for loops, while loops, range(), break, and continue",
        iconName = "loop",
        isPremium = false,
        estimatedHours = 2.4,
        lessons = listOf(
            Lesson(
                id = "m7_l1",
                moduleId = "mod_7",
                title = "The for Loop & range()",
                order = 1,
                difficulty = Difficulty.BEGINNER,
                readTimeMinutes = 6,
                isFree = true,
                summary = "Repeat instructions efficiently using counted loops and number sequences.",
                whyItMatters = "Never copy and paste identical code 100 times. Loops do the repetitive heavy lifting in milliseconds.",
                analogy = "A conveyor belt in a factory: for every box that rolls by on the belt, the robotic arm puts a stamp on it.",
                explanation = "The 'for' loop iterates over any sequence. The range(n) function generates numbers from 0 up to n-1. You can also specify start, stop, and step: range(start, stop, step).",
                syntax = "for i in range(5):\n    print(i)",
                exampleCode = "# Counting to 4\nfor count in range(4):\n    print(f\"Step {count}\")",
                lineByLine = listOf(
                    LineExplanation(1, "# Counting to 4", "Comment explaining loop."),
                    LineExplanation(2, "for count in range(4):", "Loops 4 times: count takes values 0, 1, 2, 3."),
                    LineExplanation(3, "print(f\"Step {count}\")", "Indented block executed on each pass.")
                ),
                expectedOutput = "Step 0\nStep 1\nStep 2\nStep 3",
                visualConceptType = VisualConceptType.LOOPS,
                commonMistakes = listOf(
                    "Expecting range(5) to include 5: range(5) produces 0, 1, 2, 3, 4 (5 numbers total)."
                ),
                recap = listOf(
                    "for item in sequence visits each element in order.",
                    "range(stop) starts at 0 and excludes stop.",
                    "range(start, stop) starts at start."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m7_l1_1",
                        lessonId = "m7_l1",
                        question = "What numbers are generated by list(range(1, 4))?",
                        options = listOf("[1, 2, 3, 4]", "[1, 2, 3]", "[0, 1, 2, 3]", "[2, 3, 4]"),
                        correctIndex = 1,
                        explanation = "range(1, 4) starts at 1 and stops right before 4, yielding [1, 2, 3].",
                        topic = "range"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m7_l1",
                    lessonId = "m7_l1",
                    title = "Sum Numbers with a Loop",
                    prompt = "Use a for loop and range(1, 6) to calculate the sum of numbers from 1 to 5. Print the final sum.",
                    starterCode = "total = 0\n# Use a loop to add numbers 1 to 5 to total\n",
                    solutionCode = "total = 0\nfor i in range(1, 6):\n    total += i\nprint(total)",
                    hint = "for i in range(1, 6): total += i, then print(total)",
                    explanation = "1 + 2 + 3 + 4 + 5 = 15.",
                    testCases = listOf(
                        TestCase(expectedOutput = "15")
                    )
                )
            ),
            Lesson(
                id = "m7_l2",
                moduleId = "mod_7",
                title = "The while Loop & Loop Control",
                order = 2,
                difficulty = Difficulty.INTERMEDIATE,
                readTimeMinutes = 6,
                isFree = true,
                summary = "Repeat as long as a condition holds True, and control flow with break and continue.",
                whyItMatters = "When you don't know in advance how many times to loop (e.g. waiting for user input or downloading data), while loops are essential.",
                analogy = "Like a game loop: 'While player is alive, keep rendering the game. When health hits 0, break out.'",
                explanation = "A 'while' loop runs as long as its condition remains True. 'break' exits the loop immediately, and 'continue' skips to the next iteration.",
                syntax = "while condition:\n    # code\n    if done:\n        break",
                exampleCode = "count = 3\nwhile count > 0:\n    print(count)\n    count -= 1\nprint(\"Blast off!\")",
                lineByLine = listOf(
                    LineExplanation(1, "count = 3", "Initialization."),
                    LineExplanation(2, "while count > 0:", "Condition checked on each cycle."),
                    LineExplanation(3, "print(count)", "Outputs 3, 2, 1."),
                    LineExplanation(4, "count -= 1", "Decrements count so loop terminates!"),
                    LineExplanation(5, "print(\"Blast off!\")", "Runs after loop finishes.")
                ),
                expectedOutput = "3\n2\n1\nBlast off!",
                visualConceptType = VisualConceptType.LOOPS,
                commonMistakes = listOf(
                    "Forgetting to update the loop variable, causing an infinite loop that freezes your computer."
                ),
                recap = listOf(
                    "while loops require a condition that eventually becomes False.",
                    "break escapes immediately; continue skips to the next cycle."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m7_l2_1",
                        lessonId = "m7_l2",
                        question = "Which statement halts the entire loop immediately?",
                        options = listOf("continue", "pass", "break", "exit"),
                        correctIndex = 2,
                        explanation = "break terminates the enclosing loop immediately.",
                        topic = "Loop Control"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m7_l2",
                    lessonId = "m7_l2",
                    title = "Countdown with while",
                    prompt = "Using a while loop, print numbers starting from 5 down to 1 (one per line).",
                    starterCode = "n = 5\n# Write a while loop to count down to 1\n",
                    solutionCode = "n = 5\nwhile n >= 1:\n    print(n)\n    n -= 1",
                    hint = "while n >= 1: print(n); n -= 1",
                    explanation = "Prints 5, 4, 3, 2, 1 on separate lines.",
                    testCases = listOf(
                        TestCase(expectedOutput = "5\n4\n3\n2\n1")
                    )
                )
            )
        )
    )

    private fun createModule8(): CourseModule = CourseModule(
        id = "mod_8",
        number = 8,
        title = "Lists & Tuples",
        subtitle = "Ordered collections, mutation, methods, and immutable tuples",
        iconName = "list",
        isPremium = false,
        estimatedHours = 2.5,
        lessons = listOf(
            Lesson(
                id = "m8_l1",
                moduleId = "mod_8",
                title = "Working with Lists",
                order = 1,
                difficulty = Difficulty.BEGINNER,
                readTimeMinutes = 6,
                isFree = true,
                summary = "Store ordered collections of elements in resizable, mutable lists.",
                whyItMatters = "Lists are the workhorse data structure of Python, used for shopping carts, user lists, sensor readings, and search results.",
                analogy = "A notebook binder where you can add pages, remove pages, reorder them, or rewrite any page whenever you like.",
                explanation = "Lists are defined with square brackets []. They are mutable, meaning you can add items with .append(), remove items with .remove() or .pop(), and modify values in place.",
                syntax = "my_list = [1, 2, 3]\nmy_list.append(4)\nmy_list[0] = 99",
                exampleCode = "fruits = [\"apple\", \"banana\"]\nfruits.append(\"cherry\")\nprint(fruits)\nprint(len(fruits))\nprint(fruits[0])",
                lineByLine = listOf(
                    LineExplanation(1, "fruits = [\"apple\", \"banana\"]", "Creates a list with 2 elements."),
                    LineExplanation(2, "fruits.append(\"cherry\")", "Adds 'cherry' to the end."),
                    LineExplanation(3, "print(fruits)", "Outputs full list."),
                    LineExplanation(4, "print(len(fruits))", "len() reports number of items: 3."),
                    LineExplanation(5, "print(fruits[0])", "First element: 'apple'.")
                ),
                expectedOutput = "['apple', 'banana', 'cherry']\n3\napple",
                visualConceptType = VisualConceptType.LISTS,
                commonMistakes = listOf(
                    "Trying to access an index that doesn't exist: fruits[10] causes an IndexError."
                ),
                recap = listOf(
                    "Lists use square brackets [].",
                    "Lists are 0-indexed and completely mutable.",
                    "Use len() to get length and .append() to add items."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m8_l1_1",
                        lessonId = "m8_l1",
                        question = "Which method adds an item to the end of a list in Python?",
                        options = listOf("add()", "push()", "append()", "insert_end()"),
                        correctIndex = 2,
                        explanation = ".append() adds a single element to the end of an existing list.",
                        topic = "Lists"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m8_l1",
                    lessonId = "m8_l1",
                    title = "List Operations",
                    prompt = "Create a list named 'colors' containing 'red' and 'green'. Append 'blue' to it, then print the entire list.",
                    starterCode = "# Create list, append 'blue', and print it\n",
                    solutionCode = "colors = [\"red\", \"green\"]\ncolors.append(\"blue\")\nprint(colors)",
                    hint = "colors = ['red', 'green']; colors.append('blue'); print(colors)",
                    explanation = "Appends 'blue' to the list and displays the updated collection.",
                    testCases = listOf(
                        TestCase(expectedOutput = "['red', 'green', 'blue']")
                    )
                )
            ),
            Lesson(
                id = "m8_l2",
                moduleId = "mod_8",
                title = "Tuples & Immutability",
                order = 2,
                difficulty = Difficulty.INTERMEDIATE,
                readTimeMinutes = 5,
                isFree = true,
                summary = "Protect data from accidental changes using immutable tuple sequences.",
                whyItMatters = "When returning coordinates, RGB colors, or database records, tuples guarantee the data cannot be modified elsewhere.",
                analogy = "A permanent photograph in a locked glass frame—you can look at it, but nobody can change the picture.",
                explanation = "Tuples are defined with parentheses (). Once created, their items cannot be modified, added, or removed. You can unpack tuples cleanly into separate variables.",
                syntax = "point = (10, 20)\nx, y = point",
                exampleCode = "point = (10, 20)\nprint(point[0])\n# Unpacking\nx, y = point\nprint(f\"X: {x}, Y: {y}\")",
                lineByLine = listOf(
                    LineExplanation(1, "point = (10, 20)", "Creating a 2-item tuple."),
                    LineExplanation(2, "print(point[0])", "Reading first element: 10."),
                    LineExplanation(4, "x, y = point", "Unpacking tuple into separate variables x and y."),
                    LineExplanation(5, "print(f\"X: {x}, Y: {y}\")", "Outputs 'X: 10, Y: 20'.")
                ),
                expectedOutput = "10\nX: 10, Y: 20",
                visualConceptType = VisualConceptType.LISTS,
                commonMistakes = listOf(
                    "Trying to assign point[0] = 50: raises a TypeError because tuples are immutable!"
                ),
                recap = listOf(
                    "Tuples use () and cannot be changed after creation.",
                    "Tuples are faster and safer for fixed datasets than lists.",
                    "Tuple unpacking allows assigning multiple variables in one line."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m8_l2_1",
                        lessonId = "m8_l2",
                        question = "What happens if you attempt to reassign an element in a tuple: t[0] = 5?",
                        options = listOf(
                            "It updates the tuple silently",
                            "It raises a TypeError",
                            "It converts the tuple to a list",
                            "It appends 5 to the tuple"
                        ),
                        correctIndex = 1,
                        explanation = "Tuples are immutable; attempting to reassign an item throws a TypeError.",
                        topic = "Tuples"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m8_l2",
                    lessonId = "m8_l2",
                    title = "Tuple Unpacking",
                    prompt = "Given coords = (100, 200), unpack it into variables x and y, and print their sum.",
                    starterCode = "coords = (100, 200)\n# Unpack coords into x and y and print their sum\n",
                    solutionCode = "coords = (100, 200)\nx, y = coords\nprint(x + y)",
                    hint = "x, y = coords then print(x + y)",
                    explanation = "x is 100, y is 200, so their sum is 300.",
                    testCases = listOf(
                        TestCase(expectedOutput = "300")
                    )
                )
            )
        )
    )

    private fun createModule9(): CourseModule = CourseModule(
        id = "mod_9",
        number = 9,
        title = "Dictionaries & Sets",
        subtitle = "Fast key-value lookups, unique sets, and hash maps",
        iconName = "dictionary",
        isPremium = false,
        estimatedHours = 2.4,
        lessons = listOf(
            Lesson(
                id = "m9_l1",
                moduleId = "mod_9",
                title = "Key-Value Dictionaries",
                order = 1,
                difficulty = Difficulty.BEGINNER,
                readTimeMinutes = 6,
                isFree = true,
                summary = "Store and retrieve data instantly using unique descriptive keys.",
                whyItMatters = "In the real world, data has labels: 'name', 'price', 'email'. Dictionaries map labels directly to their corresponding values.",
                analogy = "A real English dictionary: you look up the word (the key) to instantly find its definition (the value).",
                explanation = "Dictionaries use curly braces {} with key: value pairs separated by colons. You access values using dict[key] or dict.get(key).",
                syntax = "user = {\"name\": \"Amit\", \"role\": \"Admin\"}\nuser[\"role\"] = \"Lead\"",
                exampleCode = "user = {\"name\": \"Amit\", \"level\": 10}\nprint(user[\"name\"])\nuser[\"score\"] = 95\nprint(user[\"score\"])",
                lineByLine = listOf(
                    LineExplanation(1, "user = {\"name\": \"Amit\", \"level\": 10}", "Dictionary with 2 keys."),
                    LineExplanation(2, "print(user[\"name\"])", "Looks up value for key 'name': 'Amit'."),
                    LineExplanation(3, "user[\"score\"] = 95", "Adds a new key-value pair dynamically."),
                    LineExplanation(4, "print(user[\"score\"])", "Outputs 95.")
                ),
                expectedOutput = "Amit\n95",
                visualConceptType = VisualConceptType.NONE,
                commonMistakes = listOf(
                    "Accessing a non-existent key with square brackets user['missing'] triggers a KeyError. Use user.get('missing') for safe access."
                ),
                recap = listOf(
                    "Dictionaries map unique keys to values.",
                    "Lookups by key are nearly instantaneous (O(1)).",
                    "Keys must be immutable types (strings, numbers, tuples)."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m9_l1_1",
                        lessonId = "m9_l1",
                        question = "What error occurs when accessing an unmapped key via dict[key]?",
                        options = listOf("IndexError", "KeyError", "ValueError", "LookupException"),
                        correctIndex = 1,
                        explanation = "Python raises a KeyError when a requested key does not exist.",
                        topic = "Dictionaries"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m9_l1",
                    lessonId = "m9_l1",
                    title = "Dictionary Lookup",
                    prompt = "Create a dictionary named 'prices' with 'apple': 2 and 'banana': 1. Print the price of 'apple'.",
                    starterCode = "# Create dictionary and print apple price\n",
                    solutionCode = "prices = {\"apple\": 2, \"banana\": 1}\nprint(prices[\"apple\"])",
                    hint = "prices = {'apple': 2, 'banana': 1}; print(prices['apple'])",
                    explanation = "Looks up the key 'apple' which returns 2.",
                    testCases = listOf(
                        TestCase(expectedOutput = "2")
                    )
                )
            ),
            Lesson(
                id = "m9_l2",
                moduleId = "mod_9",
                title = "Sets & Unique Collections",
                order = 2,
                difficulty = Difficulty.INTERMEDIATE,
                readTimeMinutes = 5,
                isFree = true,
                summary = "Eliminate duplicates automatically and perform mathematical set operations.",
                whyItMatters = "De-duplicating lists of IDs, tags, or email addresses is one of the most common tasks in software development.",
                analogy = "A bag of unique collectible stamps: you cannot have two identical stamps in the bag; duplicates simply merge into one.",
                explanation = "Sets are unordered collections of unique elements defined with {val1, val2}. They support set union (|), intersection (&), and difference (-).",
                syntax = "unique_numbers = set([1, 2, 2, 3])\ncommon = set_a & set_b",
                exampleCode = "numbers = [1, 2, 2, 3, 4, 4, 5]\nunique = set(numbers)\nprint(sorted(list(unique)))",
                lineByLine = listOf(
                    LineExplanation(1, "numbers = [1, 2, 2, 3, 4, 4, 5]", "List containing duplicates."),
                    LineExplanation(2, "unique = set(numbers)", "set() eliminates all duplicates!"),
                    LineExplanation(3, "print(sorted(list(unique)))", "Outputs [1, 2, 3, 4, 5].")
                ),
                expectedOutput = "[1, 2, 3, 4, 5]",
                visualConceptType = VisualConceptType.NONE,
                commonMistakes = listOf(
                    "Trying to create an empty set with {}. In Python, {} creates an empty dictionary! Use set() instead."
                ),
                recap = listOf(
                    "Sets enforce element uniqueness automatically.",
                    "Use set(list) to instantly strip duplicates.",
                    "Use set() to create an empty set."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m9_l2_1",
                        lessonId = "m9_l2",
                        question = "How do you create an empty set in Python?",
                        options = listOf("{}", "set()", "[]", "empty_set()"),
                        correctIndex = 1,
                        explanation = "{} creates an empty dict; set() creates an empty set.",
                        topic = "Sets"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m9_l2",
                    lessonId = "m9_l2",
                    title = "Count Unique Items",
                    prompt = "Given items = ['pen', 'book', 'pen', 'paper', 'book'], print the number of unique items using set() and len().",
                    starterCode = "items = [\"pen\", \"book\", \"pen\", \"paper\", \"book\"]\n# Print the count of unique items\n",
                    solutionCode = "items = [\"pen\", \"book\", \"pen\", \"paper\", \"book\"]\nprint(len(set(items)))",
                    hint = "Use print(len(set(items))).",
                    explanation = "set(items) has 3 elements ('pen', 'book', 'paper'), so len() is 3.",
                    testCases = listOf(
                        TestCase(expectedOutput = "3")
                    )
                )
            )
        )
    )

    private fun createModule10(): CourseModule = CourseModule(
        id = "mod_10",
        number = 10,
        title = "Functions & Modular Code",
        subtitle = "def, parameters, return values, scope, and clean architecture",
        iconName = "function",
        isPremium = false,
        estimatedHours = 2.6,
        lessons = listOf(
            Lesson(
                id = "m10_l1",
                moduleId = "mod_10",
                title = "Defining & Calling Functions",
                order = 1,
                difficulty = Difficulty.BEGINNER,
                readTimeMinutes = 6,
                isFree = true,
                summary = "Bundle reusable blocks of instructions into named functions using def and return.",
                whyItMatters = "Functions prevent code duplication, make debugging easy, and are the primary building blocks of software architecture.",
                analogy = "A coffee machine button: You press 'Brew', give it coffee beans and water (arguments), and it hands you back a cup of coffee (return value).",
                explanation = "You define a function with 'def function_name(parameters):'. The 'return' keyword sends a calculated result back to the caller.",
                syntax = "def greet(name):\n    return f\"Hello, {name}\"",
                exampleCode = "def add(a, b):\n    return a + b\n\nresult = add(10, 25)\nprint(result)",
                lineByLine = listOf(
                    LineExplanation(1, "def add(a, b):", "Defines a function named add that expects 2 parameters."),
                    LineExplanation(2, "return a + b", "Calculates and returns the sum."),
                    LineExplanation(4, "result = add(10, 25)", "Calls the function with 10 and 25 and captures return value."),
                    LineExplanation(5, "print(result)", "Outputs 35.")
                ),
                expectedOutput = "35",
                visualConceptType = VisualConceptType.FUNCTIONS,
                commonMistakes = listOf(
                    "Confusing print() with return: print() shows text on screen, but return hands data back so other code can use it."
                ),
                recap = listOf(
                    "Functions encapsulate reusable tasks.",
                    "Parameters receive inputs; return gives back the answer.",
                    "If a function has no return statement, it returns None by default."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m10_l1_1",
                        lessonId = "m10_l1",
                        question = "What keyword returns data from a function to its caller?",
                        options = listOf("send", "output", "return", "give"),
                        correctIndex = 2,
                        explanation = "The 'return' keyword exits the function and sends data back.",
                        topic = "Functions"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m10_l1",
                    lessonId = "m10_l1",
                    title = "Square a Number",
                    prompt = "Define a function named 'square' that takes a number n, returns n * n, and print square(6).",
                    starterCode = "# Define square(n) and print square(6)\n",
                    solutionCode = "def square(n):\n    return n * n\n\nprint(square(6))",
                    hint = "def square(n): return n * n, then print(square(6))",
                    explanation = "6 * 6 = 36.",
                    testCases = listOf(
                        TestCase(expectedOutput = "36")
                    )
                )
            ),
            Lesson(
                id = "m10_l2",
                moduleId = "mod_10",
                title = "Default Parameters & Scope",
                order = 2,
                difficulty = Difficulty.INTERMEDIATE,
                readTimeMinutes = 6,
                isFree = true,
                summary = "Supply default parameter values and master local vs global variable scoping.",
                whyItMatters = "Default arguments make functions flexible, while understanding scope prevents variables from colliding.",
                analogy = "A restaurant ordering form: if you don't choose a drink, water is provided by default.",
                explanation = "Parameters can have defaults: 'def greet(name=\"Friend\"):'. Variables created inside a function are local to that function.",
                syntax = "def power(base, exp=2):\n    return base ** exp",
                exampleCode = "def power(base, exp=2):\n    return base ** exp\n\nprint(power(4))\nprint(power(4, 3))",
                lineByLine = listOf(
                    LineExplanation(1, "def power(base, exp=2):", "exp defaults to 2 if omitted."),
                    LineExplanation(2, "return base ** exp", "Computes exponentiation."),
                    LineExplanation(4, "print(power(4))", "Uses default exp=2: 4 ** 2 = 16."),
                    LineExplanation(5, "print(power(4, 3))", "Overrides exp with 3: 4 ** 3 = 64.")
                ),
                expectedOutput = "16\n64",
                visualConceptType = VisualConceptType.FUNCTIONS,
                commonMistakes = listOf(
                    "Using a mutable object (like a list []) as a default argument: defaults are evaluated once at function definition time!"
                ),
                recap = listOf(
                    "Default parameters allow optional arguments.",
                    "Local variables defined inside functions are not accessible from outside."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m10_l2_1",
                        lessonId = "m10_l2",
                        question = "Where should parameters with default values be placed in the parameter list?",
                        options = listOf(
                            "At the beginning",
                            "After all non-default parameters",
                            "Anywhere without restriction",
                            "In a separate decorator"
                        ),
                        correctIndex = 1,
                        explanation = "In Python, non-default arguments cannot follow default arguments.",
                        topic = "Default Parameters"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m10_l2",
                    lessonId = "m10_l2",
                    title = "Default Greeting Function",
                    prompt = "Define a function 'greet(name=\"Guest\")' that returns f'Hello, {name}!'. Print greet() on line 1, and greet('Amit') on line 2.",
                    starterCode = "# Define greet with default argument and print both calls\n",
                    solutionCode = "def greet(name=\"Guest\"):\n    return f\"Hello, {name}!\"\n\nprint(greet())\nprint(greet(\"Amit\"))",
                    hint = "def greet(name='Guest'): return f'Hello, {name}!'",
                    explanation = "First call uses default 'Guest', second call passes 'Amit'.",
                    testCases = listOf(
                        TestCase(expectedOutput = "Hello, Guest!\nHello, Amit!")
                    )
                )
            )
        )
    )
}
