package com.satori.app.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.satori.app.R
import com.satori.app.data.UserManager
import com.satori.app.ui.theme.*

enum class AuthMode {
    LOGIN,
    SIGNUP,
    FORGOT_PASSWORD
}

@Composable
fun AuthScreen(
    userManager: UserManager,
    onAuthSuccess: () -> Unit,
    onContinueAsGuest: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var currentMode by remember { mutableStateOf(AuthMode.LOGIN) }

    // Form inputs
    var nameInput by remember { mutableStateOf("") }
    var emailInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }
    var confirmPasswordInput by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }
    var isConfirmPasswordVisible by remember { mutableStateOf(false) }

    // Forgot password flow state
    var resetStep by remember { mutableStateOf(1) } // 1: enter email, 2: enter otp & new password
    var resetEmail by remember { mutableStateOf("") }
    var otpInput by remember { mutableStateOf("") }
    var newPasswordInput by remember { mutableStateOf("") }
    var confirmNewPasswordInput by remember { mutableStateOf("") }
    var isNewPasswordVisible by remember { mutableStateOf(false) }
    var isConfirmNewPasswordVisible by remember { mutableStateOf(false) }
    var generatedResetCode by remember { mutableStateOf("") }

    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(SatoriDeepViolet)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .testTag("auth_card"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = SatoriSurfaceDark),
            border = CardDefaults.outlinedCardBorder().copy(brush = Brush.verticalGradient(listOf(SatoriIndigo, SatoriPurple)))
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // SATORI Official Logo
                Box(
                    modifier = Modifier
                        .size(58.dp)
                        .clip(CircleShape)
                        .background(Color.White),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_satori_user_logo),
                        contentDescription = "SATORI Logo",
                        modifier = Modifier.size(52.dp)
                    )
                }

                Spacer(Modifier.height(10.dp))

                Text(
                    text = "SATORI",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp,
                    color = SatoriNeonSpark
                )

                Text(
                    text = when (currentMode) {
                        AuthMode.LOGIN -> "Welcome back. Code finally makes sense."
                        AuthMode.SIGNUP -> "Create your account to start learning."
                        AuthMode.FORGOT_PASSWORD -> "Account Recovery & Password Reset"
                    },
                    fontSize = 12.sp,
                    color = SatoriTextSecondary,
                    modifier = Modifier.padding(top = 2.dp, bottom = 18.dp)
                )

                // Error Banner
                errorMessage?.let { err ->
                    Surface(
                        color = SatoriErrorRed.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.Error, contentDescription = null, tint = SatoriErrorRed, modifier = Modifier.size(16.dp))
                            Text(err, color = SatoriErrorRed, fontSize = 12.sp)
                        }
                    }
                }

                // Segmented Mode Selector
                Surface(
                    color = SatoriSurfaceContainerDark,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Button(
                            onClick = {
                                currentMode = AuthMode.LOGIN
                                errorMessage = null
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (currentMode == AuthMode.LOGIN) SatoriIndigo else Color.Transparent,
                                contentColor = if (currentMode == AuthMode.LOGIN) Color.White else SatoriTextSecondary
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f).height(38.dp),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("Sign In", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }

                        Button(
                            onClick = {
                                currentMode = AuthMode.SIGNUP
                                errorMessage = null
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (currentMode == AuthMode.SIGNUP) SatoriIndigo else Color.Transparent,
                                contentColor = if (currentMode == AuthMode.SIGNUP) Color.White else SatoriTextSecondary
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f).height(38.dp),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("Create Account", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }

                when (currentMode) {
                    AuthMode.LOGIN -> {
                        // 1-Tap Google Sign-In Button
                        Button(
                            onClick = {
                                val res = userManager.loginWithGoogle(
                                    name = "Amit Kumar",
                                    email = "amitdehlvi@gmail.com"
                                )
                                Toast.makeText(context, res.getOrNull(), Toast.LENGTH_SHORT).show()
                                onAuthSuccess()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("google_login_primary_btn")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    Icons.Default.AccountCircle,
                                    contentDescription = null,
                                    tint = Color(0xFF4285F4),
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text(
                                        "Sign in with Google",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF1F1F1F)
                                    )
                                    Text(
                                        "Amit Kumar (amitdehlvi@gmail.com)",
                                        fontSize = 10.sp,
                                        color = Color(0xFF5F6368)
                                    )
                                }
                            }
                        }

                        // Divider
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            HorizontalDivider(modifier = Modifier.weight(1f), color = SatoriBorderDark)
                            Text(
                                "  or sign in with email  ",
                                fontSize = 11.sp,
                                color = SatoriTextMuted
                            )
                            HorizontalDivider(modifier = Modifier.weight(1f), color = SatoriBorderDark)
                        }

                        // Email Input
                        OutlinedTextField(
                            value = emailInput,
                            onValueChange = {
                                emailInput = it
                                errorMessage = null
                            },
                            label = { Text("Email Address") },
                            placeholder = { Text("amitdehlvi@gmail.com") },
                            leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = SatoriTextSecondary) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("auth_email_input"),
                            shape = RoundedCornerShape(12.dp)
                        )

                        Spacer(Modifier.height(10.dp))

                        // Password Input with Eye Visibility Toggle
                        OutlinedTextField(
                            value = passwordInput,
                            onValueChange = {
                                passwordInput = it
                                errorMessage = null
                            },
                            label = { Text("Password") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = SatoriTextSecondary) },
                            trailingIcon = {
                                IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                    Icon(
                                        imageVector = if (isPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = "Toggle password visibility",
                                        tint = SatoriTextSecondary
                                    )
                                }
                            },
                            visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("auth_password_input"),
                            shape = RoundedCornerShape(12.dp)
                        )

                        // Forgot password link
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(
                                onClick = {
                                    currentMode = AuthMode.FORGOT_PASSWORD
                                    resetStep = 1
                                    errorMessage = null
                                }
                            ) {
                                Text("Forgot Password?", fontSize = 12.sp, color = SatoriIndigoLight)
                            }
                        }

                        // Formal Sign In Button
                        Button(
                            onClick = {
                                isLoading = true
                                val result = userManager.login(emailInput, passwordInput)
                                isLoading = false
                                if (result.isSuccess) {
                                    Toast.makeText(context, result.getOrNull(), Toast.LENGTH_SHORT).show()
                                    onAuthSuccess()
                                } else {
                                    errorMessage = result.exceptionOrNull()?.message ?: "Login failed."
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SatoriIndigo),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("login_submit_btn")
                        ) {
                            Text("Sign In", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }

                        Spacer(Modifier.height(14.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Don't have an account?", fontSize = 12.sp, color = SatoriTextSecondary)
                            TextButton(
                                onClick = {
                                    currentMode = AuthMode.SIGNUP
                                    errorMessage = null
                                }
                            ) {
                                Text("Create Account", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SatoriNeonSpark)
                            }
                        }
                    }

                    AuthMode.SIGNUP -> {
                        // 1-Tap Google Sign-Up Button
                        Button(
                            onClick = {
                                val res = userManager.loginWithGoogle(
                                    name = if (nameInput.isNotBlank()) nameInput.trim() else "Amit Kumar",
                                    email = if (emailInput.isNotBlank()) emailInput.trim().lowercase() else "amitdehlvi@gmail.com"
                                )
                                Toast.makeText(context, "Welcome to SATORI. Account registered.", Toast.LENGTH_SHORT).show()
                                onAuthSuccess()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("google_signup_primary_btn")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    Icons.Default.AccountCircle,
                                    contentDescription = null,
                                    tint = Color(0xFF4285F4),
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text(
                                        "Sign up with Google",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF1F1F1F)
                                    )
                                    Text(
                                        "Amit Kumar (amitdehlvi@gmail.com)",
                                        fontSize = 10.sp,
                                        color = Color(0xFF5F6368)
                                    )
                                }
                            }
                        }

                        // Divider
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            HorizontalDivider(modifier = Modifier.weight(1f), color = SatoriBorderDark)
                            Text(
                                "  or register with email  ",
                                fontSize = 11.sp,
                                color = SatoriTextMuted
                            )
                            HorizontalDivider(modifier = Modifier.weight(1f), color = SatoriBorderDark)
                        }

                        // Full Name
                        OutlinedTextField(
                            value = nameInput,
                            onValueChange = {
                                nameInput = it
                                errorMessage = null
                            },
                            label = { Text("Full Name") },
                            placeholder = { Text("Amit Kumar") },
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = SatoriTextSecondary) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("signup_name_input"),
                            shape = RoundedCornerShape(12.dp)
                        )

                        Spacer(Modifier.height(10.dp))

                        // Email
                        OutlinedTextField(
                            value = emailInput,
                            onValueChange = {
                                emailInput = it
                                errorMessage = null
                            },
                            label = { Text("Email Address") },
                            placeholder = { Text("amitdehlvi@gmail.com") },
                            leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = SatoriTextSecondary) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("signup_email_input"),
                            shape = RoundedCornerShape(12.dp)
                        )

                        Spacer(Modifier.height(10.dp))

                        // Password with Eye Toggle
                        OutlinedTextField(
                            value = passwordInput,
                            onValueChange = {
                                passwordInput = it
                                errorMessage = null
                            },
                            label = { Text("Password (min 6 characters)") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = SatoriTextSecondary) },
                            trailingIcon = {
                                IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                    Icon(
                                        imageVector = if (isPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = "Toggle password visibility",
                                        tint = SatoriTextSecondary
                                    )
                                }
                            },
                            visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("signup_password_input"),
                            shape = RoundedCornerShape(12.dp)
                        )

                        Spacer(Modifier.height(10.dp))

                        // Confirm Password with Eye Toggle
                        OutlinedTextField(
                            value = confirmPasswordInput,
                            onValueChange = {
                                confirmPasswordInput = it
                                errorMessage = null
                            },
                            label = { Text("Confirm Password") },
                            leadingIcon = { Icon(Icons.Default.LockReset, contentDescription = null, tint = SatoriTextSecondary) },
                            trailingIcon = {
                                IconButton(onClick = { isConfirmPasswordVisible = !isConfirmPasswordVisible }) {
                                    Icon(
                                        imageVector = if (isConfirmPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = "Toggle password visibility",
                                        tint = SatoriTextSecondary
                                    )
                                }
                            },
                            visualTransformation = if (isConfirmPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("signup_confirm_password_input"),
                            shape = RoundedCornerShape(12.dp)
                        )

                        Spacer(Modifier.height(16.dp))

                        Button(
                            onClick = {
                                if (passwordInput != confirmPasswordInput) {
                                    errorMessage = "Passwords do not match."
                                    return@Button
                                }
                                val result = userManager.register(nameInput, emailInput, passwordInput)
                                if (result.isSuccess) {
                                    Toast.makeText(context, result.getOrNull(), Toast.LENGTH_SHORT).show()
                                    onAuthSuccess()
                                } else {
                                    errorMessage = result.exceptionOrNull()?.message ?: "Registration failed."
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SatoriIndigo),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("signup_submit_btn")
                        ) {
                            Text("Create Account", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }

                        Spacer(Modifier.height(12.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Already have an account?", fontSize = 12.sp, color = SatoriTextSecondary)
                            TextButton(
                                onClick = {
                                    currentMode = AuthMode.LOGIN
                                    errorMessage = null
                                }
                            ) {
                                Text("Sign In", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SatoriNeonSpark)
                            }
                        }
                    }

                    AuthMode.FORGOT_PASSWORD -> {
                        if (resetStep == 1) {
                            // Step 1: Send Verification Code
                            Text(
                                text = "Enter your registered email address to receive a 6-digit verification code.",
                                fontSize = 13.sp,
                                color = SatoriTextSecondary,
                                lineHeight = 18.sp,
                                modifier = Modifier.padding(bottom = 12.dp)
                            )

                            OutlinedTextField(
                                value = resetEmail,
                                onValueChange = {
                                    resetEmail = it
                                    errorMessage = null
                                },
                                label = { Text("Registered Email Address") },
                                placeholder = { Text("amitdehlvi@gmail.com") },
                                leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = SatoriTextSecondary) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("forgot_email_input"),
                                shape = RoundedCornerShape(12.dp)
                            )

                            Spacer(Modifier.height(16.dp))

                            Button(
                                onClick = {
                                    val result = userManager.requestPasswordReset(resetEmail)
                                    if (result.isSuccess) {
                                        generatedResetCode = result.getOrNull() ?: "749218"
                                        resetStep = 2
                                        errorMessage = null
                                        Toast.makeText(context, "Verification code generated for $resetEmail", Toast.LENGTH_SHORT).show()
                                    } else {
                                        errorMessage = result.exceptionOrNull()?.message ?: "Failed to generate verification code."
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = SatoriIndigo),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth().height(48.dp)
                            ) {
                                Icon(Icons.Default.MarkEmailRead, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text("Send Verification Code", fontWeight = FontWeight.Bold)
                            }
                        } else {
                            // Step 2: Verification Code with Auto-Fill & New Password with Eye Toggle
                            Surface(
                                color = SatoriIndigo.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(12.dp),
                                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(SatoriIndigo, SatoriPurple))),
                                modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Icon(Icons.Default.Security, contentDescription = null, tint = SatoriPythonCyan, modifier = Modifier.size(24.dp))
                                        Column {
                                            Text(
                                                "Security Verification Code",
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                            Text(
                                                "Registered for $resetEmail",
                                                fontSize = 11.sp,
                                                color = SatoriTextSecondary
                                            )
                                        }
                                    }

                                    Spacer(Modifier.height(10.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text("Verification Code:", fontSize = 10.sp, color = SatoriTextMuted)
                                            Text(
                                                text = generatedResetCode.ifEmpty { "749218" },
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.Bold,
                                                fontFamily = FontFamily.Monospace,
                                                color = SatoriPythonGold,
                                                letterSpacing = 2.sp
                                            )
                                        }

                                        Button(
                                            onClick = {
                                                otpInput = generatedResetCode.ifEmpty { "749218" }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = SatoriIndigo),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                        ) {
                                            Text("Auto-Fill", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }

                            OutlinedTextField(
                                value = otpInput,
                                onValueChange = {
                                    if (it.length <= 6) otpInput = it
                                    errorMessage = null
                                },
                                label = { Text("Enter 6-Digit Code") },
                                placeholder = { Text("e.g. 749218") },
                                leadingIcon = { Icon(Icons.Default.Pin, contentDescription = null, tint = SatoriTextSecondary) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("reset_otp_input"),
                                shape = RoundedCornerShape(12.dp),
                                textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 16.sp, letterSpacing = 2.sp)
                            )

                            Spacer(Modifier.height(10.dp))

                            // New Password with Eye Toggle
                            OutlinedTextField(
                                value = newPasswordInput,
                                onValueChange = {
                                    newPasswordInput = it
                                    errorMessage = null
                                },
                                label = { Text("New Password (min 6 characters)") },
                                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = SatoriTextSecondary) },
                                trailingIcon = {
                                    IconButton(onClick = { isNewPasswordVisible = !isNewPasswordVisible }) {
                                        Icon(
                                            imageVector = if (isNewPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                            contentDescription = "Toggle password visibility",
                                            tint = SatoriTextSecondary
                                        )
                                    }
                                },
                                visualTransformation = if (isNewPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("reset_new_password_input"),
                                shape = RoundedCornerShape(12.dp)
                            )

                            Spacer(Modifier.height(10.dp))

                            // Confirm New Password with Eye Toggle
                            OutlinedTextField(
                                value = confirmNewPasswordInput,
                                onValueChange = {
                                    confirmNewPasswordInput = it
                                    errorMessage = null
                                },
                                label = { Text("Confirm New Password") },
                                leadingIcon = { Icon(Icons.Default.LockReset, contentDescription = null, tint = SatoriTextSecondary) },
                                trailingIcon = {
                                    IconButton(onClick = { isConfirmNewPasswordVisible = !isConfirmNewPasswordVisible }) {
                                        Icon(
                                            imageVector = if (isConfirmNewPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                            contentDescription = "Toggle password visibility",
                                            tint = SatoriTextSecondary
                                        )
                                    }
                                },
                                visualTransformation = if (isConfirmNewPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("reset_confirm_new_password_input"),
                                shape = RoundedCornerShape(12.dp)
                            )

                            Spacer(Modifier.height(16.dp))

                            Button(
                                onClick = {
                                    if (otpInput.length < 4) {
                                        errorMessage = "Please enter the verification code."
                                        return@Button
                                    }
                                    if (confirmNewPasswordInput.isNotEmpty() && newPasswordInput != confirmNewPasswordInput) {
                                        errorMessage = "Passwords do not match."
                                        return@Button
                                    }
                                    val result = userManager.verifyAndResetPassword(resetEmail, otpInput, newPasswordInput)
                                    if (result.isSuccess) {
                                        Toast.makeText(context, result.getOrNull(), Toast.LENGTH_SHORT).show()
                                        onAuthSuccess()
                                    } else {
                                        errorMessage = result.exceptionOrNull()?.message ?: "Reset failed."
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = SatoriIndigo),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth().height(48.dp)
                            ) {
                                Text("Update Password & Sign In", fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(Modifier.height(12.dp))

                        TextButton(
                            onClick = {
                                currentMode = AuthMode.LOGIN
                                errorMessage = null
                            }
                        ) {
                            Text("Back to Sign In", color = SatoriTextSecondary, fontSize = 12.sp)
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))

                // Guest option
                TextButton(onClick = onContinueAsGuest) {
                    Text("Continue as Guest", color = SatoriTextMuted, fontSize = 12.sp)
                }
            }
        }
    }
}
