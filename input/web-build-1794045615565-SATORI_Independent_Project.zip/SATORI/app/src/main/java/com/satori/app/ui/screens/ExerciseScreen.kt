package com.satori.app.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.satori.app.engine.PythonEngine
import com.satori.app.model.CodingExercise
import com.satori.app.ui.components.PythonEditor
import com.satori.app.ui.theme.*
import com.satori.app.util.AudioFeedbackManager

@Composable
fun ExerciseScreen(
    exercise: CodingExercise,
    onExercisePassed: () -> Unit,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var code by remember(exercise.id) { mutableStateOf(exercise.starterCode) }
    var testResult by remember { mutableStateOf<Pair<Boolean, String>?>(null) }
    var showHint by remember { mutableStateOf(false) }
    var showSolution by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SatoriDeepViolet)
            .padding(horizontal = 16.dp)
            .testTag("exercise_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
            // Title & Prompt
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = SatoriSurfaceDark),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = exercise.title,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = exercise.prompt,
                            fontSize = 14.sp,
                            color = SatoriTextPrimary,
                            lineHeight = 20.sp,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                    }
                }
            }

            // Hint Accordion
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SatoriSurfaceContainerDark),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showHint = !showHint },
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.Lightbulb, contentDescription = null, tint = SatoriPythonGold, modifier = Modifier.size(16.dp))
                                Text("Need a Hint?", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = SatoriPythonGold)
                            }
                            Icon(if (showHint) Icons.Default.ExpandLess else Icons.Default.ExpandMore, contentDescription = null, tint = SatoriTextSecondary)
                        }

                        if (showHint) {
                            Text(
                                text = exercise.hint,
                                fontSize = 12.sp,
                                color = SatoriTextSecondary,
                                lineHeight = 18.sp,
                                modifier = Modifier.padding(top = 8.dp)
                            )
                        }
                    }
                }
            }

            // Python Code Editor
            item {
                Column {
                    Text("Your Python Solution", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                    Spacer(Modifier.height(6.dp))
                    PythonEditor(
                        initialCode = code,
                        onCodeChange = { code = it }
                    )
                }
            }

            // Evaluate & Submit Button
            item {
                Button(
                    onClick = {
                        val result = PythonEngine.evaluateExercise(code, exercise.testCases)
                        testResult = result
                        if (result.first) {
                            AudioFeedbackManager.playExercisePassed()
                            onExercisePassed()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SatoriIndigo),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("check_solution_btn")
                ) {
                    Icon(Icons.Default.PlayCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Run Test Cases & Verify", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }

            // Test Result Feedback
            testResult?.let { res ->
                item {
                    val passed = res.first
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (passed) SatoriSuccessGreen.copy(alpha = 0.2f) else SatoriErrorRed.copy(alpha = 0.2f)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(if (passed) SatoriSuccessGreen else SatoriErrorRed, if (passed) SatoriSuccessGreen else SatoriErrorRed))),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(
                                    imageVector = if (passed) Icons.Default.CheckCircle else Icons.Default.Error,
                                    contentDescription = null,
                                    tint = if (passed) SatoriSuccessGreen else SatoriErrorRed,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = if (passed) "All Test Cases Passed!" else "Test Cases Failed",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = if (passed) SatoriSuccessGreen else SatoriErrorRed
                                )
                            }
                            Text(
                                text = res.second,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                color = SatoriTextPrimary,
                                modifier = Modifier.padding(top = 8.dp)
                            )
                        }
                    }
                }
            }

            // Reveal Solution
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SatoriSurfaceContainerDark),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showSolution = !showSolution },
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Reveal Model Solution", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = SatoriTextSecondary)
                            Icon(if (showSolution) Icons.Default.ExpandLess else Icons.Default.ExpandMore, contentDescription = null, tint = SatoriTextSecondary)
                        }

                        if (showSolution) {
                            Surface(
                                color = SatoriCodeBackground,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                            ) {
                                Text(
                                    text = exercise.solutionCode,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 12.sp,
                                    color = SatoriPythonGold,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                            Text(
                                text = exercise.explanation,
                                fontSize = 12.sp,
                                color = SatoriTextSecondary,
                                modifier = Modifier.padding(top = 6.dp)
                            )
                        }
                    }
                }
            }
        }
    }
