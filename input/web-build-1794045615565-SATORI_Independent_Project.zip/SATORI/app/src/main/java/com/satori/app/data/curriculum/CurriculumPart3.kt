package com.satori.app.data.curriculum

import com.satori.app.model.*

object CurriculumPart3 {

    val modules: List<CourseModule> by lazy {
        listOf(
            createModule11(),
            createModule12(),
            createModule13(),
            createModule14(),
            createModule15()
        )
    }

    private fun createModule11(): CourseModule = CourseModule(
        id = "mod_11",
        number = 11,
        title = "Modules & Packages",
        subtitle = "import, standard library, pip, virtual environments",
        iconName = "package",
        isPremium = false,
        estimatedHours = 2.0,
        lessons = listOf(
            Lesson(
                id = "m11_l1",
                moduleId = "mod_11",
                title = "Importing Modules & the Standard Library",
                order = 1,
                difficulty = Difficulty.INTERMEDIATE,
                readTimeMinutes = 6,
                isFree = true,
                summary = "Extend Python's capabilities by importing pre-built modules from the standard library.",
                whyItMatters = "Python comes with 'batteries included'. Don't reinvent math formulas, random numbers, or timestamps when tested tools already exist.",
                analogy = "Like ordering from a specialized tool shed: instead of forging your own hammer from iron, you just grab one off the rack.",
                explanation = "Use 'import module_name' or 'from module_name import specific_func'. Modules bundle functions, classes, and constants together.",
                syntax = "import math\nfrom math import sqrt, pi",
                exampleCode = "# Builtin modules demo\nradius = 5\narea = 3.14159 * (radius ** 2)\nprint(f\"Calculated area: {int(area)}\")",
                lineByLine = listOf(
                    LineExplanation(1, "# Builtin modules demo", "Comment on module usage."),
                    LineExplanation(2, "radius = 5", "Circle radius variable."),
                    LineExplanation(3, "area = 3.14159 * (radius ** 2)", "pi * r^2 formula."),
                    LineExplanation(4, "print(f\"Calculated area: {int(area)}\")", "Truncating to integer for clean output.")
                ),
                expectedOutput = "Calculated area: 78",
                visualConceptType = VisualConceptType.NONE,
                commonMistakes = listOf(
                    "Naming your own script file the same as a standard module (e.g. naming your file 'math.py' will break 'import math')."
                ),
                recap = listOf(
                    "Modules bundle related functions and constants.",
                    "The standard library provides math, random, datetime, json, and more.",
                    "Never name custom files the same as standard modules."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m11_l1_1",
                        lessonId = "m11_l1",
                        question = "Which keyword brings an external module into your current Python script?",
                        options = listOf("include", "require", "import", "using"),
                        correctIndex = 2,
                        explanation = "Python uses the 'import' statement.",
                        topic = "Imports"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m11_l1",
                    lessonId = "m11_l1",
                    title = "Module Function Usage",
                    prompt = "Write code that calculates the perimeter of a rectangle with length = 12 and width = 8, and print the perimeter.",
                    starterCode = "length = 12\nwidth = 8\n# Calculate and print perimeter: 2 * (length + width)\n",
                    solutionCode = "length = 12\nwidth = 8\nperimeter = 2 * (length + width)\nprint(perimeter)",
                    hint = "perimeter = 2 * (length + width); print(perimeter)",
                    explanation = "2 * (12 + 8) = 40.",
                    testCases = listOf(
                        TestCase(expectedOutput = "40")
                    )
                )
            ),
            Lesson(
                id = "m11_l2",
                moduleId = "mod_11",
                title = "Creating Modules & __name__",
                order = 2,
                difficulty = Difficulty.INTERMEDIATE,
                readTimeMinutes = 6,
                isFree = true,
                summary = "Split your codebase across multiple files and understand if __name__ == '__main__'.",
                whyItMatters = "Real software isn't written in a single thousand-line file. Modularizing files keeps code readable, maintainable, and reusable.",
                analogy = "Separating a book into distinct chapters instead of printing everything on one endless scroll.",
                explanation = "Any Python file (.py) is a module. When executed directly, Python sets __name__ to '__main__'. When imported by another file, __name__ is set to the file's module name.",
                syntax = "if __name__ == '__main__':\n    # runs only when executed directly",
                exampleCode = "def helper():\n    return \"Helper ready\"\n\n# Direct execution check\nstatus = \"Direct Run\"\nprint(status)\nprint(helper())",
                lineByLine = listOf(
                    LineExplanation(1, "def helper():", "Reusable function inside the module."),
                    LineExplanation(2, "return \"Helper ready\"", "Return message."),
                    LineExplanation(4, "# Direct execution check", "Checks execution context."),
                    LineExplanation(5, "status = \"Direct Run\"", "Variable indicating execution."),
                    LineExplanation(6, "print(status)", "Outputs 'Direct Run'."),
                    LineExplanation(7, "print(helper())", "Calls helper function.")
                ),
                expectedOutput = "Direct Run\nHelper ready",
                visualConceptType = VisualConceptType.NONE,
                commonMistakes = listOf(
                    "Leaving test code unshielded at the module root, which runs accidentally whenever anyone imports the module."
                ),
                recap = listOf(
                    "__name__ equals '__main__' when the file is run directly.",
                    "Shield executable test code inside 'if __name__ == \"__main__\":'."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m11_l2_1",
                        lessonId = "m11_l2",
                        question = "What is the value of __name__ when a script is executed directly from the terminal?",
                        options = listOf("'__init__'", "'__main__'", "'script'", "'root'"),
                        correctIndex = 1,
                        explanation = "Python assigns the string '__main__' to the top-level script's __name__ attribute.",
                        topic = "Module Execution"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m11_l2",
                    lessonId = "m11_l2",
                    title = "Module Entry Point",
                    prompt = "Define a function 'run_app()' that prints 'System Online', and call it.",
                    starterCode = "# Define and call run_app()\n",
                    solutionCode = "def run_app():\n    print(\"System Online\")\n\nrun_app()",
                    hint = "def run_app(): print('System Online') then run_app()",
                    explanation = "Defines the entry point function and invokes it.",
                    testCases = listOf(
                        TestCase(expectedOutput = "System Online")
                    )
                )
            )
        )
    )

    private fun createModule12(): CourseModule = CourseModule(
        id = "mod_12",
        number = 12,
        title = "File Handling & Data",
        subtitle = "Reading, writing, with open, CSV, and JSON",
        iconName = "file",
        isPremium = false,
        estimatedHours = 2.2,
        lessons = listOf(
            Lesson(
                id = "m12_l1",
                moduleId = "mod_12",
                title = "Reading & Writing Text Files",
                order = 1,
                difficulty = Difficulty.INTERMEDIATE,
                readTimeMinutes = 6,
                isFree = true,
                summary = "Persist data to the disk using open() and the safe 'with' context manager.",
                whyItMatters = "When your application closes, RAM memory vanishes. Files allow data to survive program restarts.",
                analogy = "Writing down notes in a journal before going to sleep so you can read them tomorrow morning.",
                explanation = "Always use the 'with open(filename, mode) as f:' pattern. The 'with' statement guarantees the file closes automatically, even if errors occur.",
                syntax = "with open(\"data.txt\", \"w\") as f:\n    f.write(\"Hello\")",
                exampleCode = "# Simulating file content processing\nlines = [\"Log 1: Start\", \"Log 2: Processing\", \"Log 3: Done\"]\nfor line in lines:\n    print(line)",
                lineByLine = listOf(
                    LineExplanation(1, "# Simulating file content processing", "Simulates sequential line reading."),
                    LineExplanation(2, "lines = [...]", "List of saved log records."),
                    LineExplanation(3, "for line in lines:", "Iterates over saved lines."),
                    LineExplanation(4, "print(line)", "Outputs each log entry.")
                ),
                expectedOutput = "Log 1: Start\nLog 2: Processing\nLog 3: Done",
                visualConceptType = VisualConceptType.NONE,
                commonMistakes = listOf(
                    "Using mode 'w' instead of 'a' when appending: 'w' wipes out all existing file contents completely!"
                ),
                recap = listOf(
                    "'r' = read, 'w' = write (overwrite), 'a' = append.",
                    "Always use 'with open()' to avoid leaking file descriptors."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m12_l1_1",
                        lessonId = "m12_l1",
                        question = "What file mode opens an existing file and appends data without erasing previous content?",
                        options = listOf("'r'", "'w'", "'a'", "'x'"),
                        correctIndex = 2,
                        explanation = "Mode 'a' (append) writes new data to the end of the file.",
                        topic = "File Modes"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m12_l1",
                    lessonId = "m12_l1",
                    title = "Process Saved Records",
                    prompt = "Given records = ['Alpha', 'Beta', 'Gamma'], use a loop to print each record prefixed with 'Record: '.",
                    starterCode = "records = [\"Alpha\", \"Beta\", \"Gamma\"]\n# Loop through records and print formatted string\n",
                    solutionCode = "records = [\"Alpha\", \"Beta\", \"Gamma\"]\nfor r in records:\n    print(f\"Record: {r}\")",
                    hint = "for r in records: print(f'Record: {r}')",
                    explanation = "Iterates through the records and outputs each formatted line.",
                    testCases = listOf(
                        TestCase(expectedOutput = "Record: Alpha\nRecord: Beta\nRecord: Gamma")
                    )
                )
            ),
            Lesson(
                id = "m12_l2",
                moduleId = "mod_12",
                title = "Working with JSON Data",
                order = 2,
                difficulty = Difficulty.INTERMEDIATE,
                readTimeMinutes = 6,
                isFree = true,
                summary = "Serialize and deserialize structured data using Python's builtin json module.",
                whyItMatters = "JSON is the universal data format of the modern internet, web APIs, configurations, and mobile apps.",
                analogy = "Like packing furniture into flat boxes (serialization) to ship it across the world, then assembling it back into furniture on arrival (deserialization).",
                explanation = "json.dumps() converts Python dictionaries/lists into a JSON string. json.loads() parses a JSON string back into native Python objects.",
                syntax = "import json\njson_text = json.dumps(data)\nobj = json.loads(json_text)",
                exampleCode = "# JSON representation\nuser = {\"id\": 101, \"name\": \"Amit\", \"active\": True}\nprint(f\"ID: {user['id']}\")\nprint(f\"User: {user['name']}\")\nprint(f\"Active: {user['active']}\")",
                lineByLine = listOf(
                    LineExplanation(1, "# JSON representation", "Structured dictionary matching JSON schema."),
                    LineExplanation(2, "user = {...}", "Dictionary keys and values."),
                    LineExplanation(3, "print(f\"ID: {user['id']}\")", "Access ID: 101."),
                    LineExplanation(4, "print(f\"User: {user['name']}\")", "Access Name: 'Amit'."),
                    LineExplanation(5, "print(f\"Active: {user['active']}\")", "Access boolean flag.")
                ),
                expectedOutput = "ID: 101\nUser: Amit\nActive: True",
                visualConceptType = VisualConceptType.NONE,
                commonMistakes = listOf(
                    "Confusing json.dump (for file streams) with json.dumps (for in-memory strings with an 's')."
                ),
                recap = listOf(
                    "dumps = serialize to string.",
                    "loads = deserialize from string.",
                    "Python dicts correspond directly to JSON objects."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m12_l2_1",
                        lessonId = "m12_l2",
                        question = "Which function parses a JSON string into a Python dictionary?",
                        options = listOf("json.parse()", "json.loads()", "json.to_dict()", "json.dumps()"),
                        correctIndex = 1,
                        explanation = "json.loads() loads from a JSON string.",
                        topic = "JSON"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m12_l2",
                    lessonId = "m12_l2",
                    title = "Parse Configuration Data",
                    prompt = "Given config = {'theme': 'dark', 'version': 2}, print the value of 'theme' on line 1 and 'version' on line 2.",
                    starterCode = "config = {\"theme\": \"dark\", \"version\": 2}\n# Print config values\n",
                    solutionCode = "config = {\"theme\": \"dark\", \"version\": 2}\nprint(config[\"theme\"])\nprint(config[\"version\"])",
                    hint = "print(config['theme']); print(config['version'])",
                    explanation = "Reads the configuration keys directly and displays their values.",
                    testCases = listOf(
                        TestCase(expectedOutput = "dark\n2")
                    )
                )
            )
        )
    )

    private fun createModule13(): CourseModule = CourseModule(
        id = "mod_13",
        number = 13,
        title = "Exception Handling",
        subtitle = "try, except, finally, custom errors, and defensive coding",
        iconName = "bug",
        isPremium = false,
        estimatedHours = 2.0,
        lessons = listOf(
            Lesson(
                id = "m13_l1",
                moduleId = "mod_13",
                title = "try, except, and finally",
                order = 1,
                difficulty = Difficulty.INTERMEDIATE,
                readTimeMinutes = 6,
                isFree = true,
                summary = "Gracefully catch unexpected runtime errors and keep your application from crashing.",
                whyItMatters = "In production, networks drop, files disappear, and users type gibberish. Good software handles errors gracefully instead of crashing.",
                analogy = "An acrobat's safety net: even if an acrobat misses a trapeze catch, the safety net catches them safely so the show goes on.",
                explanation = "Put dangerous code inside a 'try:' block. If an exception is raised, Python jumps to the matching 'except ErrorType:' block. The 'finally:' block always executes no matter what.",
                syntax = "try:\n    # risky code\nexcept ValueError:\n    # handle error\nfinally:\n    # cleanup",
                exampleCode = "def safe_divide(a, b):\n    if b == 0:\n        return \"Cannot divide by zero\"\n    return a / b\n\nprint(safe_divide(10, 2))\nprint(safe_divide(10, 0))",
                lineByLine = listOf(
                    LineExplanation(1, "def safe_divide(a, b):", "Defensive division function."),
                    LineExplanation(2, "if b == 0:", "Catches division by zero before it occurs."),
                    LineExplanation(3, "return \"Cannot divide by zero\"", "Graceful error message."),
                    LineExplanation(4, "return a / b", "Normal calculation."),
                    LineExplanation(6, "print(safe_divide(10, 2))", "Outputs 5.0."),
                    LineExplanation(7, "print(safe_divide(10, 0))", "Outputs error message safely.")
                ),
                expectedOutput = "5.0\nCannot divide by zero",
                visualConceptType = VisualConceptType.NONE,
                commonMistakes = listOf(
                    "Using bare 'except:' without specifying an error type—this can hide typos and critical system bugs like KeyboardInterrupt."
                ),
                recap = listOf(
                    "try runs risky code.",
                    "except catches and recovers from specific errors.",
                    "finally always runs for cleanup (closing files, releasing locks)."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m13_l1_1",
                        lessonId = "m13_l1",
                        question = "Which block is guaranteed to execute whether an exception occurred or not?",
                        options = listOf("catch", "always", "finally", "cleanup"),
                        correctIndex = 2,
                        explanation = "The 'finally' block is always guaranteed to execute.",
                        topic = "Exceptions"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m13_l1",
                    lessonId = "m13_l1",
                    title = "Defensive Safe Parser",
                    prompt = "Write a function parse_int(text, default=0). If text is '123' return 123; if text is 'invalid' return default (0). Print parse_int('45') and parse_int('abc').",
                    starterCode = "# Define parse_int and test it\n",
                    solutionCode = "def parse_int(text, default=0):\n    if text.isdigit():\n        return int(text)\n    return default\n\nprint(parse_int(\"45\"))\nprint(parse_int(\"abc\"))",
                    hint = "Check text.isdigit() before converting with int(), else return default.",
                    explanation = "Safely handles non-numeric strings without throwing an uncaught exception.",
                    testCases = listOf(
                        TestCase(expectedOutput = "45\n0")
                    )
                )
            ),
            Lesson(
                id = "m13_l2",
                moduleId = "mod_13",
                title = "Raising Exceptions & Custom Errors",
                order = 2,
                difficulty = Difficulty.INTERMEDIATE,
                readTimeMinutes = 6,
                isFree = true,
                summary = "Trigger explicit errors using raise and define domain-specific custom exception classes.",
                whyItMatters = "When business rules are violated (e.g., negative bank deposit or underage registration), raising clear errors halts corrupted state.",
                analogy = "Pulling the emergency brake on a train when an obstruction is spotted on the tracks ahead.",
                explanation = "Use 'raise ValueError(\"message\")' to trigger an exception. Custom exceptions inherit from the builtin 'Exception' class.",
                syntax = "if age < 0:\n    raise ValueError(\"Age cannot be negative\")",
                exampleCode = "def set_age(age):\n    if age < 0:\n        return \"Error: Age cannot be negative\"\n    return f\"Age set to {age}\"\n\nprint(set_age(25))\nprint(set_age(-5))",
                lineByLine = listOf(
                    LineExplanation(1, "def set_age(age):", "Function validating business constraints."),
                    LineExplanation(2, "if age < 0:", "Detects invalid state."),
                    LineExplanation(3, "return \"Error: Age cannot be negative\"", "Handles failure clearly."),
                    LineExplanation(4, "return f\"Age set to {age}\"", "Valid flow."),
                    LineExplanation(6, "print(set_age(25))", "Outputs valid state."),
                    LineExplanation(7, "print(set_age(-5))", "Outputs constraint error.")
                ),
                expectedOutput = "Age set to 25\nError: Age cannot be negative",
                visualConceptType = VisualConceptType.NONE,
                commonMistakes = listOf(
                    "Swallowing exceptions silently without logging or providing a reason."
                ),
                recap = listOf(
                    "raise triggers exceptions explicitly.",
                    "Always provide helpful, descriptive error messages."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m13_l2_1",
                        lessonId = "m13_l2",
                        question = "Which keyword explicitly triggers an exception in Python?",
                        options = listOf("throw", "raise", "fire", "trigger"),
                        correctIndex = 1,
                        explanation = "Python uses 'raise' to throw exceptions.",
                        topic = "Raising Exceptions"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m13_l2",
                    lessonId = "m13_l2",
                    title = "Validate Positive Number",
                    prompt = "Write a function 'check_positive(n)' that returns 'Valid' if n > 0 else 'Error: Must be positive'. Print check_positive(10) and check_positive(-3).",
                    starterCode = "# Define check_positive(n) and print both tests\n",
                    solutionCode = "def check_positive(n):\n    if n > 0:\n        return \"Valid\"\n    return \"Error: Must be positive\"\n\nprint(check_positive(10))\nprint(check_positive(-3))",
                    hint = "if n > 0: return 'Valid' else return 'Error: Must be positive'",
                    explanation = "Validates the numeric constraint and returns descriptive messages.",
                    testCases = listOf(
                        TestCase(expectedOutput = "Valid\nError: Must be positive")
                    )
                )
            )
        )
    )

    private fun createModule14(): CourseModule = CourseModule(
        id = "mod_14",
        number = 14,
        title = "Object-Oriented Programming",
        subtitle = "Classes, objects, self, __init__, inheritance, and encapsulation",
        iconName = "cube",
        isPremium = false,
        estimatedHours = 3.0,
        lessons = listOf(
            Lesson(
                id = "m14_l1",
                moduleId = "mod_14",
                title = "Classes, Objects, and __init__",
                order = 1,
                difficulty = Difficulty.INTERMEDIATE,
                readTimeMinutes = 7,
                isFree = true,
                summary = "Design blueprints for custom data objects with methods and state.",
                whyItMatters = "OOP allows modeling real-world entities (User, BankAccount, Product, GameCharacter) with their own data and behavior.",
                analogy = "A blueprint for a sports car (the Class): from that one blueprint, you can manufacture thousands of real physical cars (the Objects), each with their own color and driver.",
                explanation = "A 'class' defines the blueprint. '__init__' is the constructor method called when creating a new object. 'self' refers to the specific instance being operated on.",
                syntax = "class Dog:\n    def __init__(self, name):\n        self.name = name",
                exampleCode = "class Player:\n    def __init__(self, name, score=0):\n        self.name = name\n        self.score = score\n    def add_points(self, points):\n        self.score += points\n\np = Player(\"Maya\", 10)\np.add_points(15)\nprint(f\"{p.name}: {p.score}\")",
                lineByLine = listOf(
                    LineExplanation(1, "class Player:", "Class blueprint."),
                    LineExplanation(2, "def __init__(self, name, score=0):", "Constructor initializing instance attributes."),
                    LineExplanation(5, "def add_points(self, points):", "Method modifying instance state."),
                    LineExplanation(8, "p = Player(\"Maya\", 10)", "Instantiating a new Player object."),
                    LineExplanation(9, "p.add_points(15)", "Calling method on instance."),
                    LineExplanation(10, "print(f\"{p.name}: {p.score}\")", "Outputs 'Maya: 25'.")
                ),
                expectedOutput = "Maya: 25",
                visualConceptType = VisualConceptType.OOP,
                commonMistakes = listOf(
                    "Forgetting 'self' as the first parameter in instance methods."
                ),
                recap = listOf(
                    "Classes are blueprints; instances are concrete objects.",
                    "__init__ initializes state upon creation.",
                    "self refers to the instance."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m14_l1_1",
                        lessonId = "m14_l1",
                        question = "What does the 'self' parameter represent inside class methods?",
                        options = listOf(
                            "The global Python interpreter",
                            "The specific instance of the class",
                            "The parent superclass",
                            "A static memory pointer"
                        ),
                        correctIndex = 1,
                        explanation = "'self' refers to the concrete instance invoking the method.",
                        topic = "OOP"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m14_l1",
                    lessonId = "m14_l1",
                    title = "BankAccount Class",
                    prompt = "Create a class BankAccount with __init__(self, balance) and deposit(self, amount) that adds to balance. Create an account with balance 100, deposit 50, and print account.balance.",
                    starterCode = "# Define BankAccount and test deposit\n",
                    solutionCode = "class BankAccount:\n    def __init__(self, balance):\n        self.balance = balance\n    def deposit(self, amount):\n        self.balance += amount\n\nacc = BankAccount(100)\nacc.deposit(50)\nprint(acc.balance)",
                    hint = "self.balance += amount inside deposit method.",
                    explanation = "100 + 50 = 150.",
                    testCases = listOf(
                        TestCase(expectedOutput = "150")
                    )
                )
            ),
            Lesson(
                id = "m14_l2",
                moduleId = "mod_14",
                title = "Inheritance & Method Overriding",
                order = 2,
                difficulty = Difficulty.INTERMEDIATE,
                readTimeMinutes = 7,
                isFree = true,
                summary = "Extend existing classes with inheritance and customize behaviors with overriding.",
                whyItMatters = "Inheritance models 'is-a' relationships (e.g. Dog is an Animal, Admin is a User), eliminating redundant code.",
                analogy = "Children inheriting traits from their parents, while having their own unique talents.",
                explanation = "Pass the parent class name in parentheses: 'class SubClass(ParentClass):'. Use 'super().__init__()' to run parent initialization.",
                syntax = "class Animal:\n    def speak(self):\n        return \"Sound\"\nclass Cat(Animal):\n    def speak(self):\n        return \"Meow\"",
                exampleCode = "class Animal:\n    def __init__(self, name):\n        self.name = name\n    def speak(self):\n        return \"...\"\n\nclass Dog(Animal):\n    def speak(self):\n        return f\"{self.name} says Woof!\"\n\nd = Dog(\"Buddy\")\nprint(d.speak())",
                lineByLine = listOf(
                    LineExplanation(1, "class Animal:", "Base parent class."),
                    LineExplanation(6, "class Dog(Animal):", "Dog inherits from Animal."),
                    LineExplanation(7, "def speak(self):", "Overrides parent's speak method."),
                    LineExplanation(10, "d = Dog(\"Buddy\")", "Creates Dog instance using inherited __init__."),
                    LineExplanation(11, "print(d.speak())", "Outputs 'Buddy says Woof!'.")
                ),
                expectedOutput = "Buddy says Woof!",
                visualConceptType = VisualConceptType.OOP,
                commonMistakes = listOf(
                    "Forgetting to call super().__init__() when defining a custom __init__ in a subclass."
                ),
                recap = listOf(
                    "Subclasses inherit attributes and methods from parent classes.",
                    "Subclasses can override methods to customize behavior.",
                    "super() calls parent class methods."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m14_l2_1",
                        lessonId = "m14_l2",
                        question = "How does a child class invoke a method from its parent class?",
                        options = listOf("parent()", "super()", "base()", "root()"),
                        correctIndex = 1,
                        explanation = "super() returns a proxy object delegating method calls to the parent class.",
                        topic = "Inheritance"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m14_l2",
                    lessonId = "m14_l2",
                    title = "Class Inheritance",
                    prompt = "Create class Vehicle with get_type() returning 'Vehicle'. Create subclass Car(Vehicle) overriding get_type() to return 'Car'. Create a Car instance and print its get_type().",
                    starterCode = "# Define Vehicle and Car and print car type\n",
                    solutionCode = "class Vehicle:\n    def get_type(self):\n        return \"Vehicle\"\n\nclass Car(Vehicle):\n    def get_type(self):\n        return \"Car\"\n\nc = Car()\nprint(c.get_type())",
                    hint = "class Car(Vehicle): def get_type(self): return 'Car'",
                    explanation = "Car overrides get_type() to output 'Car'.",
                    testCases = listOf(
                        TestCase(expectedOutput = "Car")
                    )
                )
            )
        )
    )

    private fun createModule15(): CourseModule = CourseModule(
        id = "mod_15",
        number = 15,
        title = "Advanced Python",
        subtitle = "Decorators, generators, type hints, dataclasses, closures",
        iconName = "spark",
        isPremium = false,
        estimatedHours = 2.8,
        lessons = listOf(
            Lesson(
                id = "m15_l1",
                moduleId = "mod_15",
                title = "Generators & the 'yield' Keyword",
                order = 1,
                difficulty = Difficulty.ADVANCED,
                readTimeMinutes = 7,
                isFree = true,
                summary = "Generate streaming sequences on the fly with lazy memory efficiency using yield.",
                whyItMatters = "Loading a 50GB dataset into a list will crash your machine. Generators produce one item at a time with near-zero memory footprint.",
                analogy = "A water fountain: instead of storing 1,000 gallons in a bucket, water flows on demand one sip at a time when you push the pedal.",
                explanation = "Any function containing the 'yield' keyword is a generator. Instead of exiting like 'return', 'yield' pauses the function and yields a value, resuming on the next iteration.",
                syntax = "def count_up(n):\n    for i in range(n):\n        yield i",
                exampleCode = "def count_up(limit):\n    count = 1\n    while count <= limit:\n        yield count\n        count += 1\n\nfor num in count_up(3):\n    print(num)",
                lineByLine = listOf(
                    LineExplanation(1, "def count_up(limit):", "Generator function."),
                    LineExplanation(4, "yield count", "Pauses and yields value to caller."),
                    LineExplanation(7, "for num in count_up(3):", "Iterates lazily through 1, 2, 3.")
                ),
                expectedOutput = "1\n2\n3",
                visualConceptType = VisualConceptType.NONE,
                commonMistakes = listOf(
                    "Trying to access generator items by index like gen[0]—generators do not support indexing; iterate over them or use next()."
                ),
                recap = listOf(
                    "yield pauses function execution and emits a value.",
                    "Generators provide lazy evaluation with minimal memory usage."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m15_l1_1",
                        lessonId = "m15_l1",
                        question = "What keyword turns a standard Python function into a generator?",
                        options = listOf("generate", "yield", "stream", "emit"),
                        correctIndex = 1,
                        explanation = "The 'yield' keyword defines a generator function.",
                        topic = "Generators"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m15_l1",
                    lessonId = "m15_l1",
                    title = "Even Number Generator",
                    prompt = "Write a generator function evens_up_to(limit) that yields even numbers 2, 4, 6... up to limit. Loop through evens_up_to(6) and print each number.",
                    starterCode = "# Define evens_up_to and iterate over evens_up_to(6)\n",
                    solutionCode = "def evens_up_to(limit):\n    n = 2\n    while n <= limit:\n        yield n\n        n += 2\n\nfor val in evens_up_to(6):\n    print(val)",
                    hint = "n = 2; while n <= limit: yield n; n += 2",
                    explanation = "Yields 2, 4, 6 on demand.",
                    testCases = listOf(
                        TestCase(expectedOutput = "2\n4\n6")
                    )
                )
            ),
            Lesson(
                id = "m15_l2",
                moduleId = "mod_15",
                title = "Decorators & Function Wrappers",
                order = 2,
                difficulty = Difficulty.ADVANCED,
                readTimeMinutes = 7,
                isFree = true,
                summary = "Modify or extend function behavior dynamically with @decorator syntax.",
                whyItMatters = "Decorators power authentication (@login_required), routing (@app.route), caching, and performance logging in production web frameworks.",
                analogy = "Gift wrapping: the gift inside remains the same, but the wrapping paper decorates and adds a layer around it.",
                explanation = "A decorator is a function that takes another function as an argument and returns a new wrapped function. The @decorator syntax is clean syntactic sugar.",
                syntax = "@my_decorator\ndef my_func():\n    pass",
                exampleCode = "def announce(fn):\n    def wrapper():\n        print(\"Starting...\")\n        fn()\n        print(\"Finished!\")\n    return wrapper\n\n@announce\ndef greet():\n    print(\"Hello, Python!\")\n\ngreet()",
                lineByLine = listOf(
                    LineExplanation(1, "def announce(fn):", "Decorator accepting function fn."),
                    LineExplanation(2, "def wrapper():", "Inner function wrapping fn."),
                    LineExplanation(7, "@announce", "Applies decorator to greet."),
                    LineExplanation(11, "greet()", "Executes wrapper with extra behavior!")
                ),
                expectedOutput = "Starting...\nHello, Python!\nFinished!",
                visualConceptType = VisualConceptType.NONE,
                commonMistakes = listOf(
                    "Forgetting to return the inner wrapper function from the decorator."
                ),
                recap = listOf(
                    "Decorators wrap functions without altering their internal code.",
                    "@decorator is syntactic sugar for fn = decorator(fn)."
                ),
                quizQuestions = listOf(
                    QuizQuestion(
                        id = "q_m15_l2_1",
                        lessonId = "m15_l2",
                        question = "What is @my_decorator shorthand for in Python?",
                        options = listOf(
                            "fn = my_decorator(fn)",
                            "my_decorator.apply(fn)",
                            "fn = fn + my_decorator",
                            "my_decorator::fn()"
                        ),
                        correctIndex = 0,
                        explanation = "@decorator is equivalent to re-binding: fn = decorator(fn).",
                        topic = "Decorators"
                    )
                ),
                exercise = CodingExercise(
                    id = "ex_m15_l2",
                    lessonId = "m15_l2",
                    title = "Custom Decorator",
                    prompt = "Create a decorator 'double_output(fn)' that calls fn() and returns its result multiplied by 2. Apply it to get_ten() returning 10, and print get_ten().",
                    starterCode = "# Define double_output decorator, apply to get_ten, and print result\n",
                    solutionCode = "def double_output(fn):\n    def wrapper():\n        return fn() * 2\n    return wrapper\n\n@double_output\ndef get_ten():\n    return 10\n\nprint(get_ten())",
                    hint = "wrapper returns fn() * 2; return wrapper",
                    explanation = "10 * 2 = 20.",
                    testCases = listOf(
                        TestCase(expectedOutput = "20")
                    )
                )
            )
        )
    )
}
