package com.satori.app.model

enum class Difficulty {
    BEGINNER,
    INTERMEDIATE,
    ADVANCED
}

enum class VisualConceptType {
    NONE,
    VARIABLES,
    LISTS,
    LOOPS,
    FUNCTIONS,
    CONDITIONS,
    OOP
}

data class LineExplanation(
    val lineNumber: Int,
    val code: String,
    val explanation: String
)

data class QuizQuestion(
    val id: String,
    val lessonId: String,
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String,
    val topic: String
)

data class TestCase(
    val input: String = "",
    val expectedOutput: String,
    val isHidden: Boolean = false
)

data class ExamQuestion(
    val id: Int,
    val question: String,
    val codeSnippet: String? = null,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String,
    val difficulty: Difficulty = Difficulty.BEGINNER,
    val category: String = "Core Syntax"
)

data class CodingExercise(
    val id: String,
    val lessonId: String,
    val title: String,
    val prompt: String,
    val starterCode: String,
    val solutionCode: String,
    val hint: String,
    val explanation: String,
    val testCases: List<TestCase>
)

data class Lesson(
    val id: String,
    val moduleId: String,
    val title: String,
    val order: Int,
    val difficulty: Difficulty = Difficulty.BEGINNER,
    val readTimeMinutes: Int = 5,
    val isFree: Boolean = true,
    val summary: String,
    val whyItMatters: String,
    val analogy: String,
    val explanation: String,
    val syntax: String,
    val exampleCode: String,
    val lineByLine: List<LineExplanation>,
    val expectedOutput: String,
    val visualConceptType: VisualConceptType = VisualConceptType.NONE,
    val commonMistakes: List<String>,
    val recap: List<String>,
    val quizQuestions: List<QuizQuestion> = emptyList(),
    val exercise: CodingExercise? = null
)

data class CourseModule(
    val id: String,
    val number: Int,
    val title: String,
    val subtitle: String,
    val iconName: String,
    val isPremium: Boolean,
    val estimatedHours: Double,
    val lessons: List<Lesson>
)

data class CheatsheetItem(
    val id: String,
    val category: String,
    val title: String,
    val syntax: String,
    val description: String,
    val codeExample: String,
    val expectedOutput: String,
    val isPremium: Boolean = false
)

data class Achievement(
    val id: String,
    val title: String,
    val description: String,
    val iconName: String,
    val xpReward: Int,
    val isUnlocked: Boolean = false,
    val unlockedAt: String? = null
)

data class ProjectStep(
    val stepNumber: Int,
    val title: String,
    val instruction: String,
    val codeSnippet: String
)

data class GuidedProject(
    val id: String,
    val title: String,
    val category: String,
    val description: String,
    val difficulty: Difficulty,
    val estimatedMinutes: Int,
    val isPremium: Boolean,
    val starterCode: String,
    val solutionCode: String,
    val steps: List<ProjectStep>
)

data class CareerPath(
    val id: String,
    val title: String,
    val iconName: String,
    val description: String,
    val targetRoles: List<String>,
    val prerequisites: String,
    val recommendedModuleNumbers: List<Int>
)

data class SubscriptionPlan(
    val id: String,
    val title: String,
    val priceInr: Int,
    val periodText: String,
    val billingText: String,
    val savingsBadge: String? = null,
    val isPopular: Boolean = false,
    val benefits: List<String>
)

data class ExecutionResult(
    val stdout: String,
    val stderr: String = "",
    val executionTimeMs: Long = 0,
    val success: Boolean = true
)

data class UserAccount(
    val id: String,
    val name: String,
    val email: String,
    val passwordHash: String,
    val isGoogleUser: Boolean = false,
    val createdAt: String
)

data class CertificateData(
    val certificateId: String,
    val recipientName: String,
    val courseName: String = "Python Core & Applied Software Engineering",
    val issueDate: String,
    val founderName: String = "Amit Kumar",
    val founderTitle: String = "Founder & Lead Architect, SATORI",
    val verificationUrl: String = "satori.dev/verify"
)

data class UserProfile(
    val name: String = "Amit Kumar",
    val email: String = "amitdehlvi@gmail.com",
    val streakDays: Int = 3,
    val totalXp: Int = 240,
    val dailyGoalMinutes: Int = 15,
    val todayMinutesLearned: Int = 12,
    val completedLessonIds: Set<String> = setOf("m1_l1", "m1_l2"),
    val quizScores: Map<String, Int> = mapOf("m1_l1" to 100, "m1_l2" to 80),
    val bookmarkedLessonIds: Set<String> = setOf("m1_l1"),
    val lessonNotes: Map<String, String> = mapOf("m1_l1" to "print() displays messages on screen."),
    val isPremium: Boolean = true,
    val activePlanId: String? = "free_all_access",
    val subscriptionExpiryDate: String? = null,
    val unlockedAchievementIds: Set<String> = setOf("first_step", "variable_alchemist"),
    val isLoggedIn: Boolean = true,
    val provider: String = "google", // "google" or "email"
    val certificateId: String? = null,
    val certificateIssuedDate: String? = null,
    val hasClaimedCertificate: Boolean = false,
    val finalExamScore: Int? = null,
    val hasPassedFinalExam: Boolean = false,
    val finalExamDate: String? = null
)
