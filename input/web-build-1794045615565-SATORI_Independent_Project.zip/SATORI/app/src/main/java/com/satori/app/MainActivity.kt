package com.satori.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.satori.app.data.CurriculumRepository
import com.satori.app.data.ReferenceRepository
import com.satori.app.data.UserManager
import com.satori.app.model.Lesson
import com.satori.app.ui.components.SatoriHeader
import com.satori.app.ui.screens.*
import com.satori.app.ui.theme.SatoriIndigo
import com.satori.app.ui.theme.SatoriSurfaceDark
import com.satori.app.ui.theme.SatoriTheme

enum class SatoriDestination(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    DASHBOARD("Home", Icons.Default.Dashboard),
    CURRICULUM("Course", Icons.Default.AutoStories),
    PLAYGROUND("Playground", Icons.Default.Code),
    CHEATSHEET("Cheatsheet", Icons.Default.MenuBook),
    PROFILE("Profile", Icons.Default.Person)
}

class MainActivity : ComponentActivity() {

    private lateinit var userManager: UserManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        userManager = UserManager(applicationContext)

        setContent {
            val userProfile by userManager.userProfile.collectAsState()
            val isDarkTheme by userManager.isDarkTheme.collectAsState()
            var isGuestMode by remember { mutableStateOf(false) }

            SatoriTheme(darkTheme = true) {
                if (!userProfile.isLoggedIn && !isGuestMode) {
                    AuthScreen(
                        userManager = userManager,
                        onAuthSuccess = { isGuestMode = false },
                        onContinueAsGuest = { isGuestMode = true }
                    )
                } else {
                    var currentTab by remember { mutableStateOf(SatoriDestination.DASHBOARD) }
                    var activeLessonId by remember { mutableStateOf<String?>(null) }
                    var activeQuizLesson by remember { mutableStateOf<Lesson?>(null) }
                    var activeExerciseLesson by remember { mutableStateOf<Lesson?>(null) }
                    var isProjectsActive by remember { mutableStateOf(false) }
                    var isExamActive by remember { mutableStateOf(false) }

                    // BackHandler
                    BackHandler(
                        enabled = isExamActive || activeExerciseLesson != null || activeQuizLesson != null || activeLessonId != null || isProjectsActive || currentTab != SatoriDestination.DASHBOARD
                    ) {
                        when {
                            isExamActive -> isExamActive = false
                            activeExerciseLesson != null -> activeExerciseLesson = null
                            activeQuizLesson != null -> activeQuizLesson = null
                            activeLessonId != null -> activeLessonId = null
                            isProjectsActive -> isProjectsActive = false
                            currentTab != SatoriDestination.DASHBOARD -> currentTab = SatoriDestination.DASHBOARD
                        }
                    }

                    Scaffold(
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("satori_root_scaffold"),
                        topBar = {
                            when {
                                isExamActive -> {
                                    // FinalExam manages its own full-screen countdown header
                                }
                                activeExerciseLesson != null -> {
                                    Surface(
                                        color = SatoriSurfaceDark,
                                        shadowElevation = 8.dp,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("exercise_sticky_header")
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 16.dp, vertical = 10.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                IconButton(
                                                    onClick = { activeExerciseLesson = null },
                                                    modifier = Modifier
                                                        .size(36.dp)
                                                        .clip(androidx.compose.foundation.shape.CircleShape)
                                                        .background(com.satori.app.ui.theme.SatoriSurfaceHighlightDark)
                                                        .testTag("exercise_back_btn")
                                                ) {
                                                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                                                }

                                                Column {
                                                    Text(
                                                        text = "Coding Challenge",
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 15.sp,
                                                        color = Color.White
                                                    )
                                                    Text(
                                                        text = activeExerciseLesson!!.title,
                                                        fontSize = 11.sp,
                                                        color = com.satori.app.ui.theme.SatoriTextSecondary,
                                                        maxLines = 1
                                                    )
                                                }
                                            }

                                            Surface(
                                                color = com.satori.app.ui.theme.SatoriPythonGold.copy(alpha = 0.2f),
                                                shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                ) {
                                                    Icon(Icons.Default.Bolt, contentDescription = null, tint = com.satori.app.ui.theme.SatoriPythonGold, modifier = Modifier.size(14.dp))
                                                    Text(
                                                        text = "+30 XP",
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = com.satori.app.ui.theme.SatoriPythonGold
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                                activeQuizLesson != null -> {
                                    Surface(
                                        color = SatoriSurfaceDark,
                                        shadowElevation = 8.dp,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("quiz_sticky_header")
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 16.dp, vertical = 10.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                IconButton(
                                                    onClick = { activeQuizLesson = null },
                                                    modifier = Modifier
                                                        .size(36.dp)
                                                        .clip(androidx.compose.foundation.shape.CircleShape)
                                                        .background(com.satori.app.ui.theme.SatoriSurfaceHighlightDark)
                                                        .testTag("quiz_back_btn")
                                                ) {
                                                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                                                }

                                                Column {
                                                    Text(
                                                        text = "Lesson Quiz",
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 15.sp,
                                                        color = Color.White
                                                    )
                                                    Text(
                                                        text = activeQuizLesson!!.title,
                                                        fontSize = 11.sp,
                                                        color = com.satori.app.ui.theme.SatoriTextSecondary,
                                                        maxLines = 1
                                                    )
                                                }
                                            }

                                            Surface(
                                                color = SatoriIndigo.copy(alpha = 0.25f),
                                                shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
                                            ) {
                                                Text(
                                                    text = "${activeQuizLesson!!.quizQuestions.size} MCQs",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = com.satori.app.ui.theme.SatoriNeonSpark,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                                else -> {
                                    SatoriHeader(
                                        userProfile = userProfile,
                                        isDarkTheme = true,
                                        onToggleTheme = { userManager.toggleTheme() },
                                        onOpenSearch = { currentTab = SatoriDestination.CHEATSHEET },
                                        onOpenNotifications = {},
                                        onOpenProfile = { currentTab = SatoriDestination.PROFILE }
                                    )
                                }
                            }
                        },
                        bottomBar = {
                            if (!isExamActive && activeLessonId == null && activeQuizLesson == null && activeExerciseLesson == null) {
                                NavigationBar(
                                    containerColor = SatoriSurfaceDark,
                                    tonalElevation = 4.dp,
                                    modifier = Modifier
                                        .windowInsetsPadding(WindowInsets.navigationBars)
                                        .testTag("satori_bottom_nav")
                                ) {
                                    SatoriDestination.values().forEach { destination ->
                                        val isSelected = currentTab == destination && !isProjectsActive
                                        NavigationBarItem(
                                            selected = isSelected,
                                            onClick = {
                                                isProjectsActive = false
                                                currentTab = destination
                                            },
                                            icon = {
                                                Icon(
                                                    imageVector = destination.icon,
                                                    contentDescription = destination.label
                                                )
                                            },
                                            label = {
                                                Text(
                                                    text = destination.label,
                                                    fontSize = 11.sp
                                                )
                                            },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = Color.White,
                                                selectedTextColor = SatoriIndigo,
                                                indicatorColor = SatoriIndigo,
                                                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                            ),
                                            modifier = Modifier.testTag("nav_tab_${destination.name.lowercase()}")
                                        )
                                    }
                                }
                            }
                        }
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            AnimatedContent(
                                targetState = Pair(
                                    isExamActive,
                                    Triple(
                                        activeExerciseLesson != null,
                                        activeQuizLesson != null,
                                        activeLessonId != null
                                    )
                                ),
                                transitionSpec = { fadeIn() togetherWith fadeOut() },
                                label = "screen_transition"
                            ) { (examActive, lessonStates) ->
                                val (hasExercise, hasQuiz, hasLesson) = lessonStates
                                when {
                                    examActive -> {
                                        FinalExamScreen(
                                            onExamPassed = { score ->
                                                userManager.recordFinalExamResult(score, true)
                                            },
                                            onExamFailed = { score ->
                                                userManager.recordFinalExamResult(score, false)
                                            },
                                            onNavigateBack = { isExamActive = false },
                                            onViewCertificate = {
                                                isExamActive = false
                                                currentTab = SatoriDestination.PROFILE
                                            }
                                        )
                                    }

                                    hasExercise && activeExerciseLesson?.exercise != null -> {
                                        ExerciseScreen(
                                            exercise = activeExerciseLesson!!.exercise!!,
                                            onExercisePassed = {
                                                userManager.completeLesson(activeExerciseLesson!!.id)
                                            },
                                            onNavigateBack = { activeExerciseLesson = null }
                                        )
                                    }

                                    hasQuiz && activeQuizLesson != null -> {
                                        QuizScreen(
                                            lesson = activeQuizLesson!!,
                                            onQuizComplete = { percent ->
                                                userManager.saveQuizScore(activeQuizLesson!!.id, percent)
                                            },
                                            onNavigateBack = { activeQuizLesson = null }
                                        )
                                    }

                                    hasLesson && activeLessonId != null -> {
                                        val module = CurriculumRepository.modules.firstOrNull { m ->
                                            m.lessons.any { it.id == activeLessonId }
                                        } ?: CurriculumRepository.modules.first()
                                        val lesson = module.lessons.firstOrNull { it.id == activeLessonId }
                                            ?: module.lessons.first()

                                        val nextLesson = module.lessons.getOrNull(module.lessons.indexOf(lesson) + 1)

                                        LessonScreen(
                                            lesson = lesson,
                                            moduleTitle = module.title,
                                            userProfile = userProfile,
                                            onToggleBookmark = { userManager.toggleBookmark(it) },
                                            onSaveNote = { id, note -> userManager.saveLessonNote(id, note) },
                                            onMarkCompleted = { userManager.completeLesson(it) },
                                            onLaunchQuiz = { activeQuizLesson = it },
                                            onLaunchExercise = { activeExerciseLesson = it },
                                            onNavigateBack = { activeLessonId = null },
                                            onNextLesson = nextLesson?.let { nl -> { activeLessonId = nl.id } }
                                        )
                                    }

                                    isProjectsActive -> {
                                        ProjectsScreen(
                                            userProfile = userProfile,
                                            onOpenSubscription = { currentTab = SatoriDestination.CURRICULUM }
                                        )
                                    }

                                    else -> {
                                        when (currentTab) {
                                            SatoriDestination.DASHBOARD -> {
                                                DashboardScreen(
                                                    userProfile = userProfile,
                                                    onNavigateToCurriculum = { currentTab = SatoriDestination.CURRICULUM },
                                                    onNavigateToLesson = { activeLessonId = it },
                                                    onNavigateToPlayground = { currentTab = SatoriDestination.PLAYGROUND },
                                                    onNavigateToCheatsheet = { currentTab = SatoriDestination.CHEATSHEET },
                                                    onNavigateToProjects = { isProjectsActive = true },
                                                    onNavigateToSubscribe = { currentTab = SatoriDestination.CURRICULUM },
                                                    onNavigateToExam = { isExamActive = true }
                                                )
                                            }

                                            SatoriDestination.CURRICULUM -> {
                                                CurriculumScreen(
                                                    userProfile = userProfile,
                                                    onNavigateToLesson = { activeLessonId = it },
                                                    onOpenSubscription = { }
                                                )
                                            }

                                            SatoriDestination.PLAYGROUND -> {
                                                PlaygroundScreen()
                                            }

                                            SatoriDestination.CHEATSHEET -> {
                                                CheatsheetScreen()
                                            }

                                            SatoriDestination.PROFILE -> {
                                                ProfileScreen(
                                                    userProfile = userProfile,
                                                    onSelectPlan = { },
                                                    onResetProgress = {
                                                        userManager.resetProgress()
                                                    },
                                                    onNavigateToLesson = { activeLessonId = it },
                                                    onEditProfile = { name, email ->
                                                        userManager.updateProfile(name, email)
                                                    },
                                                    onClaimCertificate = {
                                                        userManager.claimCertificate()
                                                    },
                                                    onLogout = {
                                                        userManager.logout()
                                                    },
                                                    onNavigateToExam = { isExamActive = true }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                    }
                }
            }
        }
    }
}
