# SATORI — Python Learning App

SATORI is an independent Android application for learning Python.

## Build locally

1. Install Android Studio and a compatible JDK.
2. Open this project folder in Android Studio.
3. Allow Gradle to sync.
4. Run the `app` configuration on an emulator or Android device.

## Firebase

Firebase is used for authentication and related cloud services. Register the Android app using the package name configured in `app/build.gradle.kts` (`com.satori.app`), then download a fresh `google-services.json` and place it in the `app/` directory.

Enable Email/Password and Google sign-in in Firebase Authentication. Add SHA-1 and SHA-256 fingerprints for the signing keys used to build the app.

## Signing

Use your own release keystore and secure signing credentials for production. Do not commit private signing keys or passwords.
